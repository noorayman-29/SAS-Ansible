/**
 * Quest Authentication Services (QAS) API
 *
 * QAS API Version 4.0
 *
 * Copyright (c) 2010 Quest Software, Inc. All Rights Reserved.
 *
 * This header file is distributed as part of the Quest 
 * Authentication Services (previously Vintela Authentication 
 * Services or VAS) distribution governed by the Quest 
 * Authentication Services (QAS) Software End User License 
 * Agreement (the "EULA"). This header file is part of the 
 * "Licensed Software" licensed to a Licensee under the EULA. 
 * The Licensee may use information learned from this file to 
 * develop software applications that use the libvas library of 
 * QAS as permitted by the EULA, and for no other purpose. If 
 * you are not the Licensee under the EULA, then you do not have 
 * any license to use this file or any information in it. 
 *
 **/

/* NOTE:  This header file contains comment markups that are used with
 *        the Doxygen (generated) documentation system
 */


/** @file
 * These are functions that have been deprecated in the QAS API but are
 * retained for source and binary compatibility. You should not use these
 * functions and definitions in any new development work. To compile old code
 * that uses these deprecated functions, you must define VASAPI_ALLOW_DEPRECATED
 * at compile time.
 *
 **/


#ifndef VASAPI_DEPRECATED_H_INCLUDED
#define VASAPI_DEPRECATED_H_INCLUDED

#ifdef VASAPI_ALLOW_DEPRECATED

/**
 * Get the realm for a group. 
 * @deprecated This has been replaced by vas_group_get_domain(), and is only
 * kept for binary compatibility. This was done to prevent confusion as the
 * realm language should only be used to describe Kerberos realm membership,
 * and this function was intended to return the Active Directory domain that
 * the group belongs to.
 *
 * @param ctx           A ::vas_ctx_t obtained from vas_ctx_alloc()
 * @param id            Identity of user used to perform Active Directory searches.
 *                      Pass NULL to perform anonymous searches.
 * @param group         A ::vas_group_t for the group.
 * @param realm         Used to return the realm of the group.
 *                      Must be freed by calling free().
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_group_get_realm( vas_ctx_t *ctx,
                               vas_id_t *id,
                               vas_group_t *group,
                               char **realm );


/**
 * Get the realm for a user account.
 * @deprecated This has been replaced by vas_user_get_domain(), and is only
 * kept for binary compatibility. This was done to prevent confusion as the
 * realm language should only be used to describe Kerberos realm membership,
 * and this function was intended to return the Active Directory domain that
 * the user belongs to. For information about the user's Kerberos realm,
 * see vas_user_get_krb5_client_name().
 *
 * @param ctx           A ::vas_ctx_t obtained from vas_ctx_alloc()
 *
 * @param id            Identity of user used to perform Active Directory searches.
 *                      Pass NULL to perform anonymous searches.
 *
 * @param user          A ::vas_user_t for the user account.
 *
 * @param realm         Used to return the realm of the user account.
 *                      Must be freed by calling free().
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_user_get_realm( vas_ctx_t *ctx,
                              vas_id_t *id,
                              vas_user_t *user,
                              char **realm );


/**
 * Get the realm for a service account.
 * @deprecated This has been replaced by vas_service_get_domain(), and is only
 * kept for binary compatibility. This was done to prevent confusion as the
 * realm language should only be used to describe Kerberos realm membership,
 * and this function was intended to return the Active Directory domain that
 * the service belongs to. For information about the service's Kerberos realm,
 * see vas_service_get_krb5_client_name().
 *
 * @param ctx           A ::vas_ctx_t obtained from vas_ctx_alloc()
 *
 * @param id            Identity of user used to perform Active Directory searches.
 *                      Pass NULL to perform anonymous searches.
 *
 * @param service       A ::vas_service_t for the service account.
 *
 * @param realm         Used to return the realm of the service account.
 *                      Must be freed by calling free().
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_service_get_realm( vas_ctx_t *ctx,
                                 vas_id_t *id,
                                 vas_service_t *service,
                                 char **realm );

/**
 * Get the realm for a computer object.
 * @deprecated This has been replaced by vas_computer_get_domain(), and is only
 * kept for binary compatibility. This was done to prevent confusion as the
 * realm language should only be used to describe Kerberos realm membership,
 * and this function was intended to return the Active Directory domain that
 * the computer belongs to. For information about the computer's Kerberos realm,
 * see vas_computer_get_krb5_client_name().
 *
 * @param ctx           A ::vas_ctx_t obtained from vas_ctx_alloc()
 *
 * @param id            Identity of user used to perform Active Directory searches.
 *                      Pass NULL to perform anonymous searches.
 *
 * @param computer      A ::vas_computer_t for the computer object.
 *
 * @param realm         Used to return the realm of the computer object.
 *                      Must be freed by calling free().
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_computer_get_realm( vas_ctx_t *ctx,
                                  vas_id_t *id,
                                  vas_computer_t *computer,
                                  char **realm );


/** Used by server application to determine whether the authenticated client
 * is a member of a specified group.
 *
 * @deprecated This has been replaced by vas_auth_check_client_membership().
 *
 * A ::vas_auth_t contains information (the Microsoft PAC) about the groups
 * that a user is a member of.  After calling vas_auth() or
 * vas_auth_with_password() developers should call vas_auth_is_client_member()
 * as the most efficient way of determining whether or not a user is a
 * member of a particular group.  If the ::vas_auth_t necessary for calling
 * vas_auth_is_client_member() can not be obtained, the less efficient
 * vas_user_is_member(), or vas_group_has_member() may be used to test for
 * group membership.
 *
 * @param ctx   ::vas_ctx_t obtained from vas_ctx_alloc()
 *
 * @param auth  The ::vas_auth_t obtained previously with a call to vas_auth()
 *              or vas_auth_with_password().
 *
 * @param group The name of the group to check. May be a simple group name,
 *              the group's distinguished name, or the group's SID string.
 *
 * @return  VAS_ERR_SUCCESS if the client is a member of the group, or one of
 *          the following error codes:
 *          - VAS_ERR_NOT_FOUND     - Client is NOT a member of the group
 *          - VAS_ERR_EXISTS        - The group does not exist
 *          - VAS_ERR_INVALID_PARAM - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY     - Memory allocation failed
 */
vas_err_t vas_auth_is_client_member( vas_ctx_t* ctx,
                                     vas_auth_t* auth,
                                     const char* group );


#endif

#endif
