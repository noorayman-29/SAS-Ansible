/**
 * Quest Authentication Services (QAS) API
 *
 * QAS API Version 4.0
 *
 * Copyright (c) 2010 Quest Software, Inc. All Rights Reserved.
 *
 * This header file is distributed as part of the Quest 
 * Authentication Services (previously Vintela Authentication 
 * Services or VAS) distribution governed by the Quest 
 * Authentication Services (QAS) Software End User License 
 * Agreement (the "EULA"). This header file is part of the 
 * "Licensed Software" licensed to a Licensee under the EULA. 
 * The Licensee may use information learned from this file to 
 * develop software applications that use the libvas library of 
 * QAS as permitted by the EULA, and for no other purpose. If 
 * you are not the Licensee under the EULA, then you do not have 
 * any license to use this file or any information in it. 
 *
 **/

/* NOTE:  This header file contains comment markups that are used with
 *        the Doxygen (generated) documentation system
 */

/** @file
 * Function declarations that allow transition to the LDAP API
 *
 * These declarations are intended to be used in conjunction with the
 * LDAP header files that are shipped with the QAS SDK and with libvas.so
 * no other LDAP header files LDAP library should be linked in.
 **/


#ifndef VAS_LDAP_H_INCLUDED
#define VAS_LDAP_H_INCLUDED

#include "vas.h"
#include "ldap.h"

#ifdef __cplusplus
extern "C" {
#endif


/** Obtain an initialized and bound LDAP handle that can be used with the
 *  "standard" LDAP V3 functions included with the VASAPI.
 *
 * @param ctx   A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id    The identity that will be used to authenticate
 *              to the LDAP server.  The id MUST have established
 *              credentials.  Pass in NULL to perform anonymous
 *              LDAP searches.
 *
 * @param uri   The universal resource identifier (URI) that identifies what
 *              will be bound to an acceptable URI looks like one of the
 *              following:
 *              - "DC://"[ server ][ "@" domain ]
 *              - "GC://"[ server ][ "@" domain ]
 *              - "LDAP://"[ server ][ ":" port ]
 *              \verbatim
 *              Use a DC:// URI when you need to bind to Active
 *              Directory Domain controllers in a specific domain.
 *              If a DC:// URI is used without specifying a domain,
 *              the library will select a domain controller that is
 *              in the same domain as the identity being used in
 *              the call to vas_ldap_init_and_bind().
 *
 *              Use a GC:// URI when you need to bind to a Microsoft
 *              Active Directory Global Catalog. Though not normally
 *              necessary, you may specify a particular server and
 *              domain.  If a server is not specified, the library will
 *              select a Global Catalog that is in the current site.
 *
 *              The LDAP:// URI is provided for partial compatibility
 *              with RFC 2255.  ldap_init_and_bind() only recognizes the
 *              host and port components of an RFC 2255 URI.  If the
 *              LDAP:// URI does not specify a  port, the default LDAP
 *              port (389) will be used.
 *              \endverbatim
 *              The following are examples of valid URIs:
 *              - DC://
 *              - DC://myserver.example.com
 *              - GC://
 *              - GC://myserver.example.com
 *              - LDAP://
 *              - LDAP://myserver.example.com
 *              - LDAP://myserver.example.com:389
 *
 * @param ld    Set to point to an initialized and bound LDAP handle.
 *              Caller must free with ldap_unbind().
 *
 * @return  VAS_ERR_SUCCESS on success, or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM  - Invalid parameters
 *          - VAS_ERR_NO_MEMORY      - Memory allocation failed
 *          - VAS_ERR_CONFIG         - Default realm not configured
 *          - VAS_ERR_CRED_NEEDED    - Need credentials for id
 *          - VAS_ERR_CRED_EXPIRED   - Credentials have expired
 *          - VAS_ERR_KRB5           - Could not perform Kerberos auth
 *          - VAS_ERR_LDAP           - Could not connect to LDAP server
 */
vas_err_t vas_ldap_init_and_bind( vas_ctx_t* ctx,
                                  vas_id_t* id,
                                  const char* uri,
                                  LDAP** ld );


/** Set attributes on an LDAP object.
 *
 * @note
 * This function has been replaced with vas_ldap_modify(), and will be deprecated
 * in future versions of the QAS API.
 *
 * @code
 *
 * // EXAMPLE:
 * int set_user_principal_name( vas_ctx_t   *ctx,
 *                              vas_id_t    *id,
 *                              const char  *dn,
 *                              const char  *name )
 * {
 *     vas_err_t   rval = 0;
 *     char        *uri = NULL, *default_realm = NULL;
 *     char        computer[ 255+1 ];
 *     LDAP*       ldap_id = NULL;
 *     LDAPMod**   mods = NULL;
 *
 *     if( gethostname( computer, sizeof( computer ) )
 *     {
 *         rval = VAS_ERR_FAILURE;
 *         fprintf( stderr, "Could not get name of current host" );
 *         goto FINISHED;
 *     }
 *
 *     if( rval = vas_computer_get_domain( ctx, id, computer, &default_realm ) )
 *     {
 *         rval = VAS_ERR_FAILURE;
 *         fprintf( stderr, "Could not get default realm" );
 *         goto FINISHED;
 *     }
 *
 *     if ( asprintf( &uri, "DC://@%s", default_realm ) == - 1 )
 *     {
 *         rval = VAS_ERR_NO_MEMORY;
 *         goto FINISHED;
 *     }
 *
 *     if(    !( mods                = calloc( 2, sizeof( LDAPMod * ) ) )
 *         || !( mods[0]             = calloc( 1, sizeof( LDAPMod ) ) )
 *         || !( mods[0]->mod_values = calloc( 1, sizeof( char * ) ) ) )
 *     {
 *         rval = VAS_ERR_NO_MEMORY;
 *         goto FINISHED;
 *     }
 *
 *     mods[0]->mod_op        = LDAP_MOD_REPLACE;
 *     mods[0]->mod_type      = VAS_ATTR_USER_PRINCIPAL_NAME;
 *     mods[0]->mod_values[0] = (char *) name;
 *
 *     if( ( rval = vas_ldap_init_and_bind( ctx, id, uri, &ldap_id ) )
 *      || ( rval = vas_ldap_set_attributes( ctx, id, uri, dn, mods ) ) )
 *     {
 *         rval = VAS_ERR_FAILURE;
 *         fprintf( stderr, "Unable to set UPN (%s) for new user %s\n", name, dn);
 *     }
 *
 * FINISHED :
 *     if( uri )
 *         free( uri );
 *
 *     if( default_realm )
 *         free( default_realm );
 *
 *     if( mods )
 *     {
 *         if( mods[0] )
 *         {
 *             if( mods[0]->mod_values )
 *                 free( mods[0]->mod_values );
 *             free( mods[0] );
 *         }
 *         free( mods );
 *     }
 *
 *     if( rval == VAS_ERR_NO_MEMORY )
 *         vastool_err( stderr, "Out of memory.\n" );
 *
 *     return rval;
 * }
 *
 * @endcode
 *
 * @param ctx   A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id    The identity that will be used to authenticate
 *              to the LDAP server.  The id MUST have established
 *              credentials.  Pass in NULL to perform an anonymous
 *              LDAP modify, however, Active Directory permissions will not
 *              allow an anonymous modify in most cases.
 *
 * @param uri   The universal resource identifier (URI) that identifies the
 *              server that will be bound to. For more details on URI format
 *              see: vas_ldap_init_and_bind()
 *
 * @param dn    The distinguished name of the LDAP object to modify
 *
 * @param mods  A NULL terminated array of LDAPMod structures. See the LDAP
 *              documentation for more information on how to use LDAPMod
 *              structures.
 *
 * @return  VAS_ERR_SUCCESS on success, or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM  - Invalid parameters
 *          - VAS_ERR_NO_MEMORY      - Memory allocation failed
 *          - VAS_ERR_LDAP           - LDAP specific error
 *
 */
vas_err_t vas_ldap_set_attributes( vas_ctx_t* ctx,
                                   vas_id_t* id,
                                   const char* uri,
                                   const char* dn,
                                   LDAPMod** mods );

/** Create an object in LDAP
 *
 * vas_ldap_add() wraps the raw LDAP details associated with creating a new
 * directory object.  Internally, it will call vas_ldap_init_and_bind() to
 * obtain an LDAP handle, and execute ldap_add_ext() to add the object to the
 * directory.  If the server specified in the URI (or the one chosen by the
 * QAS API) is not writable, it will utilize any referral information received
 * from the server.  The LDAP handle associated with this transaction will not
 * be destroyed, but will be added to the internal list of LDAP handles that
 * will be closed when vas_id_free() or vas_ctx_free() is called.
 *
 * @param ctx   A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id    The identity that will be used to authenticate to the
 *              LDAP server.  The id MUST have established credentials,
 *              and must have the correct permissions set within Active
 *              Directory to enable the creation of the object.  Pass in 
 *              NULL to perform the add anonymously, however, Active
 *              Directory usually does not allow anonymous access.
 *
 * @param uri   The universal resource identifier (URI) that identifies the
 *              server that will be bound to. For more details on URI format
 *              see: vas_ldap_init_and_bind(). If NULL, vas_ldap_init_and_bind()
 *              will attempt to resolve the server based on the DN.
 *
 * @param dn    The distingsuished name of the LDAP object to create
 *
 * @param mods  A NULL terminated array of LDAPMod objects, which contain
 *              the attributes and values to set on the given object. See
 *              the LDAP documentation for more information on how to use
 *              LDAPMod structures.
 *
 * @param sctrl A NULL terminated array of LDAPControl objects, which contain
 *              the list of server side controls to apply to this request. 
 *
 * @param cctrl A NULL terminated array of LDAPControl objects, which contain
 *              the list of client side controls to apply to this request.
 *
 * @return  VAS_ERR_SUCCESS on success, or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM  - Invalid parameters
 *          - VAS_ERR_NO_MEMORY      - Memory allocation failed
 *          - VAS_ERR_CRED_EXPIRED   - Expired credentials for id
 *          - VAS_ERR_CRED_NEEDED    - id doesn't contain credentials
 *          - VAS_ERR_LDAP           - LDAP specific error
 *
 *
 */
vas_err_t vas_ldap_add( vas_ctx_t *ctx, vas_id_t *id, const char *uri, const char *dn, LDAPMod **mods, LDAPControl **sctrl, LDAPControl **cctrl );

/** Modify an existing LDAP object
 *
 * vas_ldap_modify() wraps the raw LDAP details associated with modifying
 * attributes on an existing directory object.  Internally, it will call
 * vas_ldap_init_and_bind() to obtain an LDAP handle, and execute ldap_modify_ext()
 * to modify the objects specified attributes.  If the server specified in the URI
 * (or the one chosen by the QAS API) is not writable, it will utilize any referral
 * information received from the server.  The LDAP handle associated with this
 * transaction will not be destroyed, but will be added to the internal list of
 * LDAP handles that will be closed when vas_id_free() or vas_ctx_free() is called.
 *
 * @note
 * This call replaces vas_ldap_set_attributes().
 *
 * @param ctx   A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id    The identity that will be used to authenticate.  See
 *              vas_ldap_add() for more info on how the id is used.
 *
 * @param uri   The universal resource identifier (URI) that identifies the
 *              server that will be bound to. For more details on URI format
 *              see: vas_ldap_init_and_bind(). If NULL, vas_ldap_init_and_bind()
 *              will attempt to resolve the server based on the DN.
 *
 * @param dn    The distinguished name of the LDAP object to modify.
 *
 * @param mods  A NULL terminated array of LDAPMod objects, which contain
 *              the attributes and values to modify on the given object. See
 *              the LDAP documentation for more information on how to use
 *              LDAPMod structures.
 *
 * @param sctrl A NULL terminated array of LDAPControl objects, which contain
 *              the list of server side controls to apply to this request.
 *
 * @param cctrl A NULL terminated array of LDAPControl objects, which contain
 *              the list of client side controls to apply to this request.
 *
 * @return  VAS_ERR_SUCCESS on success, or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM  - Invalid parameters
 *          - VAS_ERR_NO_MEMORY      - Memory allocation failed
 *          - VAS_ERR_CRED_EXPIRED   - Expired credentials for id
 *          - VAS_ERR_CRED_NEEDED    - id doesn't contain credentials
 *          - VAS_ERR_LDAP           - LDAP specific error
 *
 */
vas_err_t vas_ldap_modify( vas_ctx_t *ctx,
                           vas_id_t *id,
                           const char *uri,
                           const char *dn,
                           LDAPMod **mods,
                           LDAPControl **sctrl,
                           LDAPControl **cctrl );

/** Delete an existing LDAP object
 *
 * vas_ldap_delete() wraps the raw LDAP details associated with deleting
 * a directory object.  Internally, it will call vas_ldap_init_and_bind()
 * to obtain an LDAP handle, and execute ldap_delete_ext() to modify the
 * objects specified attributes.  If the server specified in the URI
 * (or the one chosen by the QAS API) is not writable, it will utilize any
 * referral information received from the server.  The LDAP handle associated
 * with this transaction will not be destroyed, but will be added to the internal
 * list of LDAP handles that will be closed when vas_id_free() or vas_ctx_free()
 * is called.
 *
 * @param ctx   A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id    The identity that will be used to authenticate.  See
 *              vas_ldap_add() for more info on how the id is used.
 *
 * @param uri   The universal resource identifier (URI) that identifies the
 *              server that will be bound to. For more details on URI format
 *              see: vas_ldap_init_and_bind(). If NULL, vas_ldap_init_and_bind()
 *              will attempt to resolve the server based on the DN.
 *
 * @param dn    The distinguished name of the LDAP object to modify.
 *
 * @param sctrl A NULL terminated array of LDAPControl objects, which contain
 *              the list of server side controls to apply to this request.
 *
 * @param cctrl A NULL terminated array of LDAPControl objects, which contain
 *              the list of client side controls to apply to this request.
 *
 * @return  VAS_ERR_SUCCESS on success, or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM  - Invalid parameters
 *          - VAS_ERR_NO_MEMORY      - Memory allocation failed
 *          - VAS_ERR_CRED_EXPIRED   - Expired credentials for id
 *          - VAS_ERR_CRED_NEEDED    - id doesn't contain credentials
 *          - VAS_ERR_LDAP           - LDAP specific error
 *
 */
vas_err_t vas_ldap_delete( vas_ctx_t *ctx,
                           vas_id_t *id,
                           const char *uri,
                           const char *dn,
                           LDAPControl **sctrl,
                           LDAPControl **cctrl );

/** Rename a LDAP object
 *
 * vas_ldap_rename() wraps the raw LDAP details associated with renaming
 * a directory object.  Internally, it will call vas_ldap_init_and_bind()
 * to obtain an LDAP handle, and execute ldap_rename() to modify the
 * objects specified attributes.  If the server specified in the URI
 * (or the one chosen by the QAS API) is not writable, it will utilize any
 * referral information received from the server.  The LDAP handle associated
 * with this transaction will not be destroyed, but will be added to the internal
 * list of LDAP handles that will be closed when vas_id_free() or vas_ctx_free()
 * is called.
 *
 * @param ctx           A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id            The identity that will be used to authenticate.  See
 *                      vas_ldap_add() for more info on how the id is used.
 *
 * @param uri           The universal resource identifier (URI) that identifies the
 *                      server that will be bound to. For more details on URI format
 *                      see: vas_ldap_init_and_bind(). If NULL, vas_ldap_init_and_bind()
 *                      will attempt to resolve the server based on the DN.
 *
 * @param dn            The distinguished name of the LDAP object to modify.
 *
 * @param newrdn        The new name for the object
 *
 * @param newSupp       New supperior for the given object
 *
 * @param deleteoldrdn  Flag indicating if the old object should be deleted
 *
 * @param sctrl         A NULL terminated array of LDAPControl objects, which contain
 *                      the list of server side controls to apply to this request.
 *
 * @param cctrl         A NULL terminated array of LDAPControl objects, which contain
 *                      the list of client side controls to apply to this request.
 *
 * @return  VAS_ERR_SUCCESS on success, or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM  - Invalid parameters
 *          - VAS_ERR_NO_MEMORY      - Memory allocation failed
 *          - VAS_ERR_CRED_EXPIRED   - Expired credentials for id
 *          - VAS_ERR_CRED_NEEDED    - id doesn't contain credentials
 *          - VAS_ERR_LDAP           - LDAP specific error
 *
 */
vas_err_t vas_ldap_rename( vas_ctx_t *ctx,
                           vas_id_t *id,
                           const char *uri,
                           const char *dn,
                           const char *newrdn,
                           const char *newSupp,
                           int deleteoldrdn,
                           LDAPControl **sctrl,
                           LDAPControl **cctrl );
  
#ifdef __cplusplus
}
#endif

#endif
