/** Definitions for VAS PKCS#11 context.
 *
 * Copyright 2006, Quest Software, Inc. All rights reserved.
 */
 
/**@file
 * Provides definitions for a VAS PKCS#11 context, which is used to access a 
 * PKCS#11 token (typically a smartcard). To use the VAS PKCS#11 context, the 
 * VAS PKCS#11 plugin must be available. 
 * 
 * <p>The VAS PKCS#11 context provides basic PKCS#11 functionality. PKCS#11 is
 * an abstration that allows access to a 'token' in a 'slot'. Typically, the 
 * token shall be a smartcard, and the slot shall be a smartcard reader 
 * attached to the local terminal. 
 * 
 * <p>The token may contain data (such as private keys and X.509 certificates),
 * and may perform cryptographic operations (such as encryption and signature
 * generation) using that data. Typically, access to the private key (which
 * may be required for certain cryptographic operations) requires the user
 * to login to the token using a PIN. 
 * 
 * <p>The VAS PKCS#11 context requires the token to contain one or more
 * 'identities'.  An 'identity' is a combination of a private key and an 
 * X.509 certificate that together are suitable for Windows smartcard logon. 
 * This cryptographic information is used when authenticating to the KDC via 
 * PKINIT.  Typically, a token would contain just the one 'identity'. However,
 * it may be possible that some tokens contain more than one identity.
 * 
 * <p>Requirements
 * 
 * <p>The requirements for a valid identity on a token are as follows:
 * <ul>
 * <li>there must exist an RSA private key object, and that object must
 * contain a CKA_ID attribute; and</li>
 * <li>there must exist an X.509 certificate object, and that object must
 * contain a CKA_ID attribute, whose value matches the value for the CKA_ID
 * attribute of the private key attribute. This CKA_ID attribute is used to 
 * find the matching private key/certificate pair of the identity; and</li>
 * <li>the X.509 certificate must have an extension that contains the UPN
 * of the identity; and</li>
 * <li>the X.509 certificate must have an extension indicating that the 
 * certificate may be used for smartcard login.</li>
 * </ul>
 * 
 * <p>Typically, the smartcard will be initialized by the administrator in a
 * Windows environment, and the card will already meet the requirements 
 * listed above.
 *
 * <p>Configuration</p>
 *
 * <p>The VAS PKCS#11 context may be configured by specifying settings in the 
 * '[pkcs11]' section of the VAS configuration file. The following settings
 * are defined:
 * <ul>
 * <li><i>pkcs11-lib</i> - the VAS PKCS#11 context communicates with the token
 * via a vendor-supplied PKCS#11 library. The location of this library is
 * specified using the <i>pkcs11-lib</i> setting. Note that this setting is
 * mandatory.</li>
 * <li><i>pkcs11-slot</i> - the VAS PKCS#11 context will communicate with a
 * token in a PKCS#11 slot (typically, a smartcard reader). In general, when
 * there is only one reader attached to the terminal, then only one slot
 * shall be available, and it should not be necessary to specify a value for
 * this setting. However, if there is more than reader attached to a terminal,
 * or a vendor-supplied PKCS#11 library allows 'virtual' slots to represent
 * one physical reader, then it may be necessary to specify which particular
 * slot should be used. The <i>pkcs11-slot</i> setting may thus be used to
 * specify the ID of the required slot. The ID is a number, whose value is
 * dependent on the vendor-supplied PKCS#11 library that is being used. 
 * Typically, the first slot shall have an ID of 0 or 1. Note that this
 * setting is optional. If a slot is not explicitly specified, then the VAS
 * PKCS#11 context shall use the first available slot.</li>
 *
 * <p>Usage</p>
 *
 * <p>A VAS PKCS#11 context is represented by an instance of the 
 * ::vas_pkcs11_t type. This type is opaque and its contents cannot be directly
 * examined or modified by the developer. 
 * 
 * <p>A new VAS PKCS#11 context is created using the vas_pkcs11_alloc() 
 * function, and destroyed using the vas_pkcs11_free() function. A VAS context
 * is required for creating a new VAS PKCS#11 context. Optoions for specifying
 * the vendor-supplied PKCS#11 library and the required PKCS#11 slot may be
 * supplied to the vas_pkcs11_alloc() function to override the default 
 * settings in the '[pkcs11]' section of the VAS configuration file.
 *
 * <p>Example:</p>
 * <code>
 * vas_ctx_t *ctx = ...;
 * vas_pkcs11_t *pkcs11 = NULL;
 * vas_err_t err;
 *
 * // Create a new VAS PKCS#11 context, using default options.
 * err = vas_pkcs11_alloc(ctx, NULL, &pkcs11);
 * if (err != VAS_ERR_SUCCESS) { ... handle error ... }
 * 
 * ... use the VAS PKCS#11 context ...
 *
 * // Destroy the VAS PKCS#11 context.
 * vas_pkcs11_destroy(pkcs11);
 * </code>
 *
 * <p>Once a VAS PKCS#11 context has been obtained, the first operation should
 * be to check for the presence of a token in the slot. This is performed
 * using the vas_pkcs11_is_token_present function(), as follows:
 * 
 * <code>
 * vas_pkcs11_t *pkcs11 = ...;
 * int present;
 * vas_err_t err;
 *
 * // Check if a token is present in the slot.
 * err = vas_pkcs11_is_token_present(pkcs11, &present);
 * if (err != VAS_ERR_SUCCESS) { ... handle error ... }
 * 
 * if (!present) { ... wait until token is present ... }
 * </code>
 *
 * <p>Note that the VAS PKCS#11 context does not provide any asynchronous
 * notification of token insertion or removal. 
 *
 * <p>Once a token is present in the slot, the next typical operation is to
 * login to the token so that access to the private key is granted. Login is
 * performed using the vas_pkcs11_login() function, which requires a PIN. 
 * Typically, the PIN is obtained from the user via the terminal, and this PIN
 * is supplied to the vas_pkcs11_login() function. However, the PIN may also
 * be obtained via an external keypad, and in such cases it is not necessary 
 * for the application to explicitly request and read a PIN from the terminal. 
 * The vas_pkcs11_is_pin_required() function may be used to determine if an 
 * application must explictly supply the PIN to the vas_pkcs11_login() 
 * function.
 * 
 * <p>Example:</p>
 * <code>
 * vas_pkcs11_t *pkcs11 = ...;
 * const char *pin = NULL;
 * int pin_required;
 * vas_err_t err;
 *
 * // Check if a PIN is required.
 * err = vas_pkcs11_is_pin_required(pkcs11, &pin_required);
 * if (err != VAS_ERR_SUCCESS) { ... handle error ... }
 *
 * // If PIN is required, then obtain PIN from user.
 * if (pin_required) { 
 *   pin = ...;
 * }
 * 
 * // Now perform login to the token.
 * err = vas_pkcs11_login(pkcs11, pin);
 * if (err != VAS_ERR_SUCCESS) { ... handle error ... }
 * </code>
 *
 * <p>Once login to the token has been performed, the next typical operation is
 * to perform cryptographic operations on behalf of an identity on the token. 
 * The cryptographic operations supported by the VAS PKCS#11 context are 
 * signature generation using the private key, and signature verification using
 * the X.509 certificate. These operations are performed by the 
 * vas_pkcs11_sign() and vas_pkcs11_verify() operations, respectively:
 *
 * <p>Signing Example:</p>
 * const char *message = "message to be signed"; 
 * int message_len = strlen(message);
 * unsigned char *signature = NULL;
 * int signature_len;
 *
 * // Get the length of the generated signature.
 * err = vas_pkcs11_sign(pkcs11, NULL, 0, NULL, &signature_len);
 * if (err != VAS_ERR_SUCCESS) { ... handle error ... }
 *
 * // Allocate signature buffer.
 * if ((signature = malloc(signature_len)) == NULL) { 
 *   ... handle error ...
 * }
 *
 * // Generate signature.
 * err = vas_pkcs11_sign(pkcs11, message, message_len, 
 *                               signature, &signature_len);
 * if (err != VAS_ERR_SUCCESS) { ... handle error ... }
 * </code>
 * 
 * <p>Verifying Example:</p>
 * <code>
 * const unsigned char *message = ...;
 * int message_len = ...;
 * const unsigned char *siganture = ...;
 * int signature_len = ...;
 *
 * err = vas_pkcs11_verify(pkcs11, message, message_len,
 *                                 signature, signature_len);
 * if (err != VAS_ERR_SUCCESS) { ... error: signature not verified ... }
 * </code>
 *
 * <p>It was noted above that the vas_pksc11_sign() and vas_pkcs11_verify()
 * functions operate on behalf of an identity. Typically, there shall only be
 * one identity on the token, and the vas_pkcs11_sign() and vas_pkcs11_verify()
 * functions may be used without specifying the actual identity. However, it
 * may be the case that a token contains multiple identities (that is, 
 * multiple instances of matching private key/certificate pairs). The VAS
 * PKCS#11 API includes operations for obtaining the set of identies contained
 * on a token, and getting and setting the current identity. These operations
 * are performed by the vas_pkcs11_get_identities() function, the 
 * vas_pkcs11_get_identity() function, and the vas_pkcs11_set_identity()
 * function respectively. Each identity is represented by its UPN.
 * 
 * <p>For example, if the token contains multiple identities, the identity to
 * be used for PKCS#11 operations may be specified as follows:
 * <code>
 * const char const **upns = NULL;
 * int i;
 * 
 * // Get the set of UPNs representing the set of identities on the token.
 * err = vas_pkcs11_get_identies(pkcs11, &upns);
 * if (err != VAS_ERR_SUCCESS) { ... handle error ... }
 *
 * // Iterate over available identities.
 * for (i = 0; upns[i] != NULL; i++) {
 *   const char *upn = upns[i];
 *   // Check if user wishes to use the identity.
 *   if (... user selects upn ...) {
 *     // Inform VAS PKCS#11 context of identity to be used.
 *     err = vas_pkcs11_set_identity(pkcs11, upn);
 *     if (err != VAS_ERR_SUCCESS) { ... handle error ... }
 *     break;
 *   }
 * }
 * 
 * // Free the list if UPNs returned.
 * free(upns);
 *
 * ... now perform PKCS#11 operations on behalf of selected identity ...
 * </code>
 *
 * <p>Note that the vas_pkcs11_get_identity() function will obtain the UPN
 * of the identity that will be used for performing subsequent PKCS#11
 * operations. This identity will be the default identity, or the identity
 * specified using the vas_pkcs11_set_identity() function. The
 * vas_pkcs11_get_identity() function may be used to determine if there is
 * an identity on the token, and typically would be sued by display 
 * managers when performing the login.
 *
 * <p>Example:</p>
 * <code>
 * const char *upn = NULL;
 * const char *pin = NULL;
 *
 * // Get the current (or default) identity on the token.
 * err = vas_pkcs11_get_identity(pkcs11, &upn);
 * if (err != VAS_ERR_SUCCESS) { ... handle error ... }
 *
 * // Check that there is an identity on the token.
 * if (upn == NULL) { ... error: no identity on token ... }
 *
 * // Get PIN 
 * printf("Enter PIN for %s: ", upn);
 * pin = get_pin();
 * 
 * // Login to token.
 * err = vas_pkcs11_login(pkcs11, pin);
 * if (err != VAS_ERR_SUCCESS) { ... handle error ... }
 * </code>
 *
 * <p>The following is an example which demonstrates a complete VAS PKCS#11
 * lifecycle, showing VAS PKCS#11 context creation, login to the token, and
 * performing signing/verifying operation:
 *  
 * <code>
 * vas_ctx_t *ctx = ...;
 * vas_pkcs11_t *pkcs11 = ...;
 * char const **upns = NULL;
 * int i;
 * int present;
 * int pin_required;
 * char *pin = NULL;
 * char *message = "message to be signed";
 * int message_len = strlen(message);
 * unsigned char *signature = NULL;
 * int signature_len;
 * vas_err_t err;
 * 
 * // Get a PKCS#11 context (using default options)
 * err = vas_pkcs11_alloc(ctx, NULL, &pkcs11);
 * if (err != VAS_ERR_SUCCESS) { ... error ... }
 * 
 * // Wait until a token is present
 * err = vas_pkcs11_is_token_present(pkc11, &present);
 * if (err != VAS_ERR_SUCCESS) { ... error ... }
 * 
 * if (!present) { 
 *   print("Please insert token\n");
 *   do { 
 *     sleep(10);
 *     err = vas_pkcs11_is_token_present(pkc11, &present);
 *     if (err != VAS_ERR_SUCCESS) { ... error ... }
 *   } while (!present);
 * }
 * 
 * // Get the identities on the token
 * err = vas_pkcs11_get_identities(pkcs11, &upns);
 * if (err != VAS_ERR_SUCCESS) { ... error ... }
 * 
 * // If there are no identities, then bail out
 * if (upns[0] == NULL) {
 *   ... error: "No identities on the token" ... 
 * }
 * // If there is exactly one identity, it will be used by by default.
 * else if (upns[1] == NULL) {
 *   printf("Using default identity: %s\n", upns[0]);
 * }
 * // Otherwise, must select amongst identities
 * else {
 *   int i;
 *   for (i = 0; upns[i] != NULL; i++) {
 *     const char *upn = upns[i];
 *     if (user_select(upn)) {
 *       err = vas_pkcs11_set_identity(pkcs11, upn);
 *       if (err != VAS_ERR_SUCCESS) { ... error ... }
 *       break;
 *   }
 *   ... error: "No identity chosen" ...
 * }
 * 
 * // Free the array of UPNs.
 * free(upns);
 * 
 * // Check if a PIN is required for login.
 * err = vas_pkcs11_is_pin_required(pkcs11, &pin_required);
 * if (err != VAS_ERR_SUCCESS) { ... error ... }
 * 
 * if (pin_required) {
 *   pin = ... get PIN value from user ...
 * }
 * 
 * // Login to the token
 * err = vas_pkcs11_login(pkcs11, pin);
 * if (err != VAS_ERR_SUCCESS) { ... error ... }
 * 
 * // Perform some cryptographic operations
 * 
 * // 1. Sign a message
 * 
 * // Get signature length
 * err = vas_pkcs11_sign(pkcs11, NULL, 0, NULL, &signature_len);
 * if (err != VAS_ERR_SUCCESS) { ... error ... }
 * 
 * // Allocate signature buffer. 
 * if ((signature = malloc(signature_len)) == NULL) {
 *   ... error ...
 * }
 * 
 * // Sign message 
 * err = vas_pkcs11_sign(pkcs11, message, message_len,
 *                       signature, &signature_len);
 * if (err != VAS_ERR_SUCCESS) { ... error ... }
 * 
 * printf("Generated signature of length %d bytes\n", signature_len);
 * 
 * // Verify the message.
 * err = vas_pkcs11_verify(pkcs11, message, message_len,
 *                         signature, signature_len);
 * if (err != VAS_ERR_SUCCESS && err != VAS_ERR_FAILURE) {
 *   ... error verifying the signature ...
 * }
 * 
 * if (err == VAS_ERR_FAILURE) { 
 *   printf("signature was not verified\n");
 * }
 * else {
 *   printf("signature was verified\n");
 * }
 * 
 * // Free the PKCS#11 context.
 * vas_pkcs11_free(pkcs11);
 * </code>
 * 
 */ 
#ifndef VAS_PKCS11_H
#define VAS_PKCS11_H

#ifdef __cplusplus
extern "C" {
#endif

#include <vas.h>

/**@defgroup SlotConsts Constants for specifying special slot values */

 /*@{*/
/** Constant indicating that any available slot should be used. This constant 
 * may be assigned to the @a slot field of the ::vas_pkcs11_opts_t type to 
 * indicate that the first slot found with a token present should be used by
 * the VAS PKCS#11 context. The use of this constant will override any 
 * configuration option. 
 * 
 * Example:
 * <code>
 * vas_ctx_t *ctx = ...;
 * vas_pkcs11_t *pkcs11 = NULL;
 * vas_pkcs11_opts_t opts;
 *
 * // Initialize options.
 * vas_pkcs11_opts_init(&opts);
 *
 * // Use the first available slot.
 * opts.slot = VAS_PKCS11_SLOT_ANY;
 * 
 * // Get a VAS PKCS#11 context
 * vas_pkcs11_alloc(ctx, &opts, &pkcs11);
 * </code>
 */
#define VAS_PKCS11_SLOT_ANY -1

/** Constant indicating that no slot has been specified, and the slot should be 
 * derived from the VAS configuration. This constant may be assigned to the 
 * @slot field of the ::vas_pkcs11_opts_t type. 
 * 
 * Note that if the options have been initialized via a call to the 
 * vas_pkcs11_opts_init() function, then the @a slot field shall be equal to 
 * ::VAS_PKCS11_SLOT_UNSPECIFIED already. Thus, it is not necessary to 
 * explicitly assign this constant to the @a slot field.
 * 
 * Example:
 * <code>
 * vas_ctx_t *ctx = ...;
 * vas_pkcs11_t *pkcs11 = NULL;
 * vas_pkcs11_opts_t opts;
 *
 * // Initialize PKCS#11 options.
 * vas_pkcs11_opts_init(&opts);
 * 
 * // Set the slot to "UNSPECIFIED". The slot information shall be derived
 * // from VAS configuration. Note that this is unnecessary, since the 'slot'
 * // field of 'opts' shall already be set to this value.
 * opts.slot = VAS_PKCS11_SLOT_UNSPECIFIED;
 *
 * // Get a VAS PKCS#11 context using the specified options. 
 * vas_pkcs11_alloc(ctx, &opts, &pkcs11);
 * </code>
 */
#define VAS_PKCS11_SLOT_UNSPECIFIED -2

#define VAS_PKCS11_RESET_NEVER 0
#define VAS_PKCS11_RESET_ALWAYS 1
#define VAS_PKCS11_RESET_VERSION 2
#define VAS_PKCS11_RESET_UNSPECIFIED -1
/*}@*/

/** Type representing the PKCS#11 options. A value of this type may be passed 
 * to the vas_pkcs11_opts_init() function to override the configured PKCS#11
 * options. */
typedef struct {
    /** Path to the underlying PKCS#11 library. If this value is NULL,
     * then the path shall be derived from the VAS configuration file. */
    const char *path;

    /** The slot for the token. If this value is ::VAS_PKCS11_SLOT_ANY, then 
     * the first available slot shall be used. If this value is 
     * ::VAS_PKCS11_SLOT_UNSPECIFIED, then the slot shall be derived from the
     * VAS configuration file. Otherwise, this value shall represent a 
     * specific slot ID to be used. */
    int slot;

    /** Indicates if resetting of the PKCS#11 library is permitted if no
     * slots can be found. 
     *
     * Before version 2.20, the PKCS#11 standard explicitly forbade new slots 
     * being recognized dynamically after the PKCS#11 library had been 
     * initialized. If a slot was added after the PKCS#11 library had
     * been initialized, then the only way to recognize the slot was to 
     * reinitialize the library. For version 2.20 and above, new slots should
     * be recognized dynamically.
     * 
     * The VAS PKCS#11 context will attempt to reset the PKCS#11 library when
     * no slots are available, depending on the value of this option. Note,
     * however, that there may be some slight performance penalty if reset is
     * permitted. This penalty is dependent on the underlying PKCS#11 
     * implementation. 
     * 
     * Permitted values for this option are:
     * <ul>
     * <li>::VAS_PKCS11_RESET_NEVER  - the PKCS#11 libraray shall not be
     * reset if no slots can be found.  It is possible that slots may never 
     * be recognized if such slots were not connected at the time the PKCS#11 
     * library was initialized. Use this option only if the underlying PKCS#11 
     * library always recognizes slots dynamically, or if a slot is always 
     * connected when the underlying PKCS#11 library is initialized.
     * 
     * <li>::VAS_PKCS11_RESET_VERSION - the PKCS#11 library shall be reset if
     * no slots can be found, but only if the version of the library is less
     * than 2.20. Use this option if the underlying PKCS#11 library has a 
     * version number less than 2.20
     * 
     * <li>::VAS_PKCS11_RESET_ALWAYS - the PKCS#11 library shall be reset if
     * no slots can be found. This shall occur regardless of the version of
     * the underlying PKCS#11 library. Use this option if the underlying
     * PKCS#11 library is version 2.20 or above but for some reason new slots
     * are not recognized dynamically.
     *
     * <li>::VAS_PKCS11_RESET_UNSPECIFIED - the actual value for this option 
     * shall be obtained from the VAS configuration file. 
     * </ul>
     * 
     * By default, the value for this option shall be 
     * ::VAS_PKCS11_RESET_UNSPECIFIED. If a value must be specified, it is
     * recommended to use ::VAS_PKCS11_RESET_VERSION.
     */
    int allow_reset;
} vas_pkcs11_opts_t;

/** Initialize the options to a VAS PKCS#11 context. 
 *
 * Once initialized, the options shall be:
 *
 * <code>
 *   options.path = NULL
 *   options.slot = VAS_PKCS11_SLOT_UNSPECIFIED
 *   options.allow_reset = VAS_PKCS11_RESET_UNSPECIFIED
 * </code>
 *
 * The default settings above imply that the path and slot shall be derived 
 * from the VAS configuration settings. This is equivalent to passing the
 * value NULL to vas_pkcs11_alloc as the options. Typically, once the options
 * have been initialized, some particular option would be updated.
 *
 * Example:
 * <code>
 *   vas_ctx_t *ctx = ...;
 *   vas_pkcs11_opts_t options;
 *   vas_pkcs11_t *pkcs11 = NULL;
 *   vas_err_t err;
 *
 *   // Initialize PKCS#11 context with default options
 *   err = vas_pkcs11_alloc(ctx, NULL, &pkcs11);
 * 
 *   // Another way to initialize PKCS#11 context with default options
 *   vas_pkcs11_opts_init(&options);
 *   err = vas_pkcs11_alloc(ctx, &options, &pkcs11);
 *
 *   // Use a specific slot with PKCS#11 context
 *   vas_pkcs11_opts_init(&options);
 *   options.slot = 1;
 *   err = vas_pkcs11_alloc(ctx, &options, &pkcs11);
 * </code>
 *   
 * @param options the options to be initialized. Must not be NULL.
 */
void vas_pkcs11_opts_init(vas_pkcs11_opts_t *options);

/** Initialize a VAS PKCS#11 context. The VAS PKCS#11 context is 
 * destroyed by a call to vas_pkcs11_free().
 * 
 * The VAS PKCS#11 plugin must be available at run-time in order to
 * create a VAS PKCS#11 context. 
 * 
 * TODO document how to configure the plugin
 * 
 * <p>On success, a pointer to a newly-allocated VAS PKCS#11 context
 * is obtained. The vas_pkcs11_free() function must be called to 
 * release all resources held by the context and delete the context
 * itself.
 * 
 * <p>Example:
 * <code>
 * vas_ctx_t *ctx = ...;
 * vas_pkcs11_t *pkcs11 = NULL;
 * vas_pkcs11_opts_t options;
 * vas_err_t err;
 *
 * // Create the PKCS#11 context (using default options)
 * err = vas_pkcs11_alloc(ctx, NULL, &pkcs11);
 * if (err != VAS_ERR_SUCCESS) { ... error ... }
 *
 * ... use the VAS PKCS#11 context ...
 *
 * // Destroy the PKCS#11 context
 * vas_pkcs11_free(pkcs11);
 * 
 * // Create a PKCS#11 contest, using specific options. Here we
 * // specify a particular PKCS#11 library, and the leave the slot
 * // unspecified (actual slot will be derived from VAS configuration
 * // settings.
 *
 * vas_pkcs11_opts_init(&options);
 * options.path = "/usr/local/lib/lib_foo_pkcs11.so";
 * 
 * err = vas_pkcs11_alloc(ctx, &options, &pkcs11);
 * ...
 * </code>
 * 
 * @param ctx an initialized VAS context. Must not be NULL.
 * 
 * @param options the options for the VAS PKCS#11 context. The options allow
 * the caller to specify which PKCS#11 library and slot number is used when
 * performing PKCS#11 operations. If this value is NULL, then the default
 * options (obtained via VAS configuration settings) are used.

 * @param p_pkcs11 pointer to obtain a VAS PKCS#11 context. Must
 * not be NULL
 * 
 * @return VAS_ERR_SUCCESS on success; any other value indicates an error.
 * 
 * <p>The following return values are defined:
 * <ul>
 * <li>VAS_ERR_SUCCESS - the VAS PKCS#11 context was  initialized and
 * *p_pkcs11 contains a newly-allocated VAS PKCS#11 context.</li>
 * <ul>
 * 
 * TODO document other return values
 *
 * @see vas_pkcs11_free  
 */
vas_err_t vas_pkcs11_alloc(vas_ctx_t *ctx,
                           const vas_pkcs11_opts_t *options,
                           vas_pkcs11_t **p_pkcs11);

/** Determines if a token is present in the configured slot for the VAS
 * PKCS#11 context.
 * 
 * <p>Example:
 * <code>
 * vas_pkcs11_t *pkcs11 = ...;
 * int present;
 * vas_err_t err;
 * 
 * err = vas_pkcs11_is_token_present(pkcs11, &present);
 * if (err != VAS_ERR_SUCCESS) { ... handle error ... }
 * 
 * if (present) { ... handle token present case ... {
 * else { ... handle token absent case ... }
 * </code>
 * 
 * @param pkcs11 the VAS PKCS#11 context obtained via vas_pkcs11_alloc()
 * 
 * @param p_present pointer to hold 'token present' value. Must not be NULL.
 * 
 * @return VAS_ERR_SUCCESS on success; any other value indicates an error.
 * 
 * <p>The following return values are defined:
 * <ul>
 * <li>VAS_ERR_SUCCESS - the token status was determined and *p_present
 * contains the token status: 0 = token is not present, 1 = token is
 * present</li>
 * </ul>
 * 
 * TODO document other return values
 */ 
vas_err_t vas_pkcs11_is_token_present(vas_pkcs11_t *pkcs11,
                                      int *p_present);

/** Determines if a PIN is required when performing a login to the token. 
 *
 * <p>The token may be attached to an external pinpad, or the token may have
 * some other external method of authenticating the user. In such cases, a 
 * PIN is not required when performing a PCKS#11 login. The call to the
 * function vas_pkcs11_login() is still required, however the PIN may be set
 * to NULL.
 * 
 * <p>See vas_pkcs11_login() for example code
 *
 * @param pkcs11 the initialized VAS PKCS#11 context. Must not be NULL
 * @param p_pin_required pointer to hold the return value. Must not be NULL.
 * 
 * @return VAS_ERR_SUCCESS if it is possible to determine whether a PIN is
 * required. If so, *p_pin_required will contain 0 if a PIN is not required,
 * and 1 if a PIN is required.
 * 
 * @return VAS_ERR_PKCS11 if a PKCS#11 error occurred while determining if a
 * PIN is required.
 * 
 * @see vas_pkcs11_login
 */ 
vas_err_t vas_pkcs11_is_pin_required(vas_pkcs11_t *pkcs11,
                                     int *p_pin_required);

/** Perform a login to the PKCS#11 token.
 *
 * <p>A login is required to access private keys and perform cryptographic
 * operations on the token. If such operations are performed when a login
 * session is not active, then an error shall be returned.
 * 
 * <p>A PIN is generally required, unless there exists some external method
 * of presenting the PIN to the token (typically via a keypad attached to 
 * the token reader). In such cases, the PIN may be specified as NULL. The
 * vas_pkcs11_is_pin_required() method may be used to determine if a PIN is
 * required.
 *
 * <p>Once a successful login to the token has been performed, cryptographic
 * information (such as private keys) may be loaded into the VAS PKCS#11
 * context. Once a login is no longer active, any loaded cryptographic 
 * objects shall be destroyed. It is therefore crucial that the lifetime of 
 * any login sessions should be as limited as possible. In addition, if a 
 * PIN was used, that PIN should be whitened and destroyed as soon as possible
 * after the login itself.
 * 
 * <p>The login remains active until any of the following occurs:
 * <ul>
 * <li>the vas_pkcs11_logout() function is called; or</li>
 * <li>the vas_pkcs11_free() function is called; or</li>
 * <li>the token is removed from the slot</li>
 * </ul>
 *
 * <p>Example:
 * <code>
 * vas_pkcs11_t *pkcs11 = ...;
 * const char *pin = NULL;
 * int pin_required;
 * vas_err_t err;
 *
 * // Check if a PIN is required.
 * err = vas_pkcs11_is_pin_required(pkcs11, &pin_required);
 * if (err != VAS_ERR_SUCCESS) { ... error ... }
 *
 * // Get PIN if necessary.
 * if (pin_required) {
 *   pin = ...;
 * }
 *
 * // Login to the token.
 * err = vas_pkcs11_login(pkcs11, pin);
 * if (err != VAS_ERR_SUCCESS) { ... error ... }
 *
 * // Whiten and destroy the PIN 
 * if (pin != NULL) {
 *   memset(pin, 0, strlen(pin));
 *   free(pin)
 * }
 * 
 * ... perform cryptographic operations ...
 *
 * // Logout of the token.
 * vas_pkcs11_logout(pkcs11);
 * </code>
 *
 * @param pkcs11 the initialized VAS PKCS#11 context. Must not be NULL.
 *
 * @param pin the PIN for the login. May be NULL if login does not require
 * a PIN.
 * 
 * @return VAS_ERR_SUCCESS if login was performed successfully
 * 
 * @return VAS_ERR_PKCS11 if a PKCS#11 error occurred while performing the
 * login (such as incorrect PIN, PIN locked, etc)
 * 
 * @return VAS_ERR_NO_MEMORY if a memory error occurred
 */
vas_err_t vas_pkcs11_login(vas_pkcs11_t *pkcs11, const char *pin);

/** Logout of the token, destroying any private keys bound to the PKCS#11
 * context. If cryptographic operations are still required, a login must 
 * be performed.
 *
 * If a login has not been performed, this function has no effect.
 *
 * See vas_pkcs11_login() for example code.
 * 
 * @param ctx the initialzied VAS PKCS#11 context. Must not be NULL.
 *
 * @return VAS_ERR_SUCCESS if the logout was successful.
 *
 * @return VAS_ERR_PKCS11 if a PKCS#11 error occurred performing the logout.
 *
 * @see vas_pkcs11_login
 */
vas_err_t vas_pkcs11_logout(vas_pkcs11_t *pkcs11);

/** Set the PIN of the token.
 * 
 * <p>Example:
 * <code>
 * vas_pkcs11_ctx *pkcs11 = ...;
 * vas_err_t err;
 *
 * err = vas_pkcs11_set_pin(pkcs11, "old pin", "new pin");
 * if ( err != VAS_ERR_SUCCESS) { ... error ... }
 *
 * @param ctx the initialized VAS PKCS#11 context. Must not be NULL.
 * 
 * @param old_pin the current PIN of the token. May be NULL if the token 
 * allows the current PIN to be input via a protected authentication path, such
 * as a keypad attached to the token reader.
 * 
 * @param new_pin the new PIN for the token. May be NULL if the token 
 * allows the new PIN to be input via a protected authentication path, such
 * as a keypad attached to the token reader.
 * 
 * @return VAS_ERR_SUCCESS if the PIN of the token was updated from the old
 * PIN to the new PIN.
 * 
 * @return VAS_ERR_PKCS11 if a PKCS#11 error occurred (for example, the old
 * PIN cannot be verified, no token in the slot, etc).
 * 
 * @return VAS_ERR_NO_MEMORY if a memory error occurred.
 */ 
vas_err_t vas_pkcs11_set_pin(vas_pkcs11_t *pkcs11,
                             const char *old_pin,
                             const char *new_pin);

/** Get the UPN of each identity on the token. 
 *
 * Note that the array returned shall not be NULL, and the final element in 
 * the array shall be NULL. If there are no identities on the token, then 
 * an array of length 1 shall be returned, with the only element containing
 * the value NULL.
 *
 * Note also that the caller is responsible for freeing the array of UPNs
 * returned. Only the array is freed, not the individual UPNs contain in
 * that array.
 *
 * Example usage:
 * <code>
 * vas_ctx_t *ctx = ...;
 * vas_pkcs11 *pkcs11 = ...;
 * char const **upns = NULL;
 * vas_err_t err;
 *
 * // Get the set of UPNs on the token
 * err = vas_pkcs11_get_identities(pkcs11, &upns);
 * if (err != VAS_ERR_SUCCESS) { ... error ... }
 *
 * // Display the UPNs
 * for (i = 0; upns[i] != NULL; i++) {
 *   const char *upn = upns[i];
 *   printf("upn[%d] = %s\n", i, upn);
 * }
 * 
 * // Destroy the array of UPNs.
 * free(upns);
 * </code>
 *
 * @param pkcs11 the initialized PKCS#11 context. Must not be NULL.
 *
 * @param p_upns pointer to hold a newly-allocated array of UPN strings. Must
 * not be NULL. Each element of the array shall contain a UPN of an identity
 * on the token. No ordering is specified on the array contents. This array 
 * must be freed by the caller when no longer required. 
 * 
 * @return VAS_ERR_SUCCESS if the array of UPNs is obtained. 
 *
 * @return VAS_ERR_PKCS11 if a PKCS#11 error occurred.
 * 
 * @return VAS_ERR_NO_MEMORY if a memory error occurred.
 */ 
vas_err_t vas_pkcs11_get_identities(vas_pkcs11_t *pkcs11,
                                    char const ***p_upns);

/** Set the identity to be used for subsequent cryptographic operations.
 * 
 * If a token contains more than identity (a binding of private key to an
 * X.509 certificate), then this function may be used to select the identity
 * to be used when performing cryprographic operations. The identity is 
 * selected by specifying the UPN contained in the X.509 certificate.
 *
 * Typically, a token would contain only one identity, and that identity shall
 * be selected by default. If the token contains more than one identity and
 * no identity is explicitly specified, then the first identity found on the 
 * token shall be used for cryptographic operations.
 *
 * Once the identity has been selected, all subsequent cryptographic 
 * operations shall use the private key and X.509 certificate of that 
 * identity. If cryptographic operations of another identity are required,
 * then another call to this function is required.
 *
 * The following example demonstrates how to sign a message using each
 * identity on the token:
 * 
 * <code>
 * vas_pkcs11_t *pkcs11 = ...;
 * char const **upns = NULL;
 * int i;
 * vas_err_t err;
 *
 * // Get the UPNs on the token.
 * err = vas_pkcs11_get_identities(pkcs11, &upns);
 * if (err != VAS_ERR_SUCCESS) { ... error ... }
 *
 * // Perform signing operation for each identity
 * for (i = 0; upns[i] != NULL; i++) {
 *   // Set the identity on the token.
 *   err = vas_pkcs11_set_identity(pkcs11, upns[i]);
 *   if (err != VAS_ERR_SUCCESS) { ... error ... }
 *
 *   // Sign datsa using the specified identity
 *   err = vas_pkcs11_sign(pkcs11, ... );
 * }
 * 
 * // Free the set of UPNs.
 * free(upns);
 * </code>
 *
 * Note that specifying the UPN as NULL will select the default identity
 * of the token.
 * 
 * @param pkcs11 the initialized PKCS#11 context. Must not be NULL.
 *
 * @param upn the UPN of the identity to be used for cryptographic operations
 * on the token. If this value is NULL, then the default identity (if any) of
 * the token shall be selected. Otherwise, the identity whose X.509 
 * certificate contains a UPN that matches the specified UPN shall be 
 * selected.
 *
 * @return VAS_ERR_SUCCESS if the active identity of the token was updated
 * according to the specified UPN.
 *
 * @return VAS_ERR_NOT_FOUND if there is no identity on the token matching
 * the specified UPN. If the specified UPN is NULL, then this also means that
 * there are no identities on the token.
 *
 * @return VAS_ERR_PKCS11 if a PKCS#11 error occurred.
 *
 * @return VAS_ERR_NO_MEMORY if a memory error occurred.
 */
vas_err_t vas_pkcs11_set_identity(vas_pkcs11_t *pkcs11, 
                                  const char *upn);

/** Get the UPN of the active identity to be used for cryptographic
 * operation on the token.
 *
 * The active identity is the one selected via the vas_pkcs11_set_identity()
 * function, or the default identity if no identity has been explicitly
 * selected. If the token does not contain an identity (ie, there is no
 * suitable private key/X.509 certificate object on the token), then a NULL
 * UPN shall be returned.
 *
 * Example:
 * <code>
 * vas_pkcs11_t *pkcs11 = ...;
 * const char *upn = NULL;
 * vas_err_t err;
 * 
 * // Get the UPN of the active identity (if any) on the token.
 * err = vas_pkcs11_get_identity(pkcs11, &upn);
 * if (err != VAS_ERR_SUCCESS) { ... error ... }
 * 
 * if (upn == NULL) {
 *   printf("no identity available on token\n");
 * }
 * else {
 *   printf("using identity '%s'\n", upn);
 * }
 *
 * if(upn) free((char*)upn);
 *
 * </code>
 *
 * @param pkcs11 the initialized PKCS#11 context. Must not be NULL.
 *
 * @param p_upn pointer to hold the UPN of the current identity. Must not be
 * NULL. The value returned in this pointer must be freed by the caller.
 * If there are no identities on the token, the value returned shall be NULL.
 *
 * @return VAS_ERR_SUCCESS if an active identity exists on the token, and the
 * UPN of this identity has been obtained; or if there are no identities on 
 * the token, and NULL has been returned.
 *
 * @return VAS_ERR_PKCS11 if a PKCS#11 error occurred.
 *
 * @return VAS_ERR_NO_MEMORY if a memory error occurred.
 */
vas_err_t vas_pkcs11_get_identity(vas_pkcs11_t *pkcs11,
                                  char const **p_upn);

/** Resolve the identity to a user.  This really becomes necessary when
 * the certificate is mapped to a user in AD.  If the Subject Alternative
 * Name on the certificate contains the user's UPN or krb5 principal name,
 * calling this function isn't necessary.
 *
 * The active identity is the one selected via the vas_pkcs11_set_identity()
 * function, or the default identity if no identity has been explicitly
 * selected. If the token does not contain an identity (ie, there is no
 * suitable private key/X.509 certificate object on the token), then a NULL
 * vas_id_t shall be returned.
 *
 * Example:
 * <code>
 * vas_ctx_t *ctx = ...;
 * vas_pkcs11_t *pkcs11 = ...;
 * const char *upn = NULL;
 * vas_id_t *id = NULL;
 * vas_err_t err;
 * 
 * // Get the UPN of the active identity (if any) on the token.
 * err = vas_pkcs11_get_identity(pkcs11, &upn);
 * if (err != VAS_ERR_SUCCESS) { ... error ... }
 * 
 * // Set the current identity.
 * err = vas_pkcs11_set_identity(pkcs11, upn);
 * if (err != VAS_ERR_SUCCESS) { ... error ... }
 * 
 * // Resolve the identity to a user.
 * err = vas_pkcs11_set_identity(ctx, pkcs11, &id);
 * if (err != VAS_ERR_SUCCESS) { ... error ... }
 * 
 * if (id == NULL) {
 *   printf("no identity available on token\n");
 * }
 * else {
 *   printf("using an identity\n");
 * }
 *
 * </code>
 *
 * @param ctx the initialized VAS context. Must not be NULL.
 *
 * @param pkcs11 the initialized PKCS#11 context. Must not be NULL.
 *
 * @param p_upn pointer to hold the UPN of the current identity. Must not be
 * NULL. The value returned in this pointer must be freed by calling free().
 * If there are no identities on the token, the value returned shall be NULL.
 *
 * @return VAS_ERR_SUCCESS if an active identity exists on the token, and the
 * vas_id_t has been obtained; or if there are no identities on 
 * the token, and NULL has been returned.
 *
 * @return VAS_ERR_PKCS11 if a PKCS#11 error occurred.
 *
 * @return VAS_ERR_NO_MEMORY if a memory error occurred.
 *
 * @return VAS_ERR_INTERNAL for internal errors.
 *
 * @return VAS_ERR_KRB5 for a Kerberos specific error
 *
 * @return VAS_ERR_INVALID_PARAM if an invalid parameter was passed
 *
 * @return VAS_ERR_CONFIG if unable to determine default_realm.
 */
vas_err_t vas_pkcs11_resolve_identity(vas_pkcs11_t *pkcs11,
                                      char **p_upn);

/**@defgroup constants for specifying identity properties */
/*@{*/

typedef enum vas_pkcs11_identity_properties
{
    VAS_PKCS11_IDENTITY_PROP_UPN                    = 0,
    VAS_PKCS11_IDENTITY_PROP_ISSUER                 = 1,
    VAS_PKCS11_IDENTITY_PROP_SUBJECT                = 2,
    VAS_PKCS11_IDENTITY_PROP_SERIAL_NUMBER          = 3,
    VAS_PKCS11_IDENTITY_PROP_NOT_BEFORE             = 4,
    VAS_PKCS11_IDENTITY_PROP_NOT_AFTER              = 5,
    VAS_PKCS11_IDENTITY_PROP_SIGNATURE_ALGORITHM    = 6,
    VAS_PKCS11_IDENTITY_PROP_KEY_ALGORITHM          = 7,
    VAS_PKCS11_IDENTITY_PROP_KEY_USAGE              = 8,
    VAS_PKCS11_IDENTITY_PROP_EXTENDED_KEY_USAGE     = 9,
    VAS_PKCS11_IDENTITY_PROP_SUBJECT_KEY_IDENTIFIER = 10,
    VAS_PKCS11_IDENTITY_PROP_CRL                    = 11,
    VAS_PKCS11_IDENTITY_PROP_RFC822                 = 12,
    VAS_PKCS11_IDENTITY_PROP_SHA1                   = 13,
    VAS_PKCS11_IDENTITY_PROP_INVALID                = 14  /* Must be kept at the end */
} vas_pkcs11_identity_properties_t;

/*}@*/

/** Get the string representation of a property of an identity. This may be
 * used to provide informative descriptions of the identity.
 *
 * The following properties (and the strings the represent) are defined:
 * <ul>
 * <li>::VAS_PKCS11_IDENTITY_PROP_UPN -- the UPN of the identity</li>
 * <li>::VAS_PKCS11_IDENTITY_PROP_SUBJECT -- the string representation of the
 *     subject DN contained in the identity's certificate, i.e., 
 *     "/DC=foo/DC=bar/CN=Users/CN=joe"</li>
 * <li>::VAS_PKCS11_IDENTITY_PROP_ISSUER -- the string representation of the
 *     issuer DN contained inthe identity's certificate, i.e., 
 *     "/DC=foo/DC=bar/CN=ca"</li>
 * <li>::VAS_PKCS11_IDENTITY_PROP_SERIAL_NUMBER - the string representation of
 *     the serial number contained in the identity's certificate, i.e.,
 *     "61131EA7000000000009"</li>
 * <li>::VAS_PKCS11_IDENTITY_PROP_NOT_BEFORE -- the string representation of
 *     the starting validity date contained in the identity's certificate,
 *     i.e., "Mar 23 03:08:24 2006 GMT"</li>
 * <li>::VAS_PKCS11_IDENTITY_PROP_NOT_AFTER -- the string representation of 
 *     the ending validity date contained in the identity's certificate,
 *     i.e., "Mar 23 03:08:24 2007 GMT"</li>
 * <li>::VAS_PKCS11_IDENTITY_PROP_SIGNATURE_ALGORITHM -- the string 
 *     representation of the signature algorithm contained in the identity's
 *     certificate, i.e., "sha1WithRSAEncryption"</li>
 * <li>::VAS_PKCS11_IDENTITY_PROP_KEY_ALGORITH< -- the string representation 
 *     of the key algorithm contained in the identity's certificate, i.e.,
 *     "rsaEncryption"</li>
 *</ul>
 *
 * If successful, a newly-allocated string is returned representing the
 * property. This string must be freed by the caller.
 *
 * Example: get the issuer DN and subject DN of an identity
 * <code>
 * vas_pkcs11_t *pkcs11 = ...;
 * const char *upn = NULL;
 * const char *value = NULL;
 * vas_err_t err;
 *
 * // Get UPN of current identity
 * err = vas_pkcs11_get_identity(pkcs11, &upn);
 * if (err != VAS_ERR_SUCCESS) { ... error ... }
 * 
 * // Get string representation of the issuer DN
 * err = vas_pks11_identity_get_property(pkcs11, upn, 
 *                                       VAS_PKCS11_IDENTITY_PROP_ISSUER,
 *                                       &value);
 * if (err == VAS_ERR_SUCCESS) {
 *   printf("issuer = %s\n", value);
 *   free((void *) value);
 * }
 *
 * // Get string representation of the subject DN
 * err = vas_pks11_identity_get_property(pkcs11, upn, "subject", &value);
 * if (err == VAS_ERR_SUCCESS) {
 *   printf("subject = %s\n", value);
 *   free((void *) value);
 * }
 * </code>
 *
 * @param pkcs11 the initialized PKCS#11 context. Must not be NULL.
 *
 * @param upn the UPN of the identity. Must not be NULL.
 *
 * @param property the name of the required property. Must not be NULL.
 *
 * @param p_value pointer to hold a newly-allocated string representing the
 * the property. Must not be NULL. This string must be freed by the caller.
 *
 * @return VAS_ERR_SUCCESS if a value for the property was obtained and a
 * string was returned in *p_value. 
 *
 * @return VAS_ERR_FAILURE if the property does not exist, or if no value 
 * could be found for the property.
 *
 * @return VAS_ERR_PKCS11 if a PKCS#11 error occurred obtaining the identity
 * information.
 *
 * @return VAS_ERR_NO_MEMORY if a memory error occurred.
 */
vas_err_t vas_pkcs11_get_identity_property(vas_pkcs11_t *pkcs11,
                                           const char *upn,
                                           vas_pkcs11_identity_properties_t property,
                                           char const **p_value);

/** Get the string representation of a property of an identity. This may be
 *  useful when one fails to easily identify which one failed in an error
 *  message.
 *
 * If successful, a newly-allocated string is returned representing the
 * name of the property. This string must be freed by the caller.
 *
 * @param property the name of the required property. Must not be NULL.
 *
 * @param p_value pointer to hold a newly-allocated string representing the
 * name of the property. Must not be NULL. This string must be freed by the
 * caller.
 *
 * @return VAS_ERR_SUCCESS if the name for the property was obtained and a
 * string was returned in *p_value. 
 *
 * @return VAS_ERR_FAILURE if the property does not exist, or if no name 
 * could be found for the property.
 *
 * @return VAS_ERR_NO_MEMORY if a memory error occurred.
 */
vas_err_t vas_pkcs11_get_identity_property_name(vas_pkcs11_identity_properties_t property,
                                                char const **p_value);

/** Generate a signature using the current PKCS#11 identity of the token.
 *
 * A PKCS#11 identity is represented by a private key/certificate pair 
 * on the token. The certificate must contain a UPN. Typically, the token
 * shall contain exactly one such private key/certificate pair, and this
 * 'identity' shall be selected by default. However, if there is more than
 * one identity on the token, the identity may change through calls to 
 * the vas_pkcs11_set_identity() function.
 *
 * The signature generated shall use the signature algorithm specified in 
 * the X.509 certificate of the identity. Typically, this shall be 
 * rsaWithSHA1 or rsaWithMD5. Note that only RSA signing operations are
 * supported with the current release.
 *
 * An estimate of the length of the signature may be obtained by passing
 * a NULL value for the signature buffer. The estimate returned shall be
 * at least as large as the number of bytes in the signature to be 
 * generated.
 *
 * Otherwise, if a signature is required, then the length of the signature
 * buffer is required on entry. On exit, the exact length of the generated
 * signature is returned.
 *
 * Example:
 * <code>
 * vas_pkcs11_t *pkcs11 = ...;
 * const char *message = "this is a message to sign";
 * int message_len = strlen(message);
 * void *signature = NULL;
 * int signature_len;
 * vas_err_t err;
 * 
 * // Get an estimate of the length of the signature.
 * err = vas_pkcs11_sign(pkcs11, NULL, 0, NULL, &signature_len);
 * if (err != VAS_ERR_SUCCESS) { ... error ... }
 *
 * // Allocate signature buffer 
 * signature = malloc(signature_len);
 * if (signature == NULL) { ... error ... }
 *
 * // Generate a signature 
 * err = vas_pkcs11_sign(pkcs11, message, message_len, 
 *                               signature, &signature_len);
 * if (err != VAS_ERR_SUCCESS) { ... error ... }
 * 
 * printf("Generated a signure of length %d bytes\n", signature_len);
 *
 * // Now verify the signature
 * err = vas_pkcs11_verify(pkcs11, message, message_len,
 *                         signature, signature_len);
 * printf("signature verification: %s\n",
 *        (err == VAS_ERR_SUCCESS) ? "passed" : "failed");
 * </code>
 *
 * @param pkcs11 the initialized PKCS#11 context. Must not be NULL.
 *
 * @param message_buf the message to be signed. May be NULL if message_len
 * is zero.
 *
 * @param message_len the length of the message tro be signed.
 *
 * @param the buffer to hold the generated signature. May be NULL if an 
 * estimate of the signature length is required.
 *
 * @param p_signature_len pointer to hold the length of the signature. Must
 * not be NULL. If signature_buf is NULL, then on return this value shall 
 * hold an estimate of the length of the generated signature. If signature_buf
 * is non-NULL, then on entry this value holds the length of the buffer, and
 * on exit holds the exact signature length.
 *
 * @return VAS_ERR_SUCCESS if the signature length was estimated, or if the 
 * signature was generated successfully. 
 *
 * @return VAS_ERR_FAILURE if the signature buffer is too small to hold the
 * generated signature, or if no identity can be found on the token, or if 
 * an error occurred generating the signature.
 *
 * @return VAS_ERR_PKCS11 if a PKCS#11 error occurred while generating the
 * signature.
 */
vas_err_t vas_pkcs11_sign(vas_pkcs11_t *pkcs11,
                          const void *message_buf,
                          int message_len,
                          void *signature_buf,
                          int *p_signature_len);

/** Verify a signature using the current PKCS#11 identity of the token.
 *
 * The signature must have been geenrated using the same PCKS#11 identity
 * as the current PKCS#11 identity of the token. 
 *
 * See vas_pkcs11_sign for an example.
 *
 * @param pkcs11 the initialized PKCS#11 context. Must not be NULL.
 *
 * @param message_buf the message that was used to create the signature. May 
 * be NULL if message_leN is zero.
 *
 * @param message_len the length of the message that was signed.
 *
 * @param the signature generated from the message. May be NULL iff signature_len
 * is zero.
 *
 * @param signature_len the length in bytes of the generated signature.
 *
 * @return VAS_ERR_SUCCESS if the signature is verified.
 *
 * @return VAS_ERR_FAILURE if the signature could not be verified; or a 
 * cryptographic error occurred while verifying the signature.
 * 
 * @return VAS_ERR_PCKS11 if a PKCS#11 erro occurred while verifying the
 * signature.
 */
vas_err_t vas_pkcs11_verify(vas_pkcs11_t *pkcs11,
                            const void *message_buf,
                            int message_len,
                            const void *signature_buf,
                            int signature_len);

/** Free a VAS PKCS#11 context 
 *
 * <p>This function shall release all resources held by the VAS PKCS#11
 * context, and delete the context itself. After this call, the VAS PKCS#11
 * context may not be used. 
 *
 * @param pkcs11 the VAS PKCS#11 context obtained via vas_pkcs11_alloc().
 */
void vas_pkcs11_free(vas_pkcs11_t *pkcs11);

#ifdef __cplusplus
}
#endif

#endif /* VAS_PKCS11_H */
