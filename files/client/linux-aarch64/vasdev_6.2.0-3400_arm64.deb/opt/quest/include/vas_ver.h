/**
 * Safeguard Authentication Services (SAS) API 
 * 
 * SAS API Version 4.0
 * 
 * Copyright 2025 One Identity LLC. ALL RIGHTS RESERVED.
 *
 * This header file is distributed as part of the Safeguard Authentication Services
 * (previously Vintela Authentication Services or VAS) 
 * distribution governed by the Safeguard Authentication Services (SAS) 
 * Software End User License Agreement (the "EULA"). This header 
 * file is part of the "Licensed Software" licensed to a Licensee 
 * under the EULA. The Licensee may use information learned from 
 * this file to develop software applications that use the libvas 
 * library as permitted by the EULA, and for no other  purpose. 
 * If you are not the Licensee under the EULA, then you 
 * do not have any license to use this file or any information 
 * in it.
 *
 */


/* NOTE:  This header file contains comment markups that are used with  
 *        the Doxygen (generated) documentation system
 */ 


/** @file 
 * Provides constants and functions to check the library version 
 *
 * NOTE: The library version is NOT the same thing as the product
 * version. The library version is used to identify the library 
 * interface, the product version is more of a marketing identifier. 
 *
 * The library version will only change when modifications affect the 
 * interface or the functionality available throughout the API. 
 */ 


#ifndef VAS_VER_H
#define VAS_VER_H

#ifdef __cplusplus
extern "C" {
#endif


/** The library major version number
 *
 * When the major version changes (in ex. from "3.0.0" to "4.0.0"), 
 * then backward compatibility with previous releases is not        
 * granted.                                                         
 */
#define VAS_API_VERSION_MAJOR 4

/** The library minor version number
 *
 * When the minor version changes (in ex. from "4.0.0" to "4.1.0),  
 * then backward compatibility with previous releases is granted,   
 * but something changed in the implementation (such as the         
 * addition of new functions, flags, options, etc ) 
 */
#define VAS_API_VERSION_MINOR 6

/** The library minor version number
 *
 * When the micro version changes (in ex. from "4.1.0" 4.1.1 ),     
 * then the changes are small forward compatible bug fixes or       
 * documentation modifications etc. 
 */
#define VAS_API_VERSION_MICRO 0

/** The full library version as a string constant */
#define VAS_API_VERSION_STR   "4.6.0"


/** Get the version of the API library being used.  Contrast with
 * the VAS_API_VERSION_XXX macros which represent the version of 
 * the API headers that were included during compilation.
 * 
 * @param major  pointer to integer that will be set to the value of major
 *               version number.  Parameter is ignored if the pointer is 
 *               NULL.
 * 
 * @param minor  pointer to integer that will be set to the value of minor
 *               version number.  Parameter is ignored if the pointer is 
 *               NULL.
 * 
 * @param micro  pointer to integer that will be set to the value of micro
 *               version number.  Parameter is ignored if the pointer is 
 *               NULL.
 * 
 * @return  Version string. The returned string must not be modified 
 *          or freed.   
 */
const char* vas_library_version( int* major, int* minor, int* micro );


/** Get the product version that the API library that (being used)
 * was shipped with.  This is usually a good indication of which 
 * Product is currently installed.
 * 
 * @param major  pointer to integer that will be set to the value of major
 *               version number.  Parameter is ignored if the pointer is 
 *               NULL.
 * 
 * @param minor  pointer to integer that will be set to the value of minor
 *               version number.  Parameter is ignored if the pointer is 
 *               NULL.
 * 
 * @param micro  pointer to integer that will be set to the value of micro
 *               version number.  Parameter is ignored if the pointer is 
 *               NULL.
 * 
 * @return  Version string. The returned string must not be modified 
 *          or freed.   
 */
const char* vas_product_version( int* major, int* minor, int* micro );


/** Checks that the API library in use is compatible with the given 
 * version. 
 * 
 * Normally you would pass in the constants VAS_API_VERSION_MAJOR, 
 * VAS_API_VERSION_MINOR, and VAS_API_VERSION_MICRO as the 
 * three argument; this will check that the library in use is compatible with 
 * the version of API that the application was compiled against. 
 * 
 * Library compatibility is defined by two things: first the version of the 
 * running library is the same or newer. Second, the running library must
 * be binary compatible (same major version.)
 * 
 * @param major  the major version 
 * 
 * @param minor  the minor version
 * 
 * @param micro  the micro version
 * 
 * @return  zero on success (specified version is compatible), non-zero on
 *          on failure (specified version is not compatible).
 */
int vas_library_version_check( int major, int minor, int micro );


#ifdef __cplusplus
}
#endif

#endif
