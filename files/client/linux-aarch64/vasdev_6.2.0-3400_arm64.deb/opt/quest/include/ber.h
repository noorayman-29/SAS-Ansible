/** 
 * Copyright 2006 Quest Software, Inc.  -  All Rights Reserved
 * 
 * This header file is distributed as part of the Vintela Authentication 
 * Services (VAS) distribution governed by the Vintela Authentication 
 * Services (VAS) Software End User License Agreement (the "EULA"). 
 * This header file is part of the "Licensed Software" licensed to a 
 * Licensee under the EULA.  The Licensee may use information learned 
 * from this file to develop software applications that use the libvas 
 * library of VAS as permitted by the EULA, and for no other purpose.  
 * If you are not the Licensee under the EULA, then you do not have any 
 * license to use this file or any information in it. 
 * 
 **/
 
/** @file
 * Codec for ASN.1 BER encoded data. In LDAP, requests and responses
 * are sent encoded as BER data.
 * 
 * A BER identifier is an 8 bit sequence constructed as follows:
 * 
 *  Bits 8-7 are the class. The following are the possible class values:
 *      0 0 = UNIVERSAL
 *      0 1 = APPLICATION
 *      1 0 = CONTEXT-SPECIFIC
 *      1 1 = PRIVATE
 * 
 *  Bit 6 is the data type. The following are the possible data type values:
 *      0 = PRIMITIVE
 *      1 = CONSTRUCTED
 * 
 *  Bits 5-1 represent the tag number.
 * 
 * 
 **/


#ifndef BER_H_INCLUDED
#define BER_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#ifndef NO_VAS_SYM_FIXING
#include <vas_symbols/ber_sym.h> /* the symbol fixing header */
#endif

#include <krb5-types.h> /* to ensure u_int32_t is defined */


/** mask for the BER class. */
#define BER_CLASS_MASK          ((ber_tag_t) 0xc0U)

/** Mask for the encoding type. */
#define BER_ENCODING_MASK       ((ber_tag_t) 0x20U)

/** Mask for the BER identifier tag. */
#define BER_BIG_TAG_MASK        ((ber_tag_t) 0x1fU)

/** Mask for larger tags. */
#define BER_MORE_TAG_MASK       ((ber_tag_t) 0x80U)

/** Universal data type. */
#define BER_CLASS_UNIVERSAL     ((ber_tag_t) 0x00U)

/** Application specific data type. */
#define BER_CLASS_APPLICATION   ((ber_tag_t) 0x40U)

/** Context specific data type. */
#define BER_CLASS_CONTEXT       ((ber_tag_t) 0x80U)

/** Private data type. */
#define BER_CLASS_PRIVATE       ((ber_tag_t) 0xc0U)

/** Primitive data type value. */
#define BER_PRIMITIVE           ((ber_tag_t) 0x00U)

/** Constructed data type value. */
#define BER_CONSTRUCTED         ((ber_tag_t) 0x20U)


/* general BER types we know about */
/** The boolean type. */
#define BER_BOOLEAN     ((ber_tag_t) 0x01UL)

/** The integer type. */
#define BER_INTEGER     ((ber_tag_t) 0x02UL)

/** The bit string type. */
#define BER_BITSTRING   ((ber_tag_t) 0x03UL)

/** The octet string type. */
#define BER_OCTETSTRING ((ber_tag_t) 0x04UL)

/** The NULL type. */
#define BER_NULL        ((ber_tag_t) 0x05UL)

/** An enumerated type. */
#define BER_ENUMERATED  ((ber_tag_t) 0x0aUL)

/** The sequence type, which is a constructed data type. */
#define BER_SEQUENCE    ((ber_tag_t) 0x30UL)

/** The set type, which is a constructed data type. */
#define BER_SET         ((ber_tag_t) 0x31UL)


/** BerElement option to encode lengths in the minimum number of octects. */
#define BER_USE_DER     0x01
#define LBER_USE_DER	BER_USE_DER

/* The intent is that BER_ERROR and BER_DEFAULT are both defined as the
 * integer value that has all bits set to 1, as such a value is not a valid
 * BER tag 
 */
/** A BER error where all bits are set to 1, which is not a valid BER tag. */
#define BER_ERROR       ((ber_tag_t)-1)
#define LBER_ERROR	    BER_ERROR

/** An invalid BER tag where all bits are set to 1. */
#define BER_DEFAULT     ((ber_tag_t)-1)
#define LBER_DEFAULT	BER_DEFAULT
  
/** Determine if the given BER Tag is valid. */
#define BER_INVALID(t)  \
    (((t) & (ber_tag_t) 0x080UL) && (((t) & (ber_tag_t) ~ 0x0FF))

/** An unsigned type that must be at least 32 bits wide but no larger
 * than the width of an 'unsigned long'. This represents the largest
 * piece of data supported by this ber implementation. */
typedef u_int32_t ber_len_t;

/** A signed type that must be at least 32 bits wide but no larger
 * than the width of an 'unsigned long'. */
typedef int32_t   ber_slen_t;

/** Type for BER tags. */
typedef u_int32_t ber_tag_t;   /* for BER tags */

/** Type for BER integers, enum values, and Boolean values. */
typedef int32_t   ber_int_t;   /* for BER ints, enums, and Booleans */

/** Unsigned type for BER integers. */
typedef u_int32_t ber_uint_t;  /* unsigned equivalent of ber_int_t */


/** Opaque data type that holds state information about encoded data. */
typedef struct berelement BerElement;


/** Structure that represents arbitrary binary BER data. */
typedef struct berval 
{
    ber_len_t   bv_len; /**< The length of bv_val, in bytes. */
    char*       bv_val; /**< The actual BER data. */
} BerValue;


/** An array of BerValue structures. */
typedef BerValue* BerVarray;


/** Free a BER Value.
 * Both the berval structure members will be freed, as will the bv pointer
 * itself.
 *
 * @param   bv  A pointer to a berval structure. 
 * 
 * @return      No return value.
 **/
void ber_bvfree( struct berval* bv );


/** Free an array of berval structures.
 * Each berval structure is freed, as is the array itself.
 *
 * @param bv    The BerValue array to free.
 * @param       No return value.
 **/
void ber_bvecfree( struct berval** bv );


/** Create a deep copy of a berval structure.
 *
 * @param   bv  The berval structure to copy
 * @return      A pointer to the copy, or NULL on error.
 **/
BerValue* ber_bvdup( const struct berval* bv );


/** Free a BerElement structure.
 *
 * @param   ber     Pointer to the BerElement to free.
 * @param   fbuf    If set to 1, the internal buffer will be freed. THIS
 *                  SHOULD always be set to 1.
 * 
 * @return          No return value.
 **/
void ber_free( BerElement* ber, int fbuf );


/** Allocate a new BerElement structure.
 * 
 * @param options   A bitwise-or of options to use when generating the
 *                  BerElement encoding. BER_USE_DER should always be
 *                  used.
 * 
 * @return          A pointer to the allocated BerElement, or NULL on
 *                  an error.
 **/
BerElement* ber_alloc_t( int options );


/** Allocate a berval structure from a BerElement where the berval
 * contents are BER encoded from the BerElement.
 * 
 * @param   ber     The BerElement to flatten.
 * @param   bvPtr   Address of a berval struct pointer that will be 
 *                  allocated. This should be freed using ber_bvfree().
 * 
 * @return  0 on success, and -1 on an error.
 **/
int ber_flatten( BerElement* ber, struct berval** bvPtr );


/** Allocate a BerElement from the berval struct.
 * 
 * @param   bv  The berval struct to create a BerElement from.
 * @return      A BerElement pointer, or NULL on an error.
 * 
 **/
BerElement* ber_init( const struct berval* bv );


/** Encode a BER element.
 * ber_printf() works similarly to sprintf() to encode a BER element.
 * 
 * @param   ber     Pointer to a valid BerElement structure.
 * @param   format  The BER format string.
 * @param   ...     Variable argument list for the format string.
 * 
 * @return  A non-negative number on success, and -1 on an error.
 **/
int ber_printf( BerElement* ber, const char* format, ... );


/** Decode a BER element.
 * ber_scanf() works much the same way as sscanf() works to decode
 * data in a BERElement.
 * 
 * @param   ber     Pointer to a valid BerElement structure that is read.
 * @param   format  The format string that specifies what to read.
 * @param   ...     Variable argument list to be read into.
 * 
 * @return  BER_ERROR on error, other value for success.
 **/
ber_tag_t ber_scanf( BerElement* ber, const char* fmt, ... );


/** Return the next element's tag. 
 * The decoding state of the BerElement is unchanged.
 * 
 * @param ber       The BerElement to be read.
 * @param lenPtr    Address of a length variable that will be
 *                  set to the length of the next element.
 * 
 * @return  BER_DEFAULT if no further data is available to read, or
 *          the tag of the next element.
 **/
ber_tag_t ber_peek_tag( BerElement* ber, ber_len_t* lenPtr );


/** Return the next element's tag, and skip it in the parse state.
 * This function acts just like ber_peek_tag(), except the internal
 * parsing state is changed.
 * 
 * @param   ber     The BerElement to read.
 * @param   lenPtr  Address of a length variable that will be
 *                  set to the length of the next element.
 * 
 * @return  BER_DEFAULT if there is no more data to read, or the tag
 *          of the next element.
 **/
ber_tag_t ber_skip_tag( BerElement* ber, ber_len_t* lenPtr );


/** Get the first element in a constructed type like a SET.
 * The opaquePtr and lenPtr should only be used to pass data onto 
 * ber_next_element().
 * 
 * @param   ber         The BerElement to read.
 * @param   lenPtr      Pointer to hold the length of the skipped element.
 * @param   opaquePtr   Address to track position.
 * 
 * @return  BER_DEFAULT if there is no more data to read, or the tag
 *          of the first element.
 **/
ber_tag_t ber_first_element( BerElement* ber, 
                             ber_len_t* lenPtr, 
                             char** opaquePtr );


/** Get the next element in a constructed type like a SET.
 * * The opaquePtr and lenPtr should only be used to pass data to 
 * subsequent calls to ber_next_element().
 * 
 * @param ber       The BerElement to read.
 * @param lenPtr    Pointer to hold the length of the skipped element.
 * @param opaque    Address to track position.
 * 
 * @return  BER_DEFAULT if there is no more data to read, or the tag
 *          of the next element.
 **/
ber_tag_t ber_next_element( BerElement* ber, 
                            ber_len_t* lenPtr, 
                            char* opaque );


/** Added from the 2.38 version */
#define STRLENOF(s)       (sizeof(s)-1)
#define ber_bvcmp(v1,v2) \
	((v1)->bv_len < (v2)->bv_len \
		? -1 : ((v1)->bv_len > (v2)->bv_len \
			? 1 : memcmp((v1)->bv_val, (v2)->bv_val, (v1)->bv_len) ))

#define ber_bvstrcasecmp(v1,v2) \
	((v1)->bv_len < (v2)->bv_len \
		? -1 : ((v1)->bv_len > (v2)->bv_len \
			? 1 : strncasecmp((v1)->bv_val, (v2)->bv_val, (v1)->bv_len) ))

#define BER_BVISNULL(bv)	((bv)->bv_val == NULL)
#define BER_BVC(s)		{ STRLENOF(s), (s) }
#define BER_BVNULL		{ 0L, NULL }
#define BER_BVZERO(bv) \
    do { \
        (bv)->bv_len = 0; \
        (bv)->bv_val = NULL; \
    } while( 0 )


/** Allocate a chunk of memory.
 * 
 * @param s         Size of the memory to allocate
 * @param ctx       Internal memory handler context. Not USED
 * 
 * @return          Ptr to memory allocated, or NULL on error.  The allocated
 *                  memory should be freed by the caller by calling
 *                  ber_memfree().
 *         
 **/
extern void *ber_memalloc_x( ber_len_t s, void *ctx );

/** Allocate a chunk of memory.
 * 
 * @param s         Size of the memory to allocate
 *
 * @return          Ptr to memory allocated, or NULL on error.  The allocated
 *                  memory should be freed by the caller by calling
 *                  ber_memfree().
 *         
 **/
extern void *ber_memalloc( ber_len_t s );

/** Allocate a chunk of memory, and zero it out.
 *
 * @param   n       Number of blocks to allocate
 * @param   s       Size of each block to allocate
 * @param   ctx     Internal memory handler context. Not USED.
 *
 * @return          Ptr to zero'd dynamically allocated memory, or NULL.
 *                  This memory needs to be freed by the caller by calling
 *                  ber_memfree().
 **/
extern void *ber_memcalloc_x( ber_len_t n, ber_len_t s, void *ctx );

/** Allocate a chunk of memory, and zero it out.
 *
 * @param   n       Number of blocks to allocate
 * @param   s       Size of each block to allocate
 *
 * @return          Ptr to zero'd dynamically allocated memory, or NULL.
 *                  This memory needs to be freed by the caller by calling
 *                  ber_memfree().
 **/
extern void *ber_memcalloc( ber_len_t n, ber_len_t s );

/** Duplicate a block of character(string) memory
 *
 * @param   s       Ptr of the string to duplicate
 * @param   ctx     Internal memory handler context. Not USED.
 *
 * @return          Ptr to allocated memory, or NULL on error.  The allocated
 *                  memory should be freed by the caller by calling
 *                  ber_memfree().
 **/
extern char *ber_strdup_x( const char *s, void *ctx );

/** Duplicate a block of character(string) memory
 *
 * @param   s       Ptr of the string to duplicate
 *
 * @return          Ptr to allocated memory, or NULL on error.  The allocated
 *                  memory should be freed by the caller by calling
 *                  ber_memfree().
 **/
extern char *ber_strdup( const char *s );

/** Free a block of dynamically allocated memory
 *
 * @param   p       Ptr to be freed
 * @param   ctx     Internal memory handler context. Not USED.
 *
 * @return          Nothing (void)
 **/
extern void ber_memfree_x( void *p, void *ctx );

/** Free a block of dynamically allocated memory
 *
 * @param   p       Ptr to be freed
 *
 * @return          Nothing (void)
 **/
extern void ber_memfree( void *p );


/** Duplicate an existing berval structure.
 *
 * @param   dst     Storage for the destination.  If NULL, then dynamically
 *                  allocated memory will be used.
 * @param   src     Berval structure to duplicate
 * @param   ctx     Internal memory handler context. Not USED.
 *
 * @returns         Ptr to a structure with duplicated values as the source.
 *                  If dst is non-null, then dst will be returned, otherwise
 *                  the address of a dynamically allocated structure, which 
 *                  will need to be freed by the caller by calling ber_bvfree().
 **/
extern BerValue *ber_dupbv_x( BerValue *dst, BerValue *src, void *ctx );

/** Duplicate an existing berval structure.
 *
 * @param   dst     Storage for the destination.  If NULL, then dynamically
 *                  allocated memory will be used.
 * @param   src     Berval structure to duplicate
 *
 * @returns         Ptr to a structure with duplicated values as the source.
 *                  If dst is non-null, then dst will be returned, otherwise
 *                  the address of a dynamically allocated structure, which 
 *                  will need to be freed by the caller by calling ber_bvfree().
 **/
extern BerValue *ber_dupbv( struct berval *dst, BerValue *src );

/** Reallocates a block of previously dynamically allocated memory.
 *
 * @param   p       Original block of memory to reallocate
 * @param   s       New size of memory buffer
 * @param   ctx     Internal memory handler context. Not USED.
 *
 * @returns         Address of reallocated memory, or NULL.  This memory
 *                  will need to freed by the caller through ber_memfree().
 **/
extern void *ber_memrealloc_x( void *p, ber_len_t s, void *ctx );

/** Reallocates a block of previously dynamically allocated memory.
 *
 * @param   p       Original block of memory to reallocate
 * @param   s       New size of memory buffer
 * @param   ctx     Internal memory handler context. Not USED.
 *
 * @returns         Address of reallocated memory, or NULL.  This memory
 *                  will need to freed by the caller through ber_memfree().
 **/
extern void *ber_memrealloc( void *p, ber_len_t s );

/** Utility function to convert a string to a berval structure.
 *
 * @param   s       String to add to the structures value member.
 * @param   len     Length of the string to set.
 * @param   dup     Flag to indicate if the the value should be dynamically
 *                  created or just use the address of s.
 * @param   bv      The berval structure to set.
 * @param   ctx     Internal memory handler context. Not USED.
 *
 * @returns         Ptr to the berval structure, or NULL on error.
 *                  If bv is non-null this address will be returned, otherwise
 *                  it will be an address to dynamically allocated memory which
 *                  will need to be freed by the caller through ber_bvfree().
 **/
extern BerValue *ber_str2bv_x( const char *s,
                               ber_len_t len,
                               int dup,
                               BerValue *bv,
                               void *ctx );

/** Utility function to convert a string to a berval structure.
 *
 * @param   s       String to add to the structures value member.
 * @param   len     Length of the string to set.
 * @param   dup     Flag to indicate if the the value should be dynamically
 *                  created or just use the address of s.
 * @param   bv      The berval structure to set.
 * @param   ctx     Internal memory handler context. Not USED.
 *
 * @returns         Ptr to the berval structure, or NULL on error.
 *                  If bv is non-null this address will be returned, otherwise
 *                  it will be an address to dynamically allocated memory which
 *                  will need to be freed by the caller through ber_bvfree().
 **/
extern BerValue *ber_str2bv( const char *s,
                             ber_len_t len,
                             int dup,
                             BerValue *bv );


#ifdef __cplusplus
}
#endif

#endif /*BER_H_INCLUDED*/
