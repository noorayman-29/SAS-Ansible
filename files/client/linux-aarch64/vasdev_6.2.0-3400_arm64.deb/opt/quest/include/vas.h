/**
 * Quest Authentication Services (QAS) API
 *
 * QAS API Version 4.0
 *
 * Copyright (c) 2010 Quest Software, Inc. All Rights Reserved.
 *
 * This header file is distributed as part of the Quest 
 * Authentication Services (previously Vintela Authentication 
 * Services or VAS) distribution governed by the Quest 
 * Authentication Services (QAS) Software End User License 
 * Agreement (the "EULA"). This header file is part of the 
 * "Licensed Software" licensed to a Licensee under the EULA. 
 * The Licensee may use information learned from this file to 
 * develop software applications that use the libvas library of 
 * QAS as permitted by the EULA, and for no other purpose. If 
 * you are not the Licensee under the EULA, then you do not have 
 * any license to use this file or any information in it. 
 *
 **/

/* NOTE:  This header file contains comment markups that are used with
 *        the Doxygen (generated) documentation system
 */


/** @file
 * Provides functions for interacting with Microsoft domain controllers
 * including Active Directory LDAP access, Kerberos authentication, and user
 * logon functionality.
 *
 * The QAS API provides simplified interfaces for using Kerberos
 * to authenticate against Active Directory, and using LDAP to 
 * access information. All of the complexity of discovering 
 * Active Directory domain controllers, LDAP SASL binds, 
 * processing LDAP results, and Kerberos/GSSAPI function calls 
 * are hidden from the caller. The LDAP and Kerberos version 5 
 * implementations are in libvas.so. There is no need to link in 
 * a separate LDAP or Kerberos library. This version of libvas 
 * is not binary compatible with the libvas from the QAS 2.x 
 * product series. 
 *
 **/


#ifndef VASAPI_H_INCLUDED
#define VASAPI_H_INCLUDED

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif


/* Include version constants */
#include "vas_ver.h"



/****************************************************************************
 *                                                                          *
 *                        CONSTANTS AND FLAGS                               *
 *                                                                          *
 ****************************************************************************/


/** Credential cache is kept in memory (not in a file).
 * VAS_ID_FLAG_USE_MEMORY_CCACHE is useful in situations where a credential
 * cache should not outlive the process or whenever the
 * credentials should not be stored in the file credential cache for the
 * process owner. This flag may be used in calls to
 * vas_id_establish_cred_password() and vas_id_establish_cred_keytab().
 */
#define VAS_ID_FLAG_USE_MEMORY_CCACHE       (1 << 0)

/** Keep a copy of the password or keytab so that it can be used later.
 * For example, VAS_ID_FLAG_KEEP_COPY_OF_CRED is  useful when a daemon
 * needs to setuid() to a non-privileged user that no longer has access
 * to the keytab. The use of this flag affects the  behavior of the
 * following functions: vas_id_establish_cred_password()
 * vas_id_establish_cred_keytab(), vas_id_renew_cred().
 */
#define VAS_ID_FLAG_KEEP_COPY_OF_CRED       (1 << 1)

/** Use the default keytab name.
 * When calling vas_id_establish_cred_keytab() using a NULL keytab
 * argument, the keytab name is derived from the principal name.
 * Use VAS_ID_FLAG_DO_NOT_DERIVE_KEYTAB to force use of the default
 * keytab (usually /etc/opt/quest/vas/host.keytab).
 */
#define VAS_ID_FLAG_DO_NOT_DERIVE_KEYTAB    (1 << 2)

/** Do not request a TGT.
 * Used in server applications that only need to validate service tickets
 * using a keytab. When passed as a flag to vas_id_establish_cred_keytab()
 * the ::vas_id_t will be associated with a keytab with out the overhead of
 * requesting a TGT.
 */
#define VAS_ID_FLAG_NO_INITIAL_TGT          (1 << 3)

/** Request renewable tickets.
 * This flag may be used in calls to vas_id_establish_cred_password()
 * and vas_id_establish_cred_keytab().
 */
#define VAS_ID_CRED_FLAG_RENEWABLE          (1 << 4)

/** Normally, the credential cache is expected to be in a file with a filename
 * derived from the UID of the current process owner (as returned by geteuid().
 * Using the VAS_ID_FLAG_DERIVE_FILE_CCACHE_FROM_ID when making
 * calls to vas_id_establish_cred_xxx functions, will cause the credential
 * cache filename to be derived using the vas_id_t. For example, if a vas_id_t
 * called "billvasid", is allocated for a user named "bill" and bill's Unix
 * UID is 1000, calls to vas_id_establish_cred_xxx functions using billvasid,
 * will use /tmp/krb5cc_1000 as the file credential cache name.
 */
#define VAS_ID_FLAG_DERIVE_FILE_CCACHE_FROM_ID (1 << 5)

/** VAS preloads the preauthentication data to avoid unnecessary round trips
 * since Windows DC's usually require preauthentication. This flag will disable
 * the preloading of the preauthentication. This avoids issues where the
 * preloaded data's salt is incorrect for AES/DES etypes because of a mismatched
 * case on usernames, which will trigger a KRB5KDC_ERR_PREAUTH_FAILED.
 */
#define VAS_ID_FLAG_NO_INITIAL_PRELOAD (1 << 6)

/** Disable attaching FAST armor credentials before requesting TGT.
 */
#define VAS_ID_FLAG_DISABLE_FAST (1 << 7)

/** Do not use cached information when resolving identity names.
 * May be used in calls to vas_name_to_dn().
 */
#define VAS_NAME_FLAG_NO_CACHE              (1 << 0)

/** Do not use LDAP when resolving identity names.
 * May be used in calls to vas_name_to_dn().
 */
#define VAS_NAME_FLAG_NO_LDAP               (1 << 1)

/** Do not expand the Microsoft implicit principal name.
 * May be used in calls to vas_name_to_principal().
 */
#define VAS_NAME_FLAG_NO_IMPLICIT           (1 << 2)

/** Do not expand host names to fully qualified domain names.
 * May be used in calls to vas_name_to_principal().
 */
#define VAS_NAME_FLAG_NO_DNS_EXPAND         (1 << 3)

/** Search the entire forest for missing domain name components.
 * By default only the current domain will be searched. May be used in
 * calls to vas_name_to_dn().
 */
#define VAS_NAME_FLAG_FOREST_SCOPE          (1 << 4)

/** Do not search for dNSHostName when resolving host name to dn.
 * Default is to use dNSHostName in the query. This can be set
 * to increase resolution speed, as dNSHostName is not often indexed,
 * ddcreesing the query speed.
 */
#define VAS_NAME_FLAG_HOST_NO_DNS_QUERY     (1 << 5)

/****************************************************************************
 *                                                                          *
 *                        ENUMERATED TYPES                                  *
 *                                                                          *
 ****************************************************************************/

/** vas_err_t error codes
 * Nearly all QAS API functions return a vas_err_t type. More information about
 * the specific QAS error conditions that may result can be found in the
 * documentation for each QAS API function.
 **/
typedef enum vas_err
{
    VAS_ERR_BAD_ERR         = -1,
    VAS_ERR_SUCCESS         =  0,
    VAS_ERR_FAILURE         =  1,
    VAS_ERR_KRB5            =  2,
    VAS_ERR_KPASSWD         =  3,
    VAS_ERR_LDAP            =  4,
    VAS_ERR_INVALID_PARAM   =  5,
    VAS_ERR_NO_MEMORY       =  6,
    VAS_ERR_ACCESS          =  7,
    VAS_ERR_NOT_FOUND       =  8,
    VAS_ERR_THREAD          =  9,
    VAS_ERR_CONFIG          =  10,
    VAS_ERR_INTERNAL        =  11,
    VAS_ERR_EXISTS          =  12,
    VAS_ERR_DNS             =  13,
    VAS_ERR_CRED_EXPIRED    =  14,
    VAS_ERR_CRED_NEEDED     =  15,
    VAS_ERR_MORE_VALS       =  16,
    VAS_ERR_TIMEDOUT        =  17,
    VAS_ERR_INCOMPLETE      =  18,
    VAS_ERR_PKCS11          =  19,
    VAS_ERR_NOT_IMPLEMENTED =  20,
    VAS_ERR_SYS             =  21,
    VAS_ERR_NOT_CONNECTED   =  22
} vas_err_t;


/** Enumerates the types of errors that can be described by an
 * vas_err_info_t.
 **/
typedef enum vas_err_type
{
   VAS_ERR_TYPE_VAS     = 1,    /* QAS Specific errors */
   VAS_ERR_TYPE_SYS     = 2,    /* System errors */
   VAS_ERR_TYPE_KRB5    = 3,    /* Kerberos errors */
   VAS_ERR_TYPE_KPASSWD = 4,    /* Kerberos passwd protocol errors */
   VAS_ERR_TYPE_LDAP    = 5,    /* LDAP errors */
   VAS_ERR_TYPE_PKCS11  = 6     /* PKCS#11 errors */
} vas_err_type_t;


/** Enumeration of options, some of which may be passed when calling
 * vas_ctx_get_option() and vas_ctx_set_option().
 *
 * @see vas_ctx_get_option(), vas_ctx_set_option()
 **/
typedef enum vas_ctx_opt
{
    VAS_CTX_OPTION_DEFAULT_REALM                     =  1,
    VAS_CTX_OPTION_SITE_AND_FOREST_ROOT              =  2,
    VAS_CTX_OPTION_ADD_SERVER                        =  3,
    VAS_CTX_OPTION_USE_TCP_ONLY                      =  4,
    VAS_CTX_OPTION_USE_GSSAPI_AUTHZ                  =  5,
    VAS_CTX_OPTION_USE_SRVINFO_CACHE                 =  6,
    VAS_CTX_OPTION_USE_DNSSRV                        =  7,
    VAS_CTX_OPTION_USE_VASCACHE                      =  8,
    VAS_CTX_OPTION_USE_VASCACHE_IPC                  =  9,
    VAS_CTX_OPTION_USE_SERVER_REFERRALS              =  10,
    VAS_CTX_OPTION_SEPARATOR_IN_ERROR_MESSAGE_STRING =  11,
    VAS_CTX_OPTION_SRVINFO_DETECT_ONLY_UNTIL_FOUND   =  12,
    VAS_CTX_OPTION_DNS_FAILURE_TIMELIMIT             =  13,
    VAS_CTX_OPTION_DOMAIN_NAMING_CONTEXT             =  14,
    VAS_CTX_OPTION_USE_SRVINFO_CONF                  =  15,
    VAS_CTX_OPTION_SRVINFO_LAZY_DETECT               =  16,
    VAS_CTX_OPTION_SRVINFO_DO_GC_FILL                =  17,
    VAS_CTX_OPTION_KPASSWD_USE_PDC                   =  18,
    VAS_CTX_OPTION_SITE_ONLY_SERVERS                 =  19,
    VAS_CTX_OPTION_TCP_TIMEOUT                       =  20,
    VAS_CTX_OPTION_SITE_USE_PSEUDO_SITE              =  21,
    VAS_CTX_OPTION_DEFAULT_TO_MEMORY_CCACHE          =  22,
    VAS_CTX_OPTION_SRVINFO_ALWAYS_PING               =  23,
    VAS_CTX_OPTION_GET_ALL_SERVERS                   =  24
} vas_ctx_opt_t;

/** Enumeration of options that may be passed when calling
 * vas_err_get_option() and vas_err_set_option().
 *
 * @see vas_err_get_option(), vas_err_set_option()
 **/
typedef enum vas_err_opt
{
    VAS_ERR_OPTION_NEST_ERRORS = 1
} vas_err_opt_t;


/** Enumeration of options that may be passed when calling
 * vas_attrs_get_option() and vas_attrs_set_option().
 *
 * @see vas_get_option(), vas_attrs_set_option()
 **/
typedef enum vas_attrs_opt
{
    VAS_ATTRS_OPTION_SEARCH_TIMEOUT     = 1,
    VAS_ATTRS_OPTION_LDAP_PAGESIZE      = 2,
    VAS_ATTRS_B64_ENCODE_ATTRS          = 3,
    VAS_ATTRS_SECURITY_DESCRIPTOR_FLAGS = 4
} vas_attrs_opt_t;

typedef enum vas_attrs_security_descriptor_flags
{
    VAS_ATTRS_SD_FLAG_NONE    = 0,
    VAS_ATTRS_SD_FLAG_OWNER   = 1,
    VAS_ATTRS_SD_FLAG_GROUP   = 2,
    VAS_ATTRS_SD_FLAG_DACL    = 4,
    VAS_ATTRS_SD_FLAG_SACL    = 8
} vas_attrs_security_descriptor_flags_t;


/** Server info types that may be used when calling vas_info_servers().
 */
typedef enum vas_srvinfo_type
{
    VAS_SRVINFO_TYPE_ANY = 0, /* Any server */
    VAS_SRVINFO_TYPE_DC  = 1, /* Microsoft domain controller */
    VAS_SRVINFO_TYPE_PDC = 2, /* Microsoft primary domain controller emulator */
    VAS_SRVINFO_TYPE_GC  = 3  /* Microsoft Active Directory global catalog */
} vas_srvinfo_type_t;


/** Enumerates the types of names that are used in and returned
 * from various QAS API calls. 
 **/
typedef enum vas_name_type
{
    VAS_NAME_TYPE_UNKNOWN = 0,
    VAS_NAME_TYPE_USER    = 1, /* A a pw_name or a Kerberos UPN */
    VAS_NAME_TYPE_GROUP   = 2, /* A gr_name */
    VAS_NAME_TYPE_SERVICE = 3, /* Kerberos SPN */
    VAS_NAME_TYPE_HOST    = 4, /* A DNS hostname */
    VAS_NAME_TYPE_DN      = 5, /* An LDAP distinguished name */
    VAS_NAME_TYPE_SID     = 6  /* A security identifier */
} vas_name_type_t;



/****************************************************************************
 *                                                                          *
 *                        STRUCTURAL TYPES                                  *
 *                                                                          *
 ****************************************************************************/

/** QAS error information type used to describe the details of an error
 * condition.
 *
 * Note: you should not access the message field of this structure directly.
 * Instead call vas_err_info_get_string() to retrieve a formatted error
 * message for a given vas_err_info_t.
 *
 * For more information see documentation about error handling
 * and error handling functions such as: vas_err_get_info().
 */
typedef struct vas_err_info
{
   int                  code;     /* Error code */
   vas_err_type_t       type;     /* Type of error */
   struct vas_err_info* cause;    /* Pointer to the cause */
   char*                message;  /* Error message string (*/
} vas_err_info_t;


/** The main QAS API context type
 *
 * Every call to QAS API requires the use of a vas_ctx_t. A 
 * vas_ctx_t is created with a call to vas_ctx_alloc() and 
 * destroyed with a call to vas_ctx_free(). For most programs it 
 * is usually sufficient to allocate one vas_ctx_t per process. 
 * When writing threaded applications, you should use one 
 * vas_ctx_t per thread. 
 *
 * The vas_ctx_t is opaque to the caller. The internal structure of a
 * vas_ctx_t is not documented and may change at any time. Developers
 * must not write code that makes assumptions about the size or internal
 * structure of a vas_ctx_t.
 **/
typedef struct vas_ctx vas_ctx_t;


/** The QAS identity type
 *
 * A vas_id_t represents an identity. A QAS identity is a 
 * Kerberos principal which could be a user, a service, or a 
 * computer. The vas_id_t also encapsulates credentials (such as 
 * a keytab, or credential cache) that may be associated with a 
 * security principal. 
 *
 * The vas_id_t is created by calling vas_id_alloc() and destroyed by
 * calling vas_id_free(). Credentials are associated with a vas_id_t by
 * calling vas_id_establish_cred_password() and
 * vas_id_establish_cred_keytab().
 *
 * The vas_id_t is opaque to the caller. The internal structure of the
 * vas_id_t type is not documented and may change at any time.
 * Developers must not write code that makes assumptions about the
 * size or internal structure of a vas_id_t.
 **/
typedef struct vas_id vas_id_t;


/** Abstraction for authentication data
 *
 * A vas_auth_t is created by a successful call to vas_auth() and
 * vas_auth_with_password() and destroyed by calling vas_auth_free().
 * A vas_auth_t contains authentication data (i.e. the Microsoft
 * PAC) that can be used by subsequent authorization calls such as
 * vas_auth_check_client_membership()
 *
 * The vas_auth_t is opaque to the caller. The internal structure of a
 * vas_auth_t is not documented and may change at any time. Developers
 * must not write code that makes assumptions about the size or internal
 * structure of a vas_auth_t.
 **/
typedef struct vas_auth vas_auth_t;


/** A vas_attrs_t is used to obtain attribute of objects in Active Directory.
 *
 * A vas_attrs_t is created by calling vas_attrs_alloc() and destroyed by
 * calling vas_attrs_free(). LDAP searches are performed by calling
 * vas_attrs_find() and vas_attrs_find_continue().
 *
 * The vas_attrs_t type is opaque to the caller. The internal structure of the
 * vas_attrs_t type is not documented and may change at any time.
 * Developers must not write code that makes assumptions about the
 * size or internal structure of a vas_attrs_t.
 **/
typedef struct vas_attrs vas_attrs_t;


/** Binary data returned by vas_vals_get_binary().
 * This struct holds the value for binary attributes that were requested from
 * the results of a vas_attrs_find() search. ::vas_vals_binary_t are freed
 * with a call to vas_vals_free_binary()
 **/
typedef struct vas_val_binary
{
    size_t  size;  /* The size of data */
    void*   data;  /* The binary data */
} vas_val_binary_t;


/**
 * The vas_user_t type is used to retrieve information about an
 * Active Directory user object.
 *
 * A vas_user_t is created by calling vas_user_init() and destroyed
 * by calling vas_user_free(). It is only possible to create a
 * vas_user_t for a user that already exists in Active Directory.
 * Attributes of the user object may be accessed by one or more function
 * calls, e.g. vas_user_get_dn() to return the distinguished name of the
 * user object.
 *
 * The vas_user_t type is opaque to the caller. The internal structure of
 * the vas_user_t type is not documented and may change at any time.
 * Developers must not write code that makes assumptions about the
 * size or internal structure of a vas_user_t.
 *
 * @see ::vas_group_t
 **/
typedef struct vas_user vas_user_t;

/**
 * The vas_group_t type is used to retrieve information about an
 * Active Directory group object.
 *
 * A vas_group_t is created by calling vas_group_init() and destroyed
 * by calling vas_group_free(). It is only possible to create a
 * vas_group_t for a group that already exists in Active Directory.
 * Attributes of the group object may be accessed by one or more function
 * calls, e.g. vas_group_get_dn() to return the distinguished name of the
 * group object.
 *
 * The vas_group_t type is opaque to the caller. The internal structure of
 * the vas_group_t type is not documented and may change at any time.
 * Developers must not write code that makes assumptions about the
 * size or internal structure of a vas_group_t.
 *
 * @see ::vas_user_t
 **/
typedef struct vas_group vas_group_t;

/**
 * The vas_computer_t type is used to retrieve information about an
 * Active Directory computer object.
 *
 * A vas_computer_t is created by calling vas_computer_init() and destroyed
 * by calling vas_computer_free(). It is only possible to create a
 * vas_computer_t that already exists in Active Directory. Attributes of
 * the computer object may be accessed by one or more function calls,
 * e.g. vas_computer_get_dn() to return the distinguished name of the
 * computer object.
 *
 * The vas_computer_t type is opaque to the caller. The internal structure of
 * the vas_computer_t type is not documented and may change at any time.
 * Developers must not write code that makes assumptions about the
 * size or internal structure of a vas_computer_t.
 *
 * @see ::vas_user_t, ::vas_service_t
 **/
typedef struct vas_computer vas_computer_t;

/**
 * The vas_service_t type is used to retrieve information about an
 * Active Directory service account object.
 *
 * A service account is a special user account created by QAS to
 * hold credentials for a Kerberized service (e.g. an HTTP 
 * server supporting Kerberos authentication). 
 *
 * A vas_service_t is created by calling vas_service_init() and destroyed
 * by calling vas_service_free(). It is only possible to create a
 * vas_service_t for a service account that already exists in Active
 * Directory. Attributes of the service account object may be accessed
 * by one or more function calls, e.g.: vas_service_get_spns() to return the
 * list of service principal names (SPNs) associated with this service
 * account.
 *
 * The vas_service_t type is opaque to the caller. The internal structure of
 * the vas_service_t type is not documented and may change at any time.
 * Developers must not write code that makes assumptions about the
 * size or internal structure of a vas_service_t.
 *
 * @see ::vas_user_t, ::vas_computer_t
 **/
typedef struct vas_service vas_service_t;



/****************************************************************************
 *                                                                          *
 *                          FORWARD DECLARATIONS                            *
 *                                                                          *
 ****************************************************************************/

/* Forward declaration of the standard passwd struct */
struct passwd;
struct group;


/****************************************************************************
 *                                                                          *
 *                        QAS CONTEXT FUNCTIONS                             *
 *                                                                          *
 ****************************************************************************/

/** Allocates and initializes a ::vas_ctx_t and returns an error structure which
 * contains the reason for failure when the return value is not ::VAS_ERR_SUCCESS.
 * Also, allow the use of controlling how certain internals of the ::vas_ctx_t are
 * allocated through the use of the ctx_flags parameter.
 *
 * @since VAS 4.1.0
 *
 * @param ctx       Set to point to memory allocated by the VAS library. The
 *                  resulting ::vas_ctx_t must be freed by calling
 *                  vas_ctx_free().  If vas_ctx_alloc() fails, the value
 *                  pointed at by ctx is undefined and must not be freed.
 *
 * @param errinfo   Set to point to memory allocated by the VAS library. Pass
 *                  the errorinfo to vas_err_info_get_string() to get the 
 *                  error message. ::vas_err_info_t must be freed by calling
 *                  vas_err_info_free(). 
 *                  If error information is not needed set to NULL.
 *
 * @param ctx_flags Variable that contains a bitmask of optional flags used
 *                  in the construction of the ::vas_ctx_t object. If no
 *                  flags are needed set to 0.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_KRB5            - Kerberos initialization failed
**/
vas_err_t vas_ctx_alloc_with_flags( vas_ctx_t **ctx,
                                    vas_err_info_t **errinfo,
                                    int ctx_flags );


/** Allocates and initializes a ::vas_ctx_t.
 *
 * Every call to the QAS API requires the use of a ::vas_ctx_t. For most
 * programs it is usually sufficient to allocate one ::vas_ctx_t per
 * process.
 *
 * @param ctx  Set to point to memory allocated by the QAS library. The
 *             resulting ::vas_ctx_t must be freed by calling vas_ctx_free().
 *             If vas_ctx_alloc() fails, the value pointed at by ctx is
 *             undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_KRB5            - Kerberos initialization failed
 **/
vas_err_t vas_ctx_alloc( vas_ctx_t** ctx );


/** Destroys and deallocates a ::vas_ctx_t
 *
 * @param ctx  The ::vas_ctx_t to be freed.
 *
 **/
void vas_ctx_free( vas_ctx_t* ctx );


/** Set options that change QAS environmental behavior. Some
 * operations should not be attempted (as noted). 
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param option    The option to set. The following options are defined:
 *                  - VAS_CTX_OPTION_DEFAULT_REALM - set the default realm
 *                    for this vas_ctx_t. The argument is a single char * realm
 *                    name string. Setting the default realm using
 *                    this option overrides the default_realm setting in
 *                    vas.conf or allows the QAS API to operate
 *                    without the default_realm setting in
 *                    vas.conf. 
 *                  - VAS_CTX_OPTION_SITE_AND_FOREST_ROOT - Specify the
 *                    site and forest root. The arguments are: char *site,
 *                    char *forest_root. Either argument may be NULL.
 *                  - VAS_CTX_OPTION_ADD_SERVER - Specify a server that will be
 *                    used for Kerberos and LDAP traffic. The arguments are:
 *                    char *host, char *domain, char *site,
 *                    ::vas_srvinfo_type_t *srvinfo. The DNS host name name is
 *                    required, domain and site may be NULL.
 *                  - VAS_CTX_OPTION_USE_SRVINFO_CACHE - Specify whether or
 *                    not to use the server information cache (maintained by
 *                    vasd) to locate domain controllers. The argument is:
 *                    a single int where 1 turns on use of srvinfo cache (the
 *                    usual vas.conf default) and 0 turns off use of srvinfo
 *                    cache.
 *                  - VAS_CTX_OPTION_USE_DNSSRV - Specify whether or not to use
 *                    DNS SRV lookups to locate domain controllers. The
 *                    argument is a single int where 1 turns on use of DNS
 *                    lookup (the usual vas.conf default) and 0, turns off use
 *                    of DNS lookup.
 *                  - VAS_CTX_OPTION_USE_TCP_ONLY - Specify the exclusive use
 *                    of TCP for communication with servers. The argument is a
 *                    single int value. If value is 1, the library will use TCP
 *                    only. If value is 0 the library will use UDP with
 *                    failover to TCP (the usual vas.conf default).
 *                  - VAS_CTX_OPTION_USE_GSSAPI_AUTHZ - Specify whether or not
 *                    authorization checking will occur for GSSAPI acceptors.
 *                    The argument is a single integer where 1 turns on
 *                    authorization checking and 0 (the usual vas.conf default)
 *                    turns it off.
 *                  - VAS_CTX_OPTION_USE_SERVER_REFERRALS - Specify whether or
 *                    not to use Kerberos server referrals. The argument is a
 *                    single integer where 1 turns on server referrals on
 *                    and 0 (the usual vas.conf default) turns it off.
 *                  - VAS_CTX_OPTION_SEPARATOR_IN_ERROR_MESSAGE_STRING -
 *                    Specify the string to be used to separate error message
 *                    phrases when printed or logged. The default is the
 *                    newline, but syslog will not accept that value which
 *                    truncates the string. With this option, the newline can
 *                    be changed to any string containing between 1 and 15
 *                    characters (null-terminated). A longer string passed to
 *                    this function will be truncated and no error will issue.
 *                  - VAS_CTX_OPTION_SRVINFO_DETECT_ONLY_UNTIL_FOUND - Setting
 *                    this option to 1 will ensure that any QAS API call that
 *                    does domain controller detection will stop and return
 *                    the necessary servers as soon as it finds them. Some API
 *                    calls (vas_info_servers for example) have a default
 *                    behavior which involves detecting ALL servers every time
 *                    it is called. This is especially unecessary on any
 *                    subsequent call of a function that performs detection as
 *                    the initial call will have stored the entire result set
 *                    of the server detection inside the QAS context handle.
 *                    Setting this option to zero will return any API call to
 *                    its default behavior.
 *                  - VAS_CTX_OPTION_DNS_FAILURE_TIMELIMIT - If this option is
 *                    to set to a value greater than 0, then the internal QAS
 *                    code that deals with DNS resolution will track how long
 *                    DNS failures take, and error out if any failures take
 *                    longer then the set amount of time. This setting is 0 by
 *                    default. This will be most useful for callers that need
 *                    to fail over to alternative forms of authentication
 *                    quickly if Active Directory is not reachable. The
 *                    supplied option must be a time_t value that specifies the
 *                    number of seconds after which DNS lookup attempts should
 *                    be abandoned.
 *                  - VAS_CTX_OPTION_USE_SRVINFO_CONF - Setting to control if
 *                    the QAS API should load srvinfo
 *                    information from the vas.conf file. This
 *                    is really only ever used in a bootstrap
 *                    scenario (i.e.: join) where there may be
 *                    an existing vas.conf that has srvinfo
 *                    specified, and the new join shouldn't use
 *                    them.
 *                  - VAS_CTX_OPTION_USE_VASCACHE - Int
 *                    (boolean) setting to control whether or
 *                    not the QAS API should look up items in
 *                    the cache (i.e.: misc entries, user/group
 *                    entries, etc.).
 *                  - VAS_CTX_OPTION_USE_VASCACHE_IPC - Int
 *                    (boolean) setting to control whether or
 *                    not the QAS API should send IPC requests
 *                    during user/group lookups. vasd should be
 *                    the only process that needs to set this
 *                    value.
 *                  - VAS_CTX_OPTION_SRVINFO_DETECT_ONLY_UNTIL_FOUND - The
 *                    argument is time_t. Setting used within the
 *                    QAS API when looking for server information. If one
 *                    server that matches the query is found, it will not
 *                    continue loading the srvinfo list with all available
 *                    servers.
 *                  - VAS_CTX_OPTION_DOMAIN_NAMING_CONTEXT - The arguments are
 *                    char *domain and char **value. Used to set the default
 *                    naming context for the given domain. This is mainly set
 *                    or retrieved from within the QAS API. If a
 *                    search base was not set and a domain was used,
 *                    vas_attrs_find() queries the default naming context for
 *                    the domain from the DC (or if stored in the ctx handle).
 *
 * @return          VAS_ERR_SUCCESS on success or one of the following error
 *                  codes:
 *                  - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed.
 *                  - VAS_ERR_NO_MEMORY       - Memory allocation failed.
 *
 * @code
 *
 * // EXAMPLE:
 * {
 *     ...
 *
 *     if( vas_ctx_set_option( ctx, VAS_CTX_OPTION_USE_SRVINFO_CACHE, 1 ) )
 *         fprintf( stderr, "Unable to set context option VAS_CTX_OPTION_USE_SRVINFO_CACHE!\n" );
 *
 *     if( vas_ctx_set_option( ctx, VAS_CTX_OPTION_SEPARATOR_IN_ERROR_MESSAGE_STRING, "\r\n" ) )
 *         fprintf( stderr, "Unable to prescribe separator to be used in syslog messages to \"\\r\\n\"!\n" );
 *     ...
 * }
 *
 * @endcode
 *
 **/
vas_err_t vas_ctx_set_option( vas_ctx_t* ctx, vas_ctx_opt_t option, ... );


/** Get options indicative of QAS environmental behavior. Some potential
 * options are missing (VAS_CTX_OPTION_ADD_SERVER,
 * VAS_CTX_OPTION_DEFAULT_REALM and
 * VAS_CTX_OPTION_SITE_AND_FOREST_ROOT) either because it doesn't make sense to
 * return them or other interfaces exist that better implement it including
 * vas_info_forest_root(), vas_info_site() and vas_info_joined_domain().
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param option    The option to get. See vas_ctx_set_option() for the meaning
 *                    of returned values in each of these cases. Just as for
 *                    vas_ctx_set_option(), the values for the following
 *                    options are returned as output arguments, pointers for
 *                    which the caller provides storage. The types are as
 *                    follows. Unless otherwise noted these take int *value
 *                    and the value returned is to be treated as Boolean (see
 *                    the sample code below).
 *                  - VAS_CTX_OPTION_USE_SRVINFO_CACHE
 *                  - VAS_CTX_OPTION_USE_DNSSRV
 *                  - VAS_CTX_OPTION_USE_TCP_ONLY
 *                  - VAS_CTX_OPTION_USE_GSSAPI_AUTHZ
 *                  - VAS_CTX_OPTION_USE_SERVER_REFERRALS
 *                  - VAS_CTX_OPTION_USE_SRVINFO_CONF
 *                  - VAS_CTX_OPTION_USE_VASCACHE
 *                  - VAS_CTX_OPTION_USE_VASCACHE_IPC
 *                  - VAS_CTX_OPTION_SRVINFO_DETECT_ONLY_UNTIL_FOUND
 *                  - VAS_CTX_OPTION_SEPARATOR_IN_ERROR_MESSAGE_STRING - The
 *                    argument is char *separator, pointing to storage at least
 *                    16 bytes. (This option is one rather more "set" than
 *                    "got.")
 *                  - VAS_CTX_OPTION_DNS_FAILURE_TIMELIMIT - The argument is
 *                    time_t *timeout pointing to a valid time_t variable.
 *                  - VAS_CTX_OPTION_DOMAIN_NAMING_CONTEXT - The arguments are
 *                    char *domain (input: name of domain) and char **value
 *                    (output argument).
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *
 * @code
 *
 * // EXAMPLE:
 * {
 *     int   use_srvinfo_cache = 0;
 *     char  errmsg_separator[16];
 *     ...
 *
 *     vas_ctx_get_option( ctx, VAS_CTX_OPTION_USE_SRVINFO_CACHE, &use_srvinfo_cache );
 *
 *     memset( errmsg_separator, '\0, sizeof( errmsg_separator ) );
 *
 *     vas_ctx_get_option( ctx, VAS_CTX_OPTION_SEPARATOR_IN_ERROR_MESSAGE_STRING, errmsg_separator );
 *
 *     ...
 *
 *     if( user_srvinfo_cache )
 *         ...
 * }
 *
 * @endcode
 *
 **/
vas_err_t vas_ctx_get_option( vas_ctx_t* ctx, vas_ctx_opt_t option, ... );



/****************************************************************************
 *                                                                          *
 *                     IDENTITY AND CREDENTIAL FUNCTIONS                    *
 *                                                                          *
 ****************************************************************************/

/** Allocates and initializes a ::vas_id_t
 *
 * A ::vas_id_t represents an identity. A QAS identity is a Kerberos
 * principal which could be a user, a service, or a computer.
 * The ::vas_id_t also encapsulates credentials (such as a keytab, or
 * credential cache) that may be associated with a security principal.
 *
 * @param ctx    ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param name   The name of the identity that will be associated with
 *               the newly created ::vas_id_t. If name is NULL then the
 *               ::vas_id_t will be associated with the owner of the
 *               current credential cache. If a credential cache does not
 *               exist, the ::vas_id_t will be generated from the pw_name
 *               returned by getpwuid(). If not NULL, name should be a
 *               fully qualified Kerberos principal name such as:
 *                  - "bill@EXAMPLE.COM"
 *                  - "host/mybox.example.com@EXAMPLE.COM".
 *               For convenience you may use simple names that
 *               will be expanded to full Kerberos principal names by
 *               the library. The following are examples of simple names
 *               and their expansion:
 *               \verbatim
                    bill        ---> bill@EXAMPLE.COM
                    host/       ---> host/mybox.example.com@EXAMPLE.COM
                    http/x.com  ---> http/x.com@EXAMPLE.COM
                 \endverbatim
 *               Rules for principal name expansion are fairly simple.
 *               If a '/' is found in the name it is treated as a
 *               service principal name and defaults for the missing
 *               components (the DNS host name and/or the realm name)
 *               are filled in based on the values established when the
 *               machine was joined to the domain. If no '/' is found
 *               then the name is treated as a user principal name and
 *               the default for the missing realm component is filled in.
 *
 *               Note that when using the SAM account name, the default_realm
 *               must have been explicitly set in the context. See
 *               vas_ctx_set_option().
 *
 * @param id     Set to point to memory allocated by the QAS library. The
 *               resulting vas_id_t must be freed by calling vas_id_free().
 *               If vas_id_alloc() fails, the value pointed at by id is
 *               undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_KRB5            - Kerberos specific error
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_CONFIG          - Unable to determine default_realm.
 */
vas_err_t vas_id_alloc( vas_ctx_t* ctx,
                        const char* name,
                        vas_id_t** id );


/** Destroys and deallocates a ::vas_id_t
 *
 * @param ctx   ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id    The ::vas_id_t to be freed.
 *
 **/
void vas_id_free( vas_ctx_t* ctx, vas_id_t* id );


/** Obtains the name of the file being use to store cached credentials.
 *
 * @param ctx   ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id    The ::vas_id_t to get the ccache name for.
 *
 * @param name  Returns the name of the Kerberos ticket cache. Returned pointer
 *              must be freed by the caller with free().
 *              If this function fails, the pointer pointed at by name is
 *              undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_KRB5            - Kerberos specific error
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_CRED_NEEDED     - Credential cache not established
 **/
vas_err_t vas_id_get_ccache_name( vas_ctx_t* ctx,
                                  vas_id_t* id,
                                  char** name );


/** Obtains the name of the keytab file associated with a ::vas_id_t
 *
 * @param ctx   ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id    The ::vas_id_t to get the keytab name for.
 *
 * @param name  Returns the name of the Kerberos keytab. Returned pointer
 *              must be freed by the caller with free().
 *              If this function fails, the pointer pointed at by name is
 *              undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_KRB5            - Kerberos specific error
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_NOT_FOUND       - Keytab not found or established
 **/
vas_err_t vas_id_get_keytab_name( vas_ctx_t* ctx,
                                  vas_id_t* id,
                                  char** name );


/** Obtain the identity name
 *
 * Used to obtain a string representation of the principal associated
 * with the specified identity.
 *
 * @param ctx    A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id     The ::vas_id_t to get the name information for.
 *
 * @param princ  Return the Kerberos principal name. Returned pointer
 *               must be freed by the caller with call to free(). Pass
 *               NULL if Kerberos principal name output is not desired.
 *               If this function fails, the pointer pointed at by princ is
 *               undefined and must not be freed.
 *
 * @param dn     Returns the distinguished name. Returned pointer must be
 *               freed by the caller with call to free(). Pass
 *               NULL if distinguished name output is not desired.
 *               If this function fails, the pointer pointed at by dn is
 *               undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_KRB5            - Kerberos specific error
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_NOT_FOUND       - Distinguished name not found
 **/
vas_err_t vas_id_get_name( vas_ctx_t* ctx,
                           vas_id_t* id,
                           char** princ,
                           char** dn );


/** Obtain a ::vas_user_t for this ::vas_id_t
 *
 * Convenience function that eliminates the need to call vas_user_init()
 * when you already have a ::vas_id_t.
 *
 * @param ctx    ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id     The ::vas_id_t to get the name information for, and to
 *               use when performing Active Directory searches. This
 *               id must have had its initial credentials established
 *               in order to obtain the ::vas_user_t if an LDAP search
 *               is required.
 *
 * @param user   Returns the ::vas_user_t for the identity. Resulting
 *               pointer must be freed with call to vas_user_free()
 *               If this function fails, the value pointed at by user is
 *               undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_NOT_FOUND       - Could not locate a user account
 *                                      with the given name.
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_id_get_user( vas_ctx_t* ctx,
                           vas_id_t* id,
                           vas_user_t** user );

/** Obtain a ::vas_user_t for this ::vas_id_t
 *
 * Convenience function that eliminates the need to call vas_user_init()
 * when you already have a ::vas_id_t.
 *
 * @since 4.1.0
 *
 * @param ctx      ::vas_ctx_t obtained from vas_ctx_alloc().
 * 
 * @param serverid The ::vas_id_t to use when performing Active Directory
 *                 searches. This id must have had its initial credentials established
 *                 in order to obtain the ::vas_user_t if an LDAP search
 *                 is required.
 *
 * @param clientid The ::vas_id_t to get the name information for.
 *
 * @param user   Returns the ::vas_user_t for the identity. Resulting
 *               pointer must be freed with call to vas_user_free()
 *               If this function fails, the value pointed at by user is
 *               undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_NOT_FOUND       - Could not locate a user account
 *                                      with the given name.
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_id_get_user_with_serverid( vas_ctx_t* ctx,
                                          vas_id_t* serverid,
                                          vas_id_t* clientid,
                                          vas_user_t** user );

/** Check to see if initial credential needs to be established
 *
 * Check to see if credentials need to be established for the
 * specified identity. There are several ways that credentials
 * could be established already, eliminating the need to call
 * vas_id_establish_cred_password() or vas_id_establish_cred_keytab():
 *
 *   1) vas_id_establish_cred_password() or vas_id_establish_cred_keytab()
 *      have already been called for the specified identity
 *
 *   2) The specified identity is the "current user" that logged
 *      on using the QAS PAM module and a credential cache has already
 *      been established
 *
 *   3) The specified identity is the result of a delegated
 *      SPNEGO or GSSAPI authentication.
 *
 *   NOTE: This function considers the ability to obtain credentials
 *         as sufficient. So if the vas_id_t has for example the keytab
 *         or password stored, then it will return success, even if the
 *         ccache established with the credentials has expired. 
 *   NOTE: This function should not replace using vas_renew_creds on
 *         failure of subsequent function call due to ccache expiring
 *         caused by time of check/time of use situations.
 *
 * @param ctx   ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id    The ::vas_id_t for whom the credentials might have
 *              been established.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_KRB5          - Kerberos error
 *          - VAS_ERR_CRED_NEEDED   - Credentials are NOT established
 *          - VAS_ERR_CRED_EXPIRED  - Credentials are expired.
 *          - VAS_ERR_INVALID_PARAM - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY     - Memory allocation failed
 **/
vas_err_t vas_id_is_cred_established( vas_ctx_t* ctx, vas_id_t* id );


/** Establish initial password credentials
 *
 * Establish the initial credentials that will be associated with the
 * specified identity. Since an initial credential may have been
 * established already it is a good idea to check for established
 * credentials, with a call to vas_id_is_cred_established().
 *
 * Calls to vas_id_establish_cred_password() may generate DNS, and
 * Kerberos network traffic
 *
 * @param ctx   ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id    The ::vas_id_t to establish credentials for.
 *
 * @param credflags The following flags are recognized:
 *              - VAS_ID_FLAG_USE_MEMORY_CCACHE - Credential cache
 *                is kept in memory so that it will not outlive the
 *                process.
 *              - VAS_ID_FLAG_KEEP_COPY_OF_CRED - Keep a copy of the
 *                "clear text credential" so that it can be used
 *                later.
 *
 * @param password The clear-text password for the specified identity.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_KRB5     - Kerberos error. Use ::vas_err_t functions
 *                               to obtain Kerberos error details
 *          - VAS_ERR_INVALID_PARAM - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY     - Memory allocation failed
 **/
vas_err_t vas_id_establish_cred_password( vas_ctx_t* ctx,
                                          vas_id_t* id,
                                          int credflags,
                                          const char* password );

/** Establish initial keytab credentials
 *
 * Establish the initial credentials that will be associated with the
 * specified identity. Since an initial credential may have been
 * established already it is a good idea to check for established
 * credentials, with a call to vas_id_is_cred_established().
 *
 * Calls to vas_id_establish_cred_keytab() may generate DNS, and
 * Kerberos network traffic
 *
 * @param ctx    ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id     The ::vas_id_t to establish credentials for.
 *
 * @param credflags  The following flags are recognized:
 *               - VAS_ID_FLAG_USE_MEMORY_CCACHE - Credential cache
 *                 is kept in memory so that it will not outlive the
 *                 process.
 *               - VAS_ID_FLAG_KEEP_COPY_OF_CRED - Keep a copy of the
 *                 "clear text credential" so that it can be used later.
 *                 This may be useful when a daemon needs to setuid() to
 *                 a non-privileged user that no longer has access
 *                 to the keytab.
 *               - VAS_ID_FLAG_DO_NOT_DERIVE_KEYTAB - If this flag is
 *                 used and keytab is NULL, the default_keytab setting from
 *                 vas.conf is used as the keytab name.
 *               - VAS_ID_FLAG_NO_INITIAL_TGT - Do not request an inital
 *                 TGT. A TGT is not necessary for server applications
 *                 that only need to call vas_id_extablish_cred_keytab()
 *                 before calling vas_auth().
 *
 * @param keytab The path to the keytab file. Pass in NULL to use a
 *               keytab filename that is derived by QAS from
 *               the identity name. The derivation of keytab filename
 *               matches the keytab created when using vastool to
 *               join the machine to the domain or when using vastool
 *               to create service principals in Active Directory
 *
 *               The derivation rules are fairly simple. The service
 *               is used with a .keytab extension along with the
 *               /etc/opt/quest/vas directory.
 *
 *               "http/web.vintela.com" --> /etc/opt/quest/vas/http.keytab
 *               "host/"                --> /etc/opt/quest/vas/host.keytab
 *
 *               If the VAS_ID_FLAG_DO_NOT_DERIVE_KEYTAB is used then
 *               the default_keytab setting from vas.conf is used as
 *               the keytab filename.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY     - Memory allocation failed
 *          - VAS_ERR_KRB5          - Kerberos error. Use vas_err_t
 *                                    functions to obtain Kerberos error
 *                                    details
 */
vas_err_t vas_id_establish_cred_keytab( vas_ctx_t* ctx,
                                        vas_id_t* id,
                                        int credflags,
                                        const char* keytab );


/** Opaque type representing a QAS PKCS#11 context */
typedef struct vas_pkcs11_t vas_pkcs11_t;

/** Establish initial PKCS#11 credentials.
 *
 * Establish the initial credentials that will be associated with the
 * specified identity. Since an initial credential may have been
 * established already it is a good idea to check for established
 * credentials (with a call to vas_id_is_cred_established())
 *
 * Calls to vas_id_establish_cred_pkcs11() may generate DNS, and
 * kerberos network traffic.
 *
 * A QAS PKCS#11 context must be established before calling this function.
 * User login must have been performed so that access to the private key on
 * the token is granted. If there is more than one PKCS#11 'identity' (i.e.,
 * a certificate/ private key pair) on the token, then a suitable identity
 * must have been selected. The UPN of the 'identity' must map to the
 * specified QAS identity.
 *
 * Example:
 * @code
 * vas_ctx_t *ctx = ...;
 * vas_pkcs11_t *pkcs11 = NULL;
 * vas_id_t *id = NULL;
 * int credflags = ...;
 * vas_err_t err;
 *
 * // Get a PKCS#11 context, using default options.
 * err = vas_pkcs11_alloc(ctx, NULL, &pkcs11);
 * if (err != VAS_ERR_SUCCESS) { ... error ... }
 *
 * ... check that token is present ...
 * ... get PIN ...
 * ... perform login ...
 * ... get UPN from PKCS#11 context ...
 * ... create vas_id_t using UPN ...
 *
 * err = vas_id_establish_cred(ctx, id, credflags, pkcs11);
 * if (err != VAS_ERR_SUCCESS) { ... error ... }
 *
 * ... use id ...
 *
 * vas_id_free(id);
 *
 * // Free the PKCS#11 context
 * vas_pkcs11_free(pkcs11);
 * @endcode
 *
 * @param ctx    vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id     The vas_id_t to establish credentials for.
 *
 * @param credflags  The following flags are recognized:
 *               - VAS_ID_FLAG_USE_MEMORY_CCACHE - Credential cache
 *                 is kept in memory so that it will not outlive the
 *                 process.
 *               - VAS_ID_FLAG_KEEP_COPY_OF_CRED - Keep a copy of the
 *                 "clear text credential" so that it can be used later.
 *                 This may be useful when a daemon needs to setuid() to
 *                 a non-privileged user that no longer has access
 *                 to the keytab.
 *
 * @param pkcs11 the QAS PKCS#11 context, obtained from vas_pkcs11_alloc(),
 *               with user login performed and (if there is more than one
 *               certificate/private key pair on the token) the required
 *               identity selected. The identity must have a UPN that maps to
 *               the id supplied above. The lifetime of the QAS PKCS#11 context
 *               must exceed the lifetime of this function call.
 */
vas_err_t vas_id_establish_cred_pkcs11( vas_ctx_t* ctx,
                                        vas_id_t* id,
                                        int credflags,
                                        vas_pkcs11_t *pkcs11 );

/** Renew credentials
 *
 * Renew previously established credentials.
 *
 * @param ctx    ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id     The ::vas_id_t to renew credentials for.
 *
 * @param credflags  No flags currently defined. Must be set to zero.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_KRB5         - Kerberos error. Use ::vas_err_t functions
 *                                   to obtain Kerberos error details
 *          - VAS_ERR_CRED_NEEDED  - Credentials to not exist
 *          - VAS_ERR_CRED_EXPIRED - Credentials are expired.
 */
vas_err_t vas_id_renew_cred( vas_ctx_t* ctx,
                             vas_id_t* id,
                             int credflags );


void vas_id_set_computer_account_reset_handler(int (*func_pointer)(vas_id_t*) );

/****************************************************************************
 *                                                                          *
 *                      AUTHENTICATION FUNCTIONS                            *
 *                                                                          *
 ****************************************************************************/

/** Used by a server to authenticate a client.
 *
 * This function is most often used used by a server to authenticate a
 * client, but may be used by any two identities (with established
 * credentials). The vas_auth_with_password() function may be
 * used as a convenience when username and password credentials are used for
 * authentication.
 *
 * @param ctx    ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param client The ::vas_id_t of the "client" to be authenticated. The
 *               client ::vas_id_t must have been used in a previously
 *               successful call to vas_id_establish_cred_password().
 *
 * @param server The ::vas_id_t of the "server" that is authenticating
 *               the client. The server ::vas_id_t must have been used in a
 *               previously successful call to vas_id_establish_cred_keytab().
 *
 * @param auth   Returns a ::vas_auth_t that may be used in subsequent
 *               authorization calls. Resulting pointer must be freed with a
 *               call to vas_auth_free().
 *               If this function fails, the pointer pointed at by auth is
 *               undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_KRB5          - Kerberos error. Use ::vas_err_t functions
 *                                    to obtain Kerberos error details
 *          - VAS_ERR_INVALID_PARAM - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY     - Memory allocation failed
 *          - VAS_ERR_CRED_NEEDED   - Credentials not established for client
 *                                    or server ::vas_id_t
 *          - VAS_ERR_CRED_EXPIRED  - Client credentials are expired.
 **/
vas_err_t vas_auth( vas_ctx_t* ctx,
                    vas_id_t* client,
                    vas_id_t* server,
                    vas_auth_t** auth );


/** Used by a server to authenticate a client with username and
 * password credentials.
 *
 * This is a convenience function that may used instead of vas_auth()
 * when the client's username and password credentials are available.
 * The same functionality can be realized (with more flexibility) by
 * calling vas_auth() directly, but in many cases calling
 * vas_auth_with_password() is more convenient because there is no
 * need to allocate a client ::vas_id_t.
 *
 *
 * @param ctx    ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param clientname  The client principal name. Similar to the
 *               string that would be passed to vas_id_alloc().
 *
 * @param clientpasswd The clear-text client password string.
 *
 * @param server The ::vas_id_t of the "server" that is authenticating
 *               the client. The server ::vas_id_t must have been used in a
 *               previously successful call to vas_id_establish_cred_keytab().
 *
 * @param auth   Returns a ::vas_auth_t that may be used in subsequent
 *               authorization calls. Resulting pointer must be freed with a
 *               call to vas_auth_free().
 *               If this function fails, the pointer pointed at by auth is
 *               undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY     - Memory allocation failed
 *          - VAS_ERR_KRB5          - Kerberos error. Use ::vas_err_t functions
 *                                    to obtain Kerberos error details
 *          - VAS_ERR_CRED_NEEDED   - Credentials not established for client
 *                                    or server ::vas_id_t
 *          - VAS_ERR_CRED_EXPIRED  - Client credentials are expired.
 **/
vas_err_t vas_auth_with_password( vas_ctx_t* ctx,
                                  const char* clientname,
                                  const char* clientpasswd,
                                  vas_id_t* server,
                                  vas_auth_t** auth );


/** Destroys and frees resources associated with the specified
 * ::vas_auth_t
 *
 * @param ctx   ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param auth  The ::vas_auth_t to be freed.
 *
 */
void vas_auth_free( vas_ctx_t* ctx, vas_auth_t* auth );


/** Used by server application to determine whether the authenticated client
 * is a member of a specified group.
 *
 * A ::vas_auth_t contains information about the client user's group membership
 * dervied from the Microsoft PAC information that is found in the Kerberos
 * service ticket used by the vas_auth() functions. After calling vas_auth() or
 * vas_auth_with_password(), developers can call this function to efficiently
 * determine whether or not a user is a member of a particular group. If there
 * is not a ::vas_auth_t available, the vas_user_is_member() and
 * vas_group_has_member() functions can be used. However, these functions are
 * less efficient since additional LDAP searches must be performed in order
 * to determine the user's group membership.
 *
 * @since 3.0.1
 *
 * @param ctx   A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id    A ::vas_id_t that may be used to resolve the group name. If
 *              NULL is passed then the group name will only be resolved
 *              against the QAS cache and no LDAP searches will be performed.
 *
 * @param auth  The ::vas_auth_t obtained previously with a call to vas_auth()
 *              or vas_auth_with_password().
 *
 * @param group The name of the group to check. May be a simple group name,
 *              the group's distinguished name, or the group's SID string.
 *
 * @return  VAS_ERR_SUCCESS if the client is a member of the group, or one of
 *          the following error codes:
 *          - VAS_ERR_NOT_FOUND     - Client is NOT a member of the group
 *          - VAS_ERR_EXISTS        - The group does not exist
 *          - VAS_ERR_INVALID_PARAM - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY     - Memory allocation failed
 */
vas_err_t vas_auth_check_client_membership( vas_ctx_t* ctx,
                                            vas_id_t* id,
                                            vas_auth_t* auth,
                                            const char* group );

/** Used by server application to determine whether the authenticated client
 * is a member of a specified group.
 *
 * A ::vas_auth_t contains information about the client user's group membership
 * dervied from the Microsoft PAC information that is found in the Kerberos
 * service ticket used by the vas_auth() functions. After calling vas_auth() or
 * vas_auth_with_password(), developers can call this function to efficiently
 * determine whether or not a user is a member of a particular group. If there
 * is not a ::vas_auth_t available, the vas_user_is_member() and
 * vas_group_has_member() functions can be used. However, these functions are
 * less efficient since additional LDAP searches must be performed in order
 * to determine the user's group membership.
 *
 * @since 4.1.0
 *
 * @param ctx   A ::vas_ctx_t obtained from vas_ctx_alloc().
 * 
 * @param serverid A ::vas_id_t that may be used to resolve the group name. If
 *                 NULL is passed then the group name will only be resolved
 *                 against the QAS cache and no LDAP searches will be performed.
 *
 * @param clientid A ::vas_id_t to get token group information for. This id should
 *                 be for the same user as the ::vas_auth_t.  Token group lookups
 *                 will be performed if PAC look up fails or if a PAC is not
 *                 available in the ::vas_auth_t.
 *
 * @param auth  The ::vas_auth_t obtained previously with a call to vas_auth()
 *              or vas_auth_with_password(). This should be for the same user
 *              that the clientid is for.
 *
 * @param group The name of the group to check. May be a simple group name,
 *              the group's distinguished name, or the group's SID string.
 *
 * @return  VAS_ERR_SUCCESS if the client is a member of the group, or one of
 *          the following error codes:
 *          - VAS_ERR_NOT_FOUND     - Client is NOT a member of the group
 *          - VAS_ERR_EXISTS        - The group does not exist
 *          - VAS_ERR_INVALID_PARAM - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY     - Memory allocation failed
 */
vas_err_t vas_auth_check_client_membership_with_server_id( vas_ctx_t* ctx,
                                                            vas_id_t* serverid,
                                                            vas_id_t* clientid,
                                                            vas_auth_t* auth,
                                                            const char* group );
/**
 * Used by server application obtain the list of groups of which the
 * authenticated client is a member.
 *
 * A ::vas_auth_t contains information (the Microsoft PAC) about the groups
 * of which a user is a member. After calling vas_auth() or
 * vas_auth_password() developers should call vas_auth_get_client_groups()
 * as the most efficient way of obtaining a list of the groups of which a
 * user is a member. If the ::vas_auth_t necessary for calling
 * vas_auth_get_client_groups() can not be obtained, the much less efficient
 * vas_user_get_groups() may be used to get group membership.
 *
 * @since 3.0.1
 *
 * @param ctx    A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id    A ::vas_id_t that may be used to resolve the groups. If
 *              NULL is passed then the groups will only be resolved
 *              against the QAS cache and no LDAP searches will be performed.
 *
 * @param auth   The ::vas_auth_t obtained previously with a call to
 *               vas_auth() or vas_auth_password().
 *
 * @param groups Used to return the groups of which the user is a member.
 *               Must be freed with vas_group_free_groups().
 *               If this function fails, the list pointed at by groups is
 *               undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_NOT_FOUND     - Client is not a member of any groups
 *          - VAS_ERR_INVALID_PARAM - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY     - Memory allocation failed
 */
vas_err_t vas_auth_get_client_groups( vas_ctx_t* ctx,
                                      vas_id_t* id,
                                      vas_auth_t* auth,
                                      vas_group_t*** groups );

/**
 * Similar to vas_auth_get_client_groups.  However, this also takes an
 * additional flag as a parameter to update group memberships from the
 * PAC.
 *
 * @since 4.0.3
 *
 * @param ctx    A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id    A ::vas_id_t that may be used to resolve the groups. If
 *              NULL is passed then the groups will only be resolved
 *              against the QAS cache and no LDAP searches will be performed.
 *
 * @param auth   The ::vas_auth_t obtained previously with a call to
 *               vas_auth() or vas_auth_password().
 *
 * @param groups Used to return the groups of which the user is a member.
 *               Must be freed with vas_group_free_groups().
 *               If this function fails, the list pointed at by groups is
 *               undefined and must not be freed.
 *
 * @param process_pac A 1 enables PAC processing; 0 disables it.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_NOT_FOUND     - Client is not a member of any groups
 *          - VAS_ERR_INVALID_PARAM - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY     - Memory allocation failed
 */
vas_err_t vas_auth_get_client_groups2( vas_ctx_t* ctx,
                                       vas_id_t* id,
                                       vas_auth_t* auth,
                                       vas_group_t*** groups,
                                       int process_pac );


/****************************************************************************
 *                                                                          *
 *                       ATTRIBUTE/VALUE FUNCTIONS                          *
 *                                                                          *
 ****************************************************************************/

/** Allocate a ::vas_attrs_t.
 *
 * The newly allocated ::vas_attrs_t is used in subsequent calls to
 * vas_attrs_find() and vas_attrs_find_continue() to obtain the
 * attributes of objects in Active Directory via LDAP searches.
 *
 * @param ctx    ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id     The identity that will be used to authenticate
 *               to the server. The id MUST have established
 *               credentials. Pass in NULL to perform anonymous
 *               LDAP searches.
 *
 * @param attrs  Set to point to memory allocated by the QAS library. The
 *               resulting vas_attrs_t must be freed by calling
 *               vas_attrs_free().
 *               If this function fails, the value pointed at by attrs is
 *               undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY     - Memory allocation failed
 *          - VAS_ERR_NOT_FOUND     - Client is NOT a member of group
 **/
vas_err_t vas_attrs_alloc( vas_ctx_t* ctx,
                           vas_id_t* id,
                           vas_attrs_t** attrs );


/** Execute an LDAP search and process the results.
 *
 * The vas_attrs_find() and vas_attrs_find_continue() functions are
 * wrappers for several LDAP API functions that may make it easier to perform
 * and process the results of LDAP searches. vas_attrs_find() is called
 * first to initiate and obtain the first result of an LDAP search.
 *
 * vas_attrs_find_continue() is used to iterate through the remaining
 * search result. The idea is that a successful call to vas_attrs_find() is
 * followed by calls to vas_attrs_find_continue() until no more results
 * are available (VAS_ERR_NOT_FOUND is returned in this situation).
 *
 * Calls to vas_attrs_find() may generate DNS, Kerberos, and LDAP network
 * traffic.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param attrs     A ::vas_attrs_t obtained from call to vas_attrs_alloc().
 *
 * @param uri       The URI that identifies the server to which it will be
 *                  bound. For more details on URI format see:
 *                  vas_ldap_init_and_bind()
 *
 * @param scope     Optional LDAP search scope. May one of the following
 *                  strings: "base" for LDAP_SCOPE_BASE, "sub" for
 *                  LDAP_SCOPE_SUBTREE, or "one" for LDAP_SCOPE_ONELEVEL.
 *                  If not set, LDAP_SCOPE_SUBTREE will be used
 *
 * @param base      Optional search base for the LDAP search. The search
 *                  base is specified as a distinguished name
 *                  (OU=myou,DC=foo,DC=com). Pass in NULL to use the
 *                  defaultNamingContext LDAP search base. When using the GC,
 *                  pass in an empty string "" to search the entire global
 *                  catalog.
 *
 * @param filter    Required LDAP search filter that specifies search
 *                  conditions.
 *
 * @param anames    Optional list attributes to obtain. Pointer to a NULL
 *                  terminated array of strings.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_NOT_FOUND     - Matching entry doesn't exist
 *          - VAS_ERR_INVALID_PARAM - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY     - Memory allocation failed
 *          - VAS_ERR_KRB5          - Kerberos error. Use ::vas_err_t functions
 *                                    to obtain Kerberos error details
 *          - VAS_ERR_LDAP          - LDAP error. Use ::vas_err_t functions
 *                                    to obtain LDAP error details
 * @code
 *
 * // EXAMPLE 1:
 * {
 *     const char* anames[] = { "cn", NULL };
 *     vas_attrs_t *attrs = NULL;
 *
 *     ...
 *
 *     if( ( rval = vas_attrs_alloc( ctx, id, &attrs ) ) )
 *     {
 *        // (probably lack of memory)
 *        fprintf( stderr,
 *                 "ERROR: vas_attrs_alloc() failed. %s\n",
 *                 vas_err_get_string( ctx, 1 ) );
 *         return rval;
 *     }
 *
 *     // Typical vas_attrs_find() loop
 *     // (searches the defaultNamingContext of a DC in the default_realm domain).
 *     rval = vas_attrs_find( ctx,
 *                            attrs,
 *                            "DC://",
 *                            "sub",
 *                            NULL,
 *                            "(objectClass=*)",
 *                           anames );
 *     while( rval == VAS_ERR_SUCCESS )
 *     {
 *        ...
 *
 *        // display or record attribute values
 *
 *        ...
 *
 *        rval = vas_attrs_find_continue( ctx, attrs );
 *     }
 *
 *     if( rval && rval != VAS_ERR_NOT_FOUND )
 *     {
 *        fprintf( stderr,
 *                 "ERROR: vas_attrs_find() failed. %s\n",
 *                 vas_err_get_string( ctx, 1 ) );
 *
 *        vas_attrs_free( ctx, attrs );
 *        return rval;
 *     }
 *
 *     vas_attrs_free( ctx, attrs );
 *     ...
 * }
 *
 *
 * // EXAMPLE 2:
 *
 * vas_err_t CopyComputerObjectSpns( vas_ctx_t  *ctx,
 *                                   vas_id_t   *id,
 *                                   const char *domain,
 *                                   const char *computer,
 *                                   size_t     aliasListLen,
 *                                   char       **spns )
 * {
 *     int         cnt;
 *     int         spnCount = 0;
 *     char        *base = NULL, *uri = NULL, *filter = NULL;
 *     char        **spn_list = NULL;
 *     const char  *anames[] = { VAS_ATTR_SERVICE_PRINCIPAL_NAME, NULL };
 *     vas_err_t   rval = VAS_ERR_SUCCESS;
 *     vas_attrs_t *attrs = NULL;
 *
 *     // Run the computer object's SPN attribute to get all of its SPNs...
 *     if( ( asprintf( &filter, "(distinguishedName=%s)", computer ) == -1 )
 *      || ( asprintf( &uri, "DC://@%s", domain ) == -1 ) )
 *     {
 *         rval = libvas_err_vas( ctx, VAS_ERR_NO_MEMORY, NULL );
 *         goto CLEANUP;
 *     }
 *
 *     if( ( rval = vas_ldapstring_domain_to_domain_searchbase( domain, &base ) ) )
 *     {
 *         rval = libvas_err_vas_wrap( ctx,
 *                                     rval,
 *                                     "Could not convert domain %s to search base."
 *                                     domain );
 *         goto CLEANUP;
 *     }
 *
 *     rval = vas_attrs_alloc( ctx, id, &attrs );
 *
 *     if( rval )
 *         goto CLEANUP;
 *
 *     rval = vas_attrs_find( ctx, attrs, uri, "sub", base, filter, anames );
 *
 *     if( rval )
 *     {
 *         rval = libvas_err_vas_wrap( ctx,
 *                                     rval,
 *                                     "Could not find SPNs on %s.",
 *                                     computer );
 *         goto CLEANUP;
 *     }
 *
 *     // The point here is to get one of the values named in anames. So, if
 *     // the third argument isn't also in the initialization of anames above,
 *     // vas_vals_get_string() won't yield success and good information.
 *     rval = vas_vals_get_string( ctx,
 *                                 attrs,
 *                                 VAS_ATTR_SERVICE_PRINCIPAL_NAME,
 *                                 &spn_list,
 *                                 &spnCount );
 *     if( rval )
 *     {
 *         rval = libvas_err_vas_wrap( ctx,
 *                                     rval,
 *                                     "Trouble parsing out SPN attributes for %s.",
 *                                     computer );
 *         goto CLEANUP;
 *     }
 *
 *     if( spnCount > 0 )      // unlikely to be none, but possible in theory
 *     {
 *         int i = 0, count = spnCount;
 *
 *         while( aliasListLen-- > 0 && count-- > 0 )
 *         {
 *             // if we start getting NULL back from low memory, oh well...
 *             aliases[i] = strdup( spn_list[i] );
 *             i++;
 *         }
 *
 *         vas_vals_free_string( ctx, spn_list, spnCount );
 *     }
 *
 * CLEANUP :
 *     if( base )   free( base );
 *     if( uri )    free( uri );
 *     if( filter ) free( filter );
 *     if( attrs )  vas_attrs_free( ctx, attrs );
 *
 *     return rval;
 * }
 *
 * @endcode
 *
 **/
vas_err_t vas_attrs_find( vas_ctx_t* ctx,
                          vas_attrs_t* attrs,
                          const char* uri,
                          const char* scope,
                          const char* base,
                          const char* filter,
                          const char* const* anames );


/** Continues a previous vas_attrs_find()  Used to get the rest of the
 * results of an LDAP search. vas_attrs_find_continue() should be
 * called until it returns VAS_ERR_NOT_FOUND.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param attrs     A ::vas_attrs_t obtained from vas_attrs_alloc().
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_NOT_FOUND     - No more matching entries
 *          - VAS_ERR_INVALID_PARAM - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY     - Memory allocation failed
 *          - VAS_ERR_NOT_FOUND     - Client is NOT a member of group
 *          - VAS_ERR_KRB5          - Kerberos error. Use ::vas_err_t functions
 *                                    to obtain Kerberos error details
 *          - VAS_ERR_LDAP          - LDAP error. Use ::vas_err_t functions
 *                                    to obtain LDAP error details
 **/
vas_err_t vas_attrs_find_continue( vas_ctx_t* ctx, vas_attrs_t* attrs );


/** Set options that change vas_attrs behavior.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param attrs     A ::vas_attrs_t obtained from vas_attrs_alloc().
 *
 * @param option    The option to set. The following options are defined:
 *                  - VAS_ATTRS_B64_ENCODE_ATTRS - List of attributes
 *                    whose values will be base64 encoded when returned
 *                    from calls to vas_vals_get_string().
 *                    Three possible value types:
 *                     - "attribute1,attribute2,..." : String of comma
 *                       separated attribute names that should be base64
 *                       encoded. This will overwrite the vas.conf settings.
 *                     - "" (Empty string) : This will disable all base64
 *                       encoding.
 *                     - NULL : This will reset the attribute to the vas.conf
 *                       base64-encoded-attrs entry.
 *                    The vas.conf setting can be obtained by calling
 *                    vas_attrs_get_option on this option before any
 *                    set call, or after a NULL set call. Argument is
 *                    either a char* or a NULL.
 *                  - VAS_ATTRS_OPTION_SEARCH_TIMEOUT - Number of seconds
 *                    vas_attrs_find() and vas_attrs_find_continue() will
 *                    block before returning VAS_ERR_TIMEDOUT. Argument
 *                    is an integer that is set to the new timeout value.
 *                 - VAS_ATTRS_OPTION_LDAP_PAGESIZE - adjusts the size
 *                    of paged results. Argument is an integer.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 **/
vas_err_t vas_attrs_set_option( vas_ctx_t* ctx,
                                vas_attrs_t* attrs,
                                vas_attrs_opt_t option,
                                ... );

/** Get options that change ::vas_attrs_t behavior.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param attrs     A ::vas_attrs_t obtained from vas_attrs_alloc().
 *
 * @param option    The option to get. The following options are defined:
 *                  - VAS_ATTRS_B64_ENCODE_ATTRS - The argument is:
 *                    a single const char **. Returned pointer must not
 *                    be freed. See vas_attrs_set_option for the meaning
 *                    of returned values
 *                  - VAS_ATTRS_OPTION_SEARCH_TIMEOUT - The argument is:
 *                    a single int *. See vas_attrs_set_option for the meaning
 *                    of returned values
 *                  - VAS_ATTRS_OPTION_LDAP_PAGESIZE - The argument is:
 *                    a single int *. See vas_attrs_set_option for the meaning
 *                    of returned values
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 **/
vas_err_t vas_attrs_get_option( vas_ctx_t* ctx,
                                vas_attrs_t* attrs,
                                vas_attrs_opt_t option,
                                ... );


/** Free a ::vas_attrs_t structure obtained from vas_attrs_alloc().
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param attrs     A ::vas_attrs_t obtained from vas_attrs_alloc().
 *
 **/
void vas_attrs_free( vas_ctx_t* ctx, vas_attrs_t* attrs );


/** Obtain string values of an attribute
 *
 * Note that when requesting the string values for a binary attribute,
 * the resulting string may not be valid. The function will attempt
 * to base-64 encode known binary values in order to avoid returning
 * invalid strings. The list of known binary attributes is controlled
 * through the vas.conf file and the base64-encoded-attrs option, or
 * with the VAS_ATTRS_B64_ENCODE_ATTRS ::vas_attrs_opt_t value for
 * the vas_attrs_set_option() function.
 *
 * By default this list is userCertificate, objectGuid, objectSid,
 * userParameters, logonHours, and vintela-sidBL. See the vas.conf
 * man page documentation or vas_attrs_set_option() for more details.
 * See also vas_attrs_find() for sample source code.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param attrs     A ::vas_attrs_t used in a call to vas_attrs_find(),
 *                  or vas_attrs_find_continue().
 *
 * @param aname     The name of the attribute to get values for.
 *
 * @param strvals   Pointer that will receive pointer to array of
 *                  string values. Must be freed with call
 *                  vas_vals_free_string()
 *                  If this function fails, the array pointed at by strvals is
 *                  undefined and must not be freed.
 *
 * @param count     Returns number of values in the strvals array.
 *
 * @return  VAS_ERROR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_NOT_FOUND     - Values for the requested attribute
 *                                    were not found in result entry.
 *          - VAS_ERR_INVALID_PARAM - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY     - Memory allocation failed
 *          - VAS_ERR_MORE_VALS     - Indicates that there are more
 *                                    attribute values. This will happen
 *                                    when multi-valued attributes have
 *                                    more than 1500 values (for Windows
 *                                    2003 servers) or 1000 values (for
 *                                    Windows 2000 servers). The attribute
 *                                    values will be returned in sets of
 *                                    1000 or 1500 as they are obtained
 *                                    from Active Directory using
 *                                    Incremental Retrieval of Multi-Valued
                                      Attributes. To obtain the next range
 *                                    of values the caller should free the
 *                                    returned results with a call to
 *                                    vas_vals_free_string() and call
 *                                    vas_vals_get_string() again using
 *                                    the same vas_attrs_t and aname as the
 *                                    previous call. Continue calling
 *                                    vas_vals_get_string(), until
 *                                    VAS_ERR_MORE_VALS is no longer
 *                                    returned.
 *          - VAS_ERR_LDAP          - LDAP error. Use vas_err_t functions
 *                                    to obtain LDAP error details
 */
vas_err_t vas_vals_get_string( vas_ctx_t* ctx,
                               vas_attrs_t* attrs,
                               const char* aname,
                               char*** strvals,
                               int* count );

/**
 * Same as ::vas_vals_get_string but in addition callers can determine whether
 * returned values are already base64-encoded.
 *
 * @param vals_encoded Pointer that will be allocated to an array of ints,
 *                     one per value, indicating whether that value has already
 *                     been base64-encoded. Callers must free *vals_encoded
 *                     by calling ::free().
 *                     An array is used, one per value, to allow a future
 *                     implementation to base64-encode values depending on
 *                     their content (eg. non-printable data) rather than
 *                     the attribute name.
 */
vas_err_t vas_vals_get_string2( vas_ctx_t* ctx,
                                vas_attrs_t *attrs,
                                const char* aname,
                                char*** strvals,
                                int* count,
                                int** vals_encoded );

/** Obtain integer values of an attribute
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param attrs     A ::vas_attrs_t used in a call to vas_attrs_find(),
 *                  or vas_attrs_find_continue().
 *
 * @param aname     The name of the attribute to get values for.
 *
 * @param intvals   Pointer that will receive pointer to array of integer
 *                  values. Must be freed with call vas_vals_free_integer().
 *                  If this function fails, the array pointed at by intvals is
 *                  undefined and must not be freed.
 *
 * @param count     Returns number of values in the intvals array.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_NOT_FOUND     - Values for the requested attribute
 *                                    were not found in result entry.
 *          - VAS_ERR_INVALID_PARAM - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY     - Memory allocation failed
 *          - VAS_ERR_MORE_VALS     - Indicates that there are more
 *                                    attribute values. This will happen
 *                                    when multi-valued attributes have
 *                                    more than 1500 values (for Windows
 *                                    2003 servers) or 1000 values (for
 *                                    Windows 2000 servers). The attribute
 *                                    values will be returned in sets of
 *                                    1000 or 1500 as they are obtained
 *                                    from Active Directory using
 *                                    Incremental Retrieval of Multi-Valued
                                      Attributes. To obtain the next range
 *                                    of values the caller should free the
 *                                    returned results with a call to
 *                                    vas_vals_free_integer() and call
 *                                    vas_vals_get_integer() again using
 *                                    the same vas_attrs_t and aname as the
 *                                    previous call. Continue calling
 *                                    vas_vals_get_integer(), until
 *                                    VAS_ERR_MORE_VALS is no longer
 *                                    returned.
 *          - VAS_ERR_LDAP          - LDAP error. Use vas_err_t functions
 *                                    to obtain LDAP error details
 */
vas_err_t vas_vals_get_integer( vas_ctx_t* ctx,
                                vas_attrs_t* attrs,
                                const char* aname,
                                int** intvals,
                                int* count );


/** Obtain binary values of an attribute
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param attrs     A ::vas_attrs_t used in a call to vas_attrs_find(),
 *                  or vas_attrs_find_continue().
 *
 * @param aname     The name of the attribute to get values for.
 *
 * @param binvals   Pointer that will receive pointer to array of
 *                  vas_binary_val_t values. Must be freed with call
 *                  vas_vals_free_binary().
 *                  If this function fails, the array pointed at by binvals is
 *                  undefined and must not be freed.
 *
 * @param count     Returns number of values in the binvals array.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_NOT_FOUND     - Values for the requested attribute
 *                                    were not found in result entry.
 *          - VAS_ERR_INVALID_PARAM - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY     - Memory allocation failed
 *          - VAS_ERR_MORE_VALS     - Indicates that there are more
 *                                    attribute values. This will happen
 *                                    when multi-valued attributes have
 *                                    more than 1500 values (for Windows
 *                                    2003 servers) or 1000 values (for
 *                                    Windows 2000 servers). The attribute
 *                                    values will be returned in sets of
 *                                    1000 or 1500 as they are obtained
 *                                    from Active Directory using
 *                                    Incremental Retrieval of Multi-Valued
                                      Attributes. To obtain the next range
 *                                    of values the caller should free the
 *                                    returned results with a call to
 *                                    vas_vals_free_binary() and call
 *                                    vas_vals_get_binary() again using
 *                                    the same vas_attrs_t and aname as the
 *                                    previous call. Continue calling
 *                                    vas_vals_get_binary(), until
 *                                    VAS_ERR_MORE_VALS is no longer
 *                                    returned.
 *          - VAS_ERR_LDAP          - LDAP error. Use ::vas_err_t functions
 *                                    to obtain LDAP error details
 **/
vas_err_t vas_vals_get_binary( vas_ctx_t* ctx,
                               vas_attrs_t* attrs,
                               const char* aname,
                               vas_val_binary_t** binvals,
                               int* count );


/** Obtain names of attributes with values.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param attrs     A ::vas_attrs_t used in a call to vas_attrs_find(),
 *                  or vas_attrs_find_continue().
 *
 * @param anames    Pointer that will receive pointer to array of string
 *                  values. Must be freed with call vas_vals_free_anames().
 *                  If this function fails, the array pointed at by anames is
 *                  undefined and must not be freed.
 *
 * @param count     Returns number of values in the anames array.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_NOT_FOUND     - Values for the requested attribute
 *                                    were not found in result entry.
 *          - VAS_ERR_INVALID_PARAM - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY     - Memory allocation failed
 *          - VAS_ERR_LDAP          - LDAP error. Use ::vas_err_t functions
 *                                    to obtain LDAP error details
 */
vas_err_t vas_vals_get_anames( vas_ctx_t* ctx,
                               vas_attrs_t* attrs,
                               char*** anames,
                               int* count );


/** Obtain the distinguished name (DN) from the results of a
 * vas_attrs_find() operation.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param attrs     A ::vas_attrs_t used in a call to vas_attrs_find(),
 *                  or vas_attrs_find_continue().
 *
 * @param dn        Set to point to memory malloc()'d by the QAS
 *                  library. Must be freed with a call to vas_vals_free_dn().
 *                  If this function fails, the value pointed at by dn is
 *                  undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_NOT_FOUND     - Values for the requested attribute
 *                                    were not found in result entry.
 *          - VAS_ERR_INVALID_PARAM - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY     - Memory allocation failed
 *          - VAS_ERR_LDAP          - LDAP error. Use ::vas_err_t functions
 *                                    to obtain LDAP error details
 */
vas_err_t vas_vals_get_dn( vas_ctx_t* ctx,
                           vas_attrs_t* attrs,
                           char** dn );


/** Free an array of binary values returned by vas_vals_get_binary()
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param binvals   Array of binary values returned by vas_vals_get_binary().
 *
 * @param count     number of elements in the binvals array.
 *
 * @return          VAS_ERR_SUCCESS on success, or one of the following error
 *                  codes:
 *                  - VAS_ERR_INVALID_PARAM - An invalid parameter was passed
 */
vas_err_t vas_vals_free_binary( vas_ctx_t* ctx,
                                vas_val_binary_t* binvals,
                                int count );


/** Free an array of string values returned by vas_vals_get_string()
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param strvals   Array of string values returned by vas_vals_get_string().
 *
 * @param count     number of elements in the strvals array.
 *
 * @return          VAS_ERR_SUCCESS on success, or one of the following error
 *                  codes:
 *                  - VAS_ERR_INVALID_PARAM - An invalid parameter was passed
 */
vas_err_t vas_vals_free_string( vas_ctx_t* ctx, char** strvals, int count );


/** Free an array of integer values returned by vas_vals_get_integer()
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param intvals   Array of integer values returned by vas_vals_get_integer().
 *
 * @param count     number of elements in the intvals array.
 *
 * @return          VAS_ERR_SUCCESS on success, or one of the following error
 *                  codes:
 *                  - VAS_ERR_INVALID_PARAM - An invalid parameter was passed
 */
vas_err_t vas_vals_free_integer( vas_ctx_t *ctx, int* intvals, int count );


/** Free an array of attribute names returned by vas_vals_get_anames()
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param anames    Array of string values returned by vas_vals_get_anames().
 *
 * @param count     number of elements in the anames array.
 *
 * @return          VAS_ERR_SUCCESS on success, or one of the following error
 *                  codes:
 *                  - VAS_ERR_INVALID_PARAM - An invalid parameter was passed
 */
vas_err_t vas_vals_free_anames( vas_ctx_t* ctx, char** anames, int count );


/** Free a distinguished name returned by vas_vals_dn().
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param dn        value name returned vas_vals_get_dn().
 *
 * @return          VAS_ERR_SUCCESS on success, or one of the following error
 *                  codes:
 *                  - VAS_ERR_INVALID_PARAM - An invalid parameter was passed
 */
vas_err_t vas_vals_free_dn( vas_ctx_t* ctx, char* dn );



/****************************************************************************
 *                                                                          *
 *                          NAME FUNCTIONS                                  *
 *                                                                          *
 ****************************************************************************/

/** Expand a simple user, service, or computer name to a full Kerberos
 * principal name.
 *
 * @param ctx     ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param name    The name to be expanded.
 *
 * @param hint    Optional. The type of name being expanded. Recognized
 *                hint values include:
 *                - VAS_NAME_TYPE_USER
 *                - VAS_NAME_TYPE_SERVICE
 *                - VAS_NAME_TYPE_HOST
 *                - VAS_NAME_TYPE_GROUP
 *                - VAS_NAME_TYPE_UNKNOWN
 *                - VAS_NAME_TYPE_SID
 *                - VAS_NAME_TYPE_DN
 *                \verbatim
                  Providing hint will result in more accurate expansion.
                  For example, if you were expanding the name "ethan",
                  the following outputs would be generated:

                  name="ethan", hint=0
                      --> nameout="ethan\@EXAMPLE.COM"
                  name="ethan", hint=VAS_NAME_TYPE_USER
                      --> nameout="ethan\@EXAMPLE.COM"
                  name="ethan", hint=VAS_NAME_TYPE_SERVICE
                      --> nameout="ethan/myhost.example.com\@EXAMPLE.COM"
                  name="ethan", hint=VAS_NAME_TYPE_HOST
                      --> nameout="host/ethan.example.com\@EXAMPLE.COM"

                  Using the hints VAS_NAME_TYPE_USER, VAS_NAME_TYPE_SERVICE,
                  VAS_NAME_TYPE_HOST or VAS_NAME_TYPE_GROUP will restrict
                  the search to only objects of the appropriate type.

                  If VAS_NAME_TYPE_UNKNOWN is used then vas_name_to_dn()
                  will attempt to guess the type of object from the name
                  passed. If VAS_NAME_TYPE_SID or VAS_NAME_TYPE_DN are
                  passed the objects that match those SID or DNs exactly
                  will be returned.
                  \endverbatim
 *
 * @param flags   Flags that modify the expansion behavior:
 *                - VAS_NAME_FLAG_NO_IMPLICIT - Do not expand  the Microsoft
 *                  implicit principal name.
 *                  \verbatim
                    name="host/", hint=VAS_NAME_TYPE_HOST, flags=0
                       --> nameout="ETHAN$@EXAMPLE.COM"
                    name="host/", hint=VAS_NAME_TYPE_HOST, flags=_NO_IMPLICIT
                       --> nameout="host/ethan.example.com@EXAMPLE.COM"
                    \endverbatim
                  - VAS_NAME_FLAG_NO_DNS_EXPAND - Do not expand hostname to a
                    fully qualified DNS name:
                    \verbatim
                    name="ethan", hint=HOST, flags=_NO_IMPLICIT | _NO_DNS_EXPAND
                     --> nameout="host/ethan@EXAMPLE.COM"
                    \endverbatim
 *                 - VAS_NAME_FLAG_FOREST_SCOPE - If a domain/realm part is not
 *                   specified, the entire forest is searched. By default only
 *                   the current realm will be searched.
 *
 * @param nameout Set to point to memory malloc()'d by the QAS library. The
 *                resulting pointer must be freed by calling free().
 *                If this function fails, the value pointed at by nameout is
 *                undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY     - Memory allocation failed
 **/
vas_err_t vas_name_to_principal( vas_ctx_t* ctx,
                                 const char* name,
                                 vas_name_type_t hint,
                                 int flags,
                                 char** nameout );


/** Obtain the LDAP distinguished name for a simple user, group,
 * service, or computer name.
 *
 *
 * @param ctx     ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id      The identity that will be used to authenticate.
 *                to the LDAP server. The id MUST have established
 *                credentials. Pass in NULL to perform anonymous
 *                LDAP searches.
 *
 * @param name    The name to obtain the distinguished name for.
 *
 * @param hint    Optional. The type of name being used. Recognized
 *                hint values include:
 *                - VAS_NAME_TYPE_UNKNOWN
 *                - VAS_NAME_TYPE_USER
 *                - VAS_NAME_TYPE_GROUP
 *                - VAS_NAME_TYPE_SERVICE
 *                - VAS_NAME_TYPE_HOST
 *
 * @param flags   Flags that modify the expansion behavior:
 *                - VAS_NAME_FLAG_NO_CACHE
 *                - VAS_NAME_FLAG_NO_LDAP
 *                - VAS_NAME_FLAG_FOREST_SCOPE - If a domain/realm part is
 *                                               not specified, the entire
 *                                               forest is searched. By
 *                                               default only the current
 *                                               realm will be searched.
 *
 * @param nameout The resulting distinguished name. Set to point to memory
 *                allocated by the QAS library. The resulting pointer
 *                must be freed by calling free().
 *                If this function fails, the value pointed at by nameout is
 *                undefined and must not be freed.
 *
 * @param domainout The Active Directory domain the object represented by
 *                  the name is located in. Set to point to memory
 *                  allocated by the QAS library. The resulting pointer
 *                  must be freed by calling free(). Pass NULL if
 *                  information about the domain is not desired.
 *                  If this function fails, the value pointed at by domainout
 *                  is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_NOT_FOUND     - No distinguished name found
 *          - VAS_ERR_INVALID_PARAM - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY     - Memory allocation failed
 *          - VAS_ERR_KRB5          - Kerberos error. Use ::vas_err_t functions
 *                                    to obtain Kerberos error details
 *          - VAS_ERR_LDAP          - LDAP error. Use ::vas_err_t functions
 *                                    to obtain LDAP error details
 **/
vas_err_t vas_name_to_dn( vas_ctx_t* ctx,
                          vas_id_t* id,
                          const char* name,
                          vas_name_type_t hint,
                          int flags,
                          char** nameout,
                          char** domainout );


/**
 * Compare two names for equality.
 *
 * @param ctx     ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id      The identity that will be used to authenticate.
 *                to the LDAP server. The id MUST have established
 *                credentials. Pass in NULL to perform anonymous
 *                LDAP searches.
 *
 * @param name_a  First name to compare.
 *
 * @param name_b  Second name to compare.
 *
 * @param hint    Optional. The type of name being used. Recognized
 *                hint values include:
 *                - VAS_NAME_TYPE_UNKNOWN
 *                - VAS_NAME_TYPE_USER
 *                - VAS_NAME_TYPE_GROUP
 *                - VAS_NAME_TYPE_SERVICE
 *                - VAS_NAME_TYPE_HOST
 *
 * @param flags   Flags that modify the expansion behavior:
 *                - VAS_NAME_FLAG_NO_CACHE
 *                - VAS_NAME_FLAG_NO_LDAP
 *                - VAS_NAME_FLAG_FOREST_SCOPE - If a domain/realm part is
 *                                               not specified, the entire
 *                                               forest is searched. By
 *                                               default only the current
 *                                               realm will be searched.
 *
 * @return VAS_ERR_SUCCESS if the names match and VAS_ERR_FAILURE if they do
 *   not. In both cases the error code will not be attached to the ::vas_ctx_t
 *   (ie. a call to vas_err_get_code() will not return this error code. If
 *   an error occurs (for example because a name cannot be looked up), then
 *   this call may also return one of the following errors, which
 *   will be attached to the ::vas_ctx_t and
 *   returnable from vas_err_get_code().
 *
 *          - VAS_ERR_NOT_FOUND     - No distinguished name found
 *          - VAS_ERR_INVALID_PARAM - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY     - Memory allocation failed
 *          - VAS_ERR_KRB5          - Kerberos error. Use ::vas_err_t functions
 *                                    to obtain Kerberos error details
 *          - VAS_ERR_LDAP          - LDAP error. Use ::vas_err_t functions
 *                                    to obtain LDAP error details
 *
 **/
int vas_name_compare( vas_ctx_t *ctx,
                      vas_id_t *id,
                      const char *name_a,
                      const char *name_b,
                      vas_name_type_t hint,
                      int flags );

/****************************************************************************
 *                                                                          *
 *                        INFORMATION FUNCTIONS                             *
 *                                                                          *
 ****************************************************************************/

/** Obtains the name of the forest root domain
 *
 * @param ctx          A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param forest_root  The address of a char* that will be set to the
 *                     root domain of the forest. The caller must free the
 *                     returned pointer with free(). Pass NULL if the
 *                     forest_root is not desired.
 *                     If this function fails, the pointer pointed at by
 *                     forest_root is undefined and must not be freed.
 *
 * @param forest_root_dn  The address of a char* that will be set to the forest
 *                        root distinguished name (DN). The caller must free the
 *                        returned pointer with free(). Pass NULL if the
 *                        forest_root_dn is not desired.
 *                        If this function fails, the pointer pointed at by
 *                        forest_root_dn is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_CONFIG          - Unable to determine default_realm
 *          - VAS_ERR_DNS             - DNS server lookup failed
 *          - VAS_ERR_LDAP            - LDAP error. Use ::vas_err_t functions
 *                                      to obtain LDAP error details
 **/
vas_err_t vas_info_forest_root( vas_ctx_t* ctx,
                                char** forest_root,
                                char** forest_root_dn );


/**
 * Obtains the name of the Active Directory domain to which the computer is
 * joined. This function may be used as a test to see if the computer is joined.
 *
 * @param ctx     A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param domain  The address of a char* that will be set to the domain
 *                to which the computer is joined. The caller must free the
 *                returned pointer. The caller must free the
 *                returned pointer with free(). Pass NULL if the
 *                domain string is not desired.
 *
 * @param domain_dn  The address of a char* that will be set to the domain
 *                distinguished name (DN) to which the computer is joined.
 *                The caller must free the returned pointer with free().
 *                Pass NULL if the domain DN string is not desired.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_CONFIG          - Unable to determine default_realm
 **/
vas_err_t vas_info_joined_domain( vas_ctx_t* ctx,
                                  char** domain,
                                  char** domain_dn );


/**
 * Obtains the name of the current Active Directory site to which the host
 * belongs.
 *
 * @param ctx     A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param site    Returns the site name to which the Unix host belongs.
 *                The caller must free the returned pointer with free().
 *                If this function fails, the pointer pointed at by site
 *                is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_NOT_FOUND       - Host does not belong to a site.
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_CONFIG          - Unable to determine default_realm
 *          - VAS_ERR_DNS             - DNS server lookup failed
 *          - VAS_ERR_LDAP            - LDAP error. Use ::vas_err_t functions
 *                                      to obtain LDAP error details
 **/
vas_err_t vas_info_site( vas_ctx_t* ctx, char** site );


/**
 * Obtain names of Active Directory domains in the Active Directory forest to
 * which the QAS host is joined.
 *
 * Calls to vas_info_domains() may generate DNS network traffic.
 *
 * @param ctx     A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id      The identity that will be used to search
 *                Active Directory. The id must have established
 *                credentials. Pass in NULL to attempt anonymous
 *                discovery of domains, which may fail depending
 *                on permissions set in AD.
 *
 * @param domains The address of a char** array that will be allocated and
 *                filled with domain name strings. (The array is used similarly
 *                to char *argv[] and is NULL terminated.)
 *                The caller should free the returned array pointer, by calling
 *                vas_info_domains_free(). Pass NULL if the domains
 *                strings are not desired.
 *                If this function fails, the array pointed at by domains
 *                is undefined and must not be freed.
 *
 * @param domains_dn  The address of a char** array that will be allocated and
 *                filled with DN strings. (The array is used similarly to
 *                char *argv[] and is NULL terminated.)
 *                The caller should free the returned array pointer, by calling
 *                vas_info_domains_free().
 *                Pass NULL if the domain DN strings are not desired.
 *                If this function fails, the array pointed at by domains_dn
 *                is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_NOT_FOUND       - Host does not belong to a site.
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_CONFIG          - Unable to determine default_realm
 *          - VAS_ERR_DNS             - DNS server lookup failed
 *          - VAS_ERR_LDAP            - LDAP error. Use ::vas_err_t functions
 *                                      to obtain LDAP error details
 **/
vas_err_t vas_info_domains( vas_ctx_t* ctx,
                            vas_id_t* id,
                            char*** domains,
                            char*** domains_dn );


/** Free an array of domain names obtained from vas_info_domains().
 *
 * @param ctx     A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param domains The array to be freed.
 *
 **/
void vas_info_domains_free( vas_ctx_t* ctx, char** domains );


/**
 * Obtain names of Active Directory domain controllers in the specified domain.
 *
 * Calls to vas_info_servers() may generate DNS network traffic.
 *
 * @param ctx     A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param domain  The name of the domain you want to get servers for.
 *                Pass in NULL to get servers for the domain to which the
 *                computer is joined. When obtaining global
 *                catalog servers, the domain parameter is ignored
 *                and the API automatically returns all Global
 *                catalogs in the specified site.
 *
 * @param site    The name of the site you want to get servers for. Pass NULL
 *                to get servers for the site to which the computer
 *                is joined. Pass in "*" to get servers for any
 *                site.
 *
 * @param type    The type of server you are looking for:
 *                - VAS_SRVINFO_TYPE_ANY - Any server
 *                - VAS_SRVINFO_TYPE_DC  - Windows domain controller
 *                - VAS_SRVINFO_TYPE_GC  - Windows global catalog
 *                - VAS_SRVINFO_TYPE_PDC - Windows primary domain controller
 *
 * @param servers The address of a char** array that will be allocated and
 *                filled with server hostname strings that are in the same
 *                site as the Unix host. (The array is used similarly to
 *                char *argv[] and is NULL terminated.)
 *                The caller should free the returned
 *                array pointer, with a call to vas_info_servers_free()
 *                If this function fails, the array pointed at by servers
 *                is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_NOT_FOUND       - Host does not belong to a site.
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_CONFIG          - Unable to determine default_realm
 *          - VAS_ERR_DNS             - DNS server lookup failed
 *          - VAS_ERR_LDAP            - LDAP error. Use ::vas_err_t functions
 *                                      to obtain LDAP error details
 **/
vas_err_t vas_info_servers( vas_ctx_t* ctx,
                            const char* domain,
                            const char* site,
                            vas_srvinfo_type_t type,
                            char*** servers );


/** Used to free server arrays obtained from call to vas_info_servers()
 *
 * @param ctx     A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param servers The array to be freed.
 *
 **/
void vas_info_servers_free( vas_ctx_t* ctx, char** servers );


/****************************************************************************
 *                                                                          *
 *                      MISC/UTILITY FUNCTIONS                              *
 *                                                                          *
 ****************************************************************************/

/** Obtain a password by prompting and reading input from the console
 *
 * @param ctx    A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param prompt The string that will be used as the credential prompt.
 *
 * @param verify Optional verification prompt. Useful (for example)
 *               when prompting for a new password. Pass in NULL to skip
 *               verification prompt.
 *
 * @param credstr Returns the credential string. Memory is allocated
 *                by the QAS library and must be freed by the caller using
 *                free().
 *                If this function fails, the memory pointed at by credstr
 *                is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_FAILURE         - Failed to read password from prompt
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 **/
vas_err_t vas_prompt_for_cred_string( vas_ctx_t* ctx,
                                      const char* prompt,
                                      const char* verify,
                                      char** credstr );


/****************************************************************************
 *                                                                          *
 *                        ERROR FUNCTIONS                                   *
 *                                                                          *
 ****************************************************************************/

/**
 * Used to obtain the error code for the last error that occurred using the
 * specified ::vas_ctx_t.
 *
 * @param ctx         The ::vas_ctx_t to get the error code from.
 *
 * @return            The last error code or VAS_ERR_SUCCESS if no error.
 *
 **/
vas_err_t vas_err_get_code( vas_ctx_t* ctx );


/**
 * Used to obtain a formatted error string for the last error that
 * occurred using the specified ::vas_ctx_t.
 *
 * @param ctx         The ::vas_ctx_t to get the error string from.
 *
 * @param with_cause  Pass in a non-zero value to include the cause as
 *                    part of the formatted error string.
 *
 * @return            Pointer to the error string or a default error message
 *                    if no error has occurred. The caller MUST NOT free
 *                    returned pointer. Use strdup() to
 *                    save a copy of the returned string if necessary as
 *                    subsequent calls to vas_err_get_string() will reallocate
 *                    the internal string. This function will never return
 *                    NULL.
 **/
const char* vas_err_get_string( vas_ctx_t* ctx, int with_cause );


/**
 * Clear the last error that occurred on the specified ::vas_ctx_t.
 *
 * @param ctx    The ::vas_ctx_t to clear the error for.
 *
 **/
vas_err_t vas_err_clear( vas_ctx_t* ctx );


/**
 * Used to obtain information about the last error that occurred using the
 * specified ::vas_ctx_t.
 *
 * @param ctx    The ::vas_ctx_t to get error information from.
 *
 * @return       Memory allocated by the QAS library. The resulting
 *               vas_err_info_t must be freed by calling
 *               vas_err_info_free(). The caller MUST check for NULL
 *               return. A NULL return indicates that it was not
 *               possible to construct a vas_err_info_t
 **/
vas_err_info_t* vas_err_get_info( vas_ctx_t* ctx );


/**
 * Free the error info returned by vas_err_info_copy(), vas_err_get_info() and
 * vas_err_get_cause_by_type().
 *
 * @param info   A ::vas_err_info_t returned by previous call to
 *               vas_err_info().
 *
 **/
void vas_err_info_free( vas_err_info_t* info );

/**
 * Make a copy of the error info.
 *
 * @param err    The ::vas_err_info_t value to copy.
 *
 * @param copy   Returns the copied error. The memory for the copy is
 *               allocated by the QAS library and must be freed by
 *               calling vas_err_info_free().
 *               If this function fails, the memory pointed at by copy
 *               is undefined and must not be freed.
 *
 * @return       VAS_ERR_SUCCESS on success or one of the following error codes:
 *               VAS_ERR_NO_MEMORY       - Could not allocate memory
 *               VAS_ERR_INVALID_PARAM   - err or copy were NULL
 *
 **/
vas_err_t vas_err_info_copy( vas_err_info_t* err, vas_err_info_t** copy );



/**
 * Used to obtain a formatted error string from the supplied ::vas_err_info_t.
 *
 * @param ctx         A ::vas_ctx_t from vas_ctx_alloc().
 *
 * @param info        The ::vas_err_info_t to get error info from.
 *
 * @param with_cause  Pass in non-zero to include the cause as part of the
 *                    formatted error string.
 *
 * @return            Returns memory allocated by the QAS library. The
 *                    resulting error string must be freed by calling
 *                    free(). The caller MUST check for NULL return. A
 *                    NULL return indicates that it was not possible to
 *                    construct an error string.
 **/
char* vas_err_info_get_string ( vas_ctx_t* ctx,
                                vas_err_info_t* info,
                                int with_cause );

/**
 * Get the first cause in the error chain which matches the given type.
 * This should be used for example to examine an underlying Kerberos or LDAP
 * error.
 *
 * @param ctx    The ::vas_ctx_t to get error information from.
 *
 * @param type   The ::vas_err_type_t type to match.
 *
 * @return       Memory allocated by the QAS library. The resulting
 *               ::vas_err_info_t must be freed by calling
 *               vas_err_info_free(). The caller MUST check for NULL
 *               return. A NULL return indicates that a match was not
 *               found, or it was not possible to construct a ::vas_err_info_t.
 */
vas_err_info_t* vas_err_get_cause_by_type( vas_ctx_t* ctx,
                                           vas_err_type_t type );


/**
 * Get the name and/or a message describing the specified QAS error without
 * need for QAS context. This function is useful in many debugging situations
 * where vas_ctx_t isn't available or its overhead is unnecessary.
 *
 * @param err       A QAS error value returned from any function.
 *
 * @param name      (Optional) Pointer to where a newly allocated string
 *                  containing the #define name of the error will be placed.
 *                  This memory must be freed by the caller.
 *
 * @param msg       (Optional) Pointer to where a newly allocated string
 *                  containing a titular description of the error will be
 *                  placed. This memory must be freed by the caller.
 *
 */
vas_err_t vas_err_get_string_from_vas_code( vas_err_t err,
                                            char    **name,
                                            char    **msg );

/**
 * Set options that change QAS error logging behavior.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param option    The option to set. The following options are defined:
 *                  - VAS_ERR_OPTION_NEST_ERRORS - Int
 *                    (boolean) setting to control whether or
 *                    not the QAS API should nest all errors that are set
 *                    by calls to libvas_err and libvas_err_wrap. This is
 *                    useful when base errors caused by vas error types:
 *                    VAS_ERR_TYPE_KRB5, VAS_ERR_TYPE_KPASSWD, VAS_ERR_TYPE_LDAP
 *                    and VAS_ERR_TYPE_PKCS11 are buried below multiple  
 *                    errors of the same type.
 *
 * @return          VAS_ERR_SUCCESS on success or one of the following error
 *                  codes:
 *                  - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed.
 *                  - VAS_ERR_NO_MEMORY       - Memory allocation failed.
 */
vas_err_t vas_err_set_option( vas_ctx_t* ctx, vas_err_opt_t option, ... );

/** Get options indicative of QAS error logging behavior.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param option    The option to get. See vas_err_set_option() for the meaning
 *                    of returned values in each of these cases. Just as for
 *                    vas_err_set_option(), the values for the following
 *                    options are returned as output arguments, pointers for
 *                    which the caller provides storage. The types are as
 *                    follows. Unless otherwise noted these take int *value
 *                    and the value returned is to be treated as Boolean (see
 *                    the sample code below).
 *                  - VAS_ERR_OPTION_NEST_ERRORS
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 */
vas_err_t vas_err_get_option( vas_ctx_t* ctx, vas_err_opt_t option, ... );

/****************************************************************************
 *                                                                          *
 *                            QAS USER FUNCTIONS                            *
 *                                                                          *
 ****************************************************************************/

/**
 * Lookup a user account and return a ::vas_user_t.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id        The identity of user to perform Active Directory searches.
 *                  Pass NULL to allow an anonymous search.
 *
 * @param name      The name of the user account to resolve. See
 *                  vas_name_to_dn() for details of the supported name formats.
 *
 * @param flags     The flags to pass to control searching behavior. See
 *                  vas_name_to_dn() for supported flags and their behavior.
 *
 * @param user      Set to point to memory allocated by the QAS
 *                  library. The resulting ::vas_user_t must be freed by
 *                  calling vas_user_free().
 *                  If this function fails, the memory pointed at by user
 *                  is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_NOT_FOUND       - Could not locate a user account
 *                                      with the given name.
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_user_init( vas_ctx_t* ctx,
                         vas_id_t* id,
                         const char* name,
                         int flags,
                         vas_user_t** user );


/**
 * Compare two ::vas_user_t objects for equality.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 * @param user_a    First user to compare.
 * @param user_b    Second user to compare.
 *
 * @return VAS_ERR_SUCCESS if users are equal, VAS_ERR_FAILURE otherwise.
 */
vas_err_t vas_user_compare( vas_ctx_t *ctx,
                            vas_user_t *user_a,
                            vas_user_t *user_b );


/**
 * Determine whether the given user account is a member of the given Active
 * Directory group.
 *
 * If the user is not a member, VAS_ERR_NOT_FOUND is returned, but this
 * error is not added to the ::vas_ctx_t passed in. Therefore you should
 * call this as follows:
 *
 * @code
 * switch ( vas_user_is_member( ctx, id, user, group ) )
 * {
 * case VAS_ERR_SUCCESS:
 *     // The user is a member
 *     ...
 * case VAS_ERR_NOT_FOUND:
 *     // The user is not a member
 *     ...
 *
 * default:
 *     // A different error has occurred
 *     err_str = vas_err_get_string( ctx, 1 );
 *     ...
 * }
 * @endcode
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id        Identity of user to perform Active Directory searches.
 *                  Pass NULL to allow an anonymous search.
 *
 * @param user      A ::vas_user_t for the user account.
 *
 * @param group     A ::vas_group_t for the group to check membership of.
 *
 * @return  VAS_ERR_SUCCESS if the user is a member of the group, or one of
 *          the following error codes:
 *          - VAS_ERR_NOT_FOUND       - The user is not a member of the group
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 *
 * @see vas_group_has_member()
 **/
vas_err_t vas_user_is_member( vas_ctx_t* ctx,
                              vas_id_t* id,
                              vas_user_t* user,
                              vas_group_t* group );

/**
 * Get the Active Directory groups of which a user is a member.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id        Identity of user to perform Active Directory searches
 *                  Pass NULL to allow an anonymous search.
 *
 * @param user      A ::vas_user_t for the user account.
 *
 * @param groups    Used to return the groups of which the user is a member.
 *                  *groups will be a NULL-terminated array of vas_group_t
 *                  pointers and must be freed with vas_group_free_groups().
 *                  If this function fails, the array pointed at by groups
 *                  is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 *
 **/
vas_err_t vas_user_get_groups( vas_ctx_t* ctx,
                               vas_id_t* id,
                               vas_user_t* user,
                               vas_group_t*** groups );

/**
 * Get the Active Directory groups sids of which a user is a member.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id        Identity of user to perform Active Directory searches
 *                  Pass NULL to allow an anonymous search.
 *
 * @param user      A ::vas_user_t for the user account.
 *
 * @param groups    Used to return the groups of which the user is a member.
 *                  *groups will be a NULL-terminated array of SIDS in string
 *                  format and must be freed with vas_stringarray_free().
 *                  If this function fails, the array pointed at by groups
 *                  is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 *
 **/
vas_err_t vas_user_get_groups_sid_strings ( vas_ctx_t* ctx,
                               vas_id_t* id,
                               vas_user_t* user,
                               char*** groups );

/**
 * Get arbitrary attributes from the Active Directory user object for this
 * ::vas_user_t.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id        Identity of user used to perform Active Directory searches.
 *                  Pass NULL to perform anonymous searches.
 *
 * @param user      A ::vas_user_t for the user account.
 *
 * @param anames    NULL terminated array of attribute names to retrieve.
 *
 * @param attrs     ::vas_attrs_t which is allocated by the QAS function. This
 *                  must be freed with vas_attrs_free(). The values for the
 *                  requested attributes can be obtained with the vas_vals_get*
 *                  family of functions.
 *                  If this function fails, the value pointed at by user
 *                  is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or on of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 *
 **/
vas_err_t vas_user_get_attrs( vas_ctx_t* ctx,
                              vas_id_t* id,
                              vas_user_t* user,
                              const char* const* anames,
                              vas_attrs_t** attrs );


/**
 * Get the distinguished name (DN) for a user account.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id        Identity of user used to perform Active Directory searches.
 *                  Pass NULL to perform anonymous searches.
 *
 * @param user      A ::vas_user_t for the user account.
 *
 * @param dn        Used to return the DN of the user account. Must be
 *                  freed by calling free().
 *                  If this function fails, the value pointed at by dn
 *                  is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_user_get_dn( vas_ctx_t* ctx,
                           vas_id_t* id,
                           vas_user_t* user,
                           char** dn );

/**
 * Get the Active Directory domain to which the given user belongs.
 *
 * @param ctx      A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id       Identity of user used to perform Active Directory searches.
 *                 Pass NULL to perform anonymous searches.
 *
 * @param user     A ::vas_user_t for the user account.
 *
 * @param domain   Used to return the domain of the user account.
 *                 Must be freed by calling free().
 *                 If this function fails, the value pointed at by domain
 *                 is undefined and must not be freed.
 *
 * @since 3.0.1
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_user_get_domain( vas_ctx_t* ctx,
                               vas_id_t* id,
                               vas_user_t* user,
                               char** domain );


/**
 * Get the security account manager (SAM) name (the NETBIOS name) for a user.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id        Identity of user used to perform Active Directory searches.
 *                  Pass NULL to perform anonymous searches.
 * @param user      A ::vas_user_t for the user account.
 *
 * @param sam       Used to return the SAM account name of the user
 *                  object. Must be freed by calling free().
 *                  If this function fails, the value pointed at by sam
 *                  is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_user_get_sam_account_name( vas_ctx_t* ctx,
                                         vas_id_t* id,
                                         vas_user_t* user,
                                         char** sam );

/**
 * Get the security identity (SID) for a user account.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id        Identity of user used to perform Active Directory searches.
 *                  Pass NULL to perform an anonymous searches.
 *
 * @param user      A ::vas_user_t for the user account.
 *
 * @param sid       Used to return the SID of the user account. Must be
 *                  freed by calling free().
 *                  If this function fails, the value pointed at by sid
 *                  is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or non-zero errno on error. The
 *          following return values are defined:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_user_get_sid( vas_ctx_t *ctx,
                            vas_id_t *id,
                            vas_user_t *user,
                            char **sid );

/**
 * Get the GUID str for a user account.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id        Identity of user used to perform Active Directory searches.
 *                  Pass NULL to perform an anonymous searches.
 *
 * @param user      A ::vas_user_t for the user account.
 *
 * @param guidstr   Used to return the GUID string of the user account. Must be
 *                  freed by calling free().
 *                  If this function fails, the value pointed at by sid
 *                  is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or non-zero errno on error. The
 *          following return values are defined:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_user_get_guidstr( vas_ctx_t *ctx,
                                vas_id_t *id,
                                vas_user_t *user,
                                char **guidstr );

/**
 * Get the user principal name (UPN) for a user account.
 *
 * @param ctx     A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id      Identity of user used to perform Active Directory searches.
 *                Pass NULL to perform anonymous searches.
 *
 * @param user    A ::vas_user_t for the user account.
 *
 * @param upn     Used to return the UPN of the user account. Must be
 *                freed by calling free().
 *                If this function fails, the value pointed at by upn
 *                is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_user_get_upn( vas_ctx_t* ctx,
                            vas_id_t* id,
                            vas_user_t* user,
                            char** upn );

/**
 * Get the passwd entry for a Unix enabled user.
 *
 * This function returns a struct passwd which contains the Unix username
 * uid, gid etc of a user. If the user is not Unix enabled VAS_ERR_NOT_FOUND
 * is returned. Memory for both the passwd structure and the string pointers
 * in this structure is allocated in a contiguous buffer that must be freed
 * by calling free() on the returned struct passwd pointer. This function
 * does not search Active Directory directly, but uses the QAS cache mechanism
 * to look up the information. The returned passwd struct contains the
 * user information directly from Active Directory, which will not be validated
 * for the local Unix system (for example, the UID is not validated to ensure
 * that is within the valid range for the Unix system). This function does not
 * call the system getpwnam() function.
 *
 * @param ctx      A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id       Currently unused, may be NULL.
 *
 * @param user     A ::vas_user_t for the user account.
 *
 * @param pwd      struct passwd for returning information about a Unix-enabled
 *                 user. Must be freed by calling free().
 *                 If this function fails, the structure pointed at by pwd
 *                 is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_NOT_FOUND       - User is not a Unix enabled user
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_user_get_pwinfo( vas_ctx_t* ctx,
                               vas_id_t* id,
                               vas_user_t* user,
                               struct passwd** pwd );

/**
 * Get the Kerberos client name for a user account.
 *
 * This function returns the user account's Kerberos principal name
 * for retrieving client tickets. This is equivalent to
 * samAccountName\@realm. This name is always guaranteed to work for
 * obtaining ticket granting tickets for any user account.
 *
 * @param ctx           A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id            Identity of user used to perform Active Directory searches.
 *                      Pass NULL to perform anonymous searches.
 *
 * @param user          A ::vas_user_t for the user account.
 *
 * @param client_name   Used to return the Kerberos client name of the user
 *                      account. Must be freed by calling free().
 *                      If this function fails, the value pointed at by
 *                      client_name is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_user_get_krb5_client_name( vas_ctx_t* ctx,
                                         vas_id_t* id,
                                         vas_user_t* user,
                                         char** client_name );

/**
 * Get account control flags for this user account.
 *
 * @param ctx               A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id                Identity of user used to perform Active Directory
                            searches. Pass NULL to perform anonymous searches.
 *
 * @param user              A ::vas_user_t for the user account.
 *
 * @param account_control   Pointer to an integer to return the flags. Must not
 *                          be NULL.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_user_get_account_control( vas_ctx_t* ctx,
                                        vas_id_t* id,
                                        vas_user_t* user,
                                        int* account_control );

/**
 * Check if a user has access to a given service.
 *
 * This function queries the QAS users.allow and users.deny files, or the
 * service specific rule set if configured, to determine
 * whether a given user may access a given service on this machine.
 *
 * @param ctx               A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param user              A ::vas_user_t for the user account.
 *
 * @param service           Service to check access for. This may be NULL to
 *                          query the default users.allow and users.deny file.
 *                          If no allow or deny file has been configured for the
 *                          given service, then the default users.allow and
 *                          users.deny files will be used as well. For
 *                          information on configuring these access control files,
 *                          see the QAS Administrator's Guide.
 *
 * @return  VAS_ERR_SUCESS if the user is allowed access, or one of the
 *          following error codes:
 *          - VAS_ERR_ACCESS          - Access is denied for the service.
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_user_check_access( vas_ctx_t* ctx,
                                 vas_user_t* user,
                                 const char* service );

/**
 * Check to see if a user has a UID conflict with another user.
 *
 * This function will determine whether any Unix accounts on the current Unix
 * host have the same Unix UID number as the given user. The set of Unix
 * accounts searched include the local Unix accounts, the set of Active Directory
 * Unix accounts configured for the given system, and any other Unix accounts
 * available to the Unix host through other account backends (for example, NIS).
 *
 * @param ctx               A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param user              A ::vas_user_t for the user account.
 *
 * @return  VAS_ERR_SUCCESS if no conflicts were found, or one of the
 *          following error codes:
 *          - VAS_ERR_EXISTS          - A user with a conflicting UID was found
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_user_check_conflicts( vas_ctx_t* ctx, vas_user_t* user );

/**
 * Free a ::vas_user_t.
 *
 * @param ctx           A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param user          A ::vas_user_t to free.
 *
 **/
void vas_user_free( vas_ctx_t* ctx, vas_user_t* user );

/**
 * Check to see if a user is in a group.
 *
 * Written for sudo_vas plugin. 
 * 
 * Checks the cache for user as member of group. If the group is not cached,
 * and user isn't a member after loading group, group4user is tried and membership
 * is checked again.
 *
 * @param user              A unix name for a QAS user. 
 *
 * @param group             A name for a group, sam, domain\sam, sam@domain or
 *                          SID. 
 *
 * @return  VAS_ERR_SUCCESS if user is a member of group, VAS_ERR_FAILURE if not.
 **/
vas_err_t vas_unixuser_check_nonunix_membership( vas_ctx_t *ctx, const char *user, const char* group );

/**
 * Check to see if vasd is running
 *
 * Written for sudo_vas plugin. 
 * 
 * @return  VAS_ERR_SUCCESS if vasd is running, VAS_ERR_FAILURE if not.
 **/
vas_err_t vas_is_vasd_running( void );

/****************************************************************************
 *                                                                          *
 *                           QAS GROUP FUNCTIONS                            *
 *                                                                          *
 ****************************************************************************/

/**
 * Create a vas_group_t for the given Active Directory group
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id        Identity of user used to perform Active Directory searches.
 *                  Pass NULL to perform an anonymous searches.
 *
 * @param name      Name of the group to resolve. See
 *                  vas_name_to_dn() for details of the supported name formats.
 *
 * @param flags     Flags to pass to control searching behavior. See
 *                  vas_name_to_dn() for supported flags and their behavior.
 *
 * @param group     Address of a ::vas_group_t* that will be set to point to
 *                  memory allocated by the QAS library. The resulting
 *                  ::vas_group_t must be freed by calling vas_group_free().
 *                  If this function fails, the memory pointed at by group
 *                  is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_NOT_FOUND       - Could not locate a group
 *                                      with the given name.
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_group_init( vas_ctx_t* ctx,
                          vas_id_t* id,
                          const char* name,
                          int flags,
                          vas_group_t** group );


/**
 * Compare two ::vas_group_t objects for equality.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 * @param group_a   First group to compare.
 * @param group_b   Second group to compare.
 *
 * @return VAS_ERR_SUCCESS if users are equal, VAS_ERR_FAILURE otherwise.
 */
vas_err_t vas_group_compare( vas_ctx_t *ctx,
                             vas_group_t *group_a,
                             vas_group_t *group_b );


/**
 * Determine whether a group has the given user as a member.
 *
 * If the user is not a member, VAS_ERR_NOT_FOUND is returned, but this
 * error is not added to the vas_ctx_t passed in. Therefore you should
 * call this as follows:
 *
 * @code
 * switch ( vas_group_has_member( ctx, id, group, user ) )
 * {
 * case VAS_ERR_SUCCESS:
 *     // The user is a member
 *     ...
 * case VAS_ERR_NOT_FOUND:
 *     // The user is not a member
 *     ...
 *
 * default:
 *     // A different error has occurred
 *     err_str = vas_err_get_string( ctx, 1 );
 *     ...
 * }
 * @endcode
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 * @param id        Identity of user to perform Active Directory searches as.
 *                  Pass NULL to perform anonymous searches.
 * @param group     A ::vas_group_t for the group.
 * @param user      A ::vas_user_t for the user account to check membership.
 *
 * @return  VAS_ERR_SUCCESS if the user is a member of the group, or one of the
 *          following error codes:
 *          - VAS_ERR_NOT_FOUND       - The user is not a member
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 *
 **/
vas_err_t vas_group_has_member( vas_ctx_t* ctx,
                                vas_id_t* id,
                                vas_group_t* group,
                                vas_user_t* user );

/**
 * Lookup arbitrary attributes for the given group.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 * @param id        Identity of user used to perform Active Directory searches.
 *                  Pass NULL to perform anonymous searches.
 * @param group     A ::vas_group_t for the group.
 * @param anames    NULL terminated array of attribute names to get.
 * @param attrs     Address of a ::vas_attrs_t pointer that will be set to
 *                  memory allocated by the QAS library. Must be freed by
 *                  calling vas_attrs_free().
 *                  If this function fails, the pionter pointed at by attrs
 *                  is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 *
 **/
vas_err_t vas_group_get_attrs( vas_ctx_t* ctx,
                               vas_id_t* id,
                               vas_group_t* group,
                               const char** anames,
                               vas_attrs_t** attrs );

/**
 * Get the GUID str for a group account.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id        Identity of user used to perform Active Directory searches.
 *                  Pass NULL to perform an anonymous searches.
 *
 * @param group     A ::vas_group_t for the group.
 *
 * @param guidstr   Used to return the GUID string of the group. Must be
 *                  freed by calling free().
 *                  If this function fails, the value pointed at by sid
 *                  is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or non-zero errno on error. The
 *          following return values are defined:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_group_get_guidstr( vas_ctx_t *ctx,
                                vas_id_t *id,
                                vas_group_t *group,
                                char **guidstr );


/**
 * Get the distinguished name (DN) for a group.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 * @param id        Identity of user used to perform Active Directory searches.
 *                  Pass NULL to perform anonymous searches.
 * @param group     A ::vas_group_t for the group.
 * @param dn        Used to return the DN of the group. Must be freed by
 *                  calling free().
 *                  If this function fails, the value pointed at by dn
 *                  is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_group_get_dn( vas_ctx_t* ctx,
                            vas_id_t* id,
                            vas_group_t* group,
                            char** dn );

/**
 * Get the Active Directory domain the group exists in.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 * @param id        Identity of user used to perform Active Directory searches.
 *                  Pass NULL to perform anonymous searches.
 * @param group     A ::vas_group_t for the group.
 * @param domain    Used to return the domain the group exists in. Must be
 *                  freed by calling free().
 *                  If this function fails, the value pointed at by domain
 *                  is undefined and must not be freed.
 *
 * @since 3.0.1
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_group_get_domain( vas_ctx_t* ctx,
                                vas_id_t* id,
                                vas_group_t* group,
                                char** domain );

/**
 * Get the security identity (SID) for a group.
 *
 * @param ctx      A :vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id       Identity of user used to perform Active Directory searches.
 *                 Pass NULL to perform anonymous searches.
 *
 * @param group    A ::vas_group_t for the group.
 *
 * @param sid      Used to return the SID of the group. Must be freed by
 *                 calling free().
 *                 If this function fails, the value pointed at by sid
 *                 is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_group_get_sid( vas_ctx_t *ctx,
                             vas_id_t *id,
                             vas_group_t *group,
                             char **sid );


/**
 * Get the group entry for a Unix enabled group
 *
 * This function returns a struct group which contains the Unix group,
 * gid and members of a group. If the group is not Unix enabled VAS_ERR_NOT_FOUND
 * is returned. Memory for both the group structure and the string pointers
 * in this structure is allocated in a contiguous buffer that must be freed
 * by calling free() on the returned struct group pointer. This function
 * does not search Active Directory directly, but uses the QAS cache mechanism
 * to look up the information. The returned group struct contains the
 * user information directly from Active Directory, which will not be validated
 * for the local Unix system (for example, the GID is not validated to ensure
 * that is within the valid range for the Unix system). This function does NOT
 * call the system getgrnam() function.
 *
 * @param ctx      A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id       Currently unused, may be NULL.
 *
 * @param group    A ::vas_group_t for the group account.
 *
 * @param grp      pointer to struct group for returning information about a
 *                 Unix-enabled group. Must be freed by calling free().
 *                 If this function fails, the structure pointed at by grp
 *                 is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_NOT_FOUND       - Group is not a Unix enabled group
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_group_get_grinfo( vas_ctx_t* ctx,
                                vas_id_t* id,
                                vas_group_t* group,
                                struct group** grp );


/**
 * Free a ::vas_group_t.
 *
 * @param ctx           A ::vas_ctx_t obtained from vas_ctx_alloc().
 * @param group         A ::vas_group_t to free.
 *
 **/
void vas_group_free( vas_ctx_t* ctx, vas_group_t* group );

/**
 * Free an array of ::vas_group_t pointers.
 *
 * This a convenience function which can be used to free a list of
 * groups returned from vas_user_get_groups().
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc()
 *
 * @param groups    A NULL terminated array of ::vas_group_t pointers.
 *
 * @return          VAS_ERR_SUCCESS on success or one of the following
 *                  error codes:
 *                  - VAS_ERR_INVALID_PARAM - An invalid parameter was passed
 **/
vas_err_t vas_group_free_groups( vas_ctx_t* ctx, vas_group_t** groups );


/****************************************************************************
 *                                                                          *
 *                      QAS SERVICE ACCOUNT FUNCTIONS                       *
 *                                                                          *
 ****************************************************************************/

/**
 * Create a ::vas_service_t for the given Active Directory service account.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id        Identity of user to perform Active Directory searches as.
 *                  Pass NULL to perform anonymous searches.
 *
 * @param name      Name of the service account to resolve. See
 *                  vas_name_to_dn() for details of the supported name formats.
 *
 * @param flags     Flags to pass to control searching behavior. See
 *                  vas_name_to_dn() for supported flags and their behavior.
 *
 * @param service   Set to point to memory allocated by the QAS
 *                  library. The resulting ::vas_service_t must be freed by
 *                  calling vas_service_free().
 *                  If this function fails, the value pointed at by service
 *                  is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_NOT_FOUND       - Could not locate a service account
 *                                      with the given name.
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_service_init( vas_ctx_t* ctx,
                            vas_id_t* id,
                            const char* name,
                            int flags,
                            vas_service_t** service );

/**
 * Compare two ::vas_service_t objects for equality.
 *
 * @param ctx           A ::vas_ctx_t obtained from vas_ctx_alloc().
 * @param service_a     First service to compare.
 * @param service_b     Second service to compare.
 *
 * @return VAS_ERR_SUCCESS if users are equal, VAS_ERR_FAILURE otherwise.
 */
vas_err_t vas_service_compare( vas_ctx_t *ctx,
                               vas_service_t *service_a,
                               vas_service_t *service_b );


/**
 * Lookup attributes for the given Active Directory service account.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id        Identity of user to perform Active Directory searches as.
 *                  Pass NULL to perform anonymous searches.
 *
 * @param service   A ::vas_service_t for the service account.
 *
 * @param anames    A NULL terminated array of attributes names to lookup.
 *
 * @param attrs     Address of a ::vas_attrs_t pointer that is set to memory
 *                  allocated by the QAS library. Must be freed by calling
 *                  vas_attrs_free(). The attribute values can be obtained
 *                  with the vas_vals_get* family of functions.
 *                  If this function fails, the memory pointed at by attrs
 *                  is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 *
 **/
vas_err_t vas_service_get_attrs( vas_ctx_t* ctx,
                                 vas_id_t* id,
                                 vas_service_t* service,
                                 const char* const* anames,
                                 vas_attrs_t** attrs );

/**
 * Get the distinguished name (DN) for a service account.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id        Identity of user used to perform Active Directory searches.
 *                  Pass NULL to perform anonymous searches.
 *
 * @param service   A ::vas_service_t for the service account.
 *
 * @param dn        Used to return the DN of the service account. Must be
 *                  freed by calling free().
 *                  If this function fails, the value pointed at by dn
 *                  is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_service_get_dn( vas_ctx_t* ctx,
                              vas_id_t* id,
                              vas_service_t* service,
                              char** dn );


/**
 * Get the Active Directory domain to which the given service belongs.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id        Identity of user used to perform Active Directory searches.
 *                  Pass NULL to perform anonymous searches.
 *
 * @param service   A ::vas_service_t for the service account.
 *
 * @param domain    Used to return the domain of the service account.
 *                  Must be freed by calling free().
 *                  If this function fails, the value pointed at by domain
 *                  is undefined and must not be freed.
 *
 * @since 3.0.1
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_service_get_domain( vas_ctx_t* ctx,
                                  vas_id_t* id,
                                  vas_service_t* service,
                                  char** domain );


/**
 * Get the Kerberos client name for a service account.
 *
 * This function returns the service account's Kerberos principal name
 * for retrieving client tickets. This is equivalent to
 * samAccountName\@realm. This name is always guaranteed to work for
 * obtaining ticket granting tickets (TGT) for any service account.
 *
 * @param ctx           A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id            Identity of user used to perform Active Directory searches.
 *                      Pass NULL to perform anonymous searches.
 *
 * @param service       A ::vas_service_t for the service account.
 *
 * @param client_name   Used to return the Kerberos client name of the service
 *                      account. Must be freed by calling free().
 *                      If this function fails, the value pointed at by
 *                      client_name is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_service_get_krb5_client_name( vas_ctx_t* ctx,
                                            vas_id_t* id,
                                            vas_service_t* service,
                                            char** client_name );

/**
 * Get a list of service principal names (SPNs) for a service account.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id        Identity of user used to perform Active Directory searches.
 *                  Pass NULL to perform anonymous searches.
 *
 * @param service   A ::vas_service_t for the service account.
 *
 * @param spns      Used to return a NULL terminated array of the SPNs of
 *                  the service account. Must be freed by calling free()
 *                  on each member of the list and then the list itself.
 *                  If this function fails, the array pointed at by spns
 *                  is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_service_get_spns( vas_ctx_t* ctx,
                                vas_id_t* id,
                                vas_service_t* service,
                                char*** spns );

/**
 * Get the user principal name (UPN) for a service account.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id        Identity of user used to perform Active Directory searches.
 *                  Pass NULL to perform anonymous searches.
 *
 * @param service   A ::vas_service_t for the service account.
 *
 * @param upn       Used to return the UPN of the service account. Must be
 *                  freed by calling free().
 *                  If this function fails, the value pointed at by upn
 *                  is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_service_get_upn( vas_ctx_t* ctx,
                               vas_id_t* id,
                               vas_service_t* service,
                               char** upn );

/**
 * Free a ::vas_service_t.
 *
 * @param ctx           A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param service       A ::vas_service_t to free.
 *
 **/
void vas_service_free( vas_ctx_t* ctx, vas_service_t* service );



/****************************************************************************
 *                                                                          *
 *                   COMPUTER OBJECT RELATED FUNCTIONS                      *
 *                                                                          *
 ****************************************************************************/

/**
 * Lookup a computer object and return a ::vas_computer_t.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id        Identity of user to perform Active Directory searches.
 *                  Pass NULL to perform anonymous searches.
 *
 * @param name      Name of the computer object to resolve. See
 *                  vas_name_to_dn() for details of the supported name formats.
 *
 * @param flags     Flags to pass to control searching behavior. See
 *                  vas_name_to_dn() for supported flags and their behavior.
 *
 * @param computer  Set to point to memory allocated by the QAS
 *                  library. The resulting ::vas_computer_t must be freed by
 *                  calling vas_computer_free().
 *                  If this function fails, the memory pointed at by computer
 *                  is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_NOT_FOUND       - Could not locate a computer object
 *                                      with the given name.
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 */
vas_err_t vas_computer_init( vas_ctx_t* ctx,
                             vas_id_t* id,
                             const char* name,
                             int flags,
                             vas_computer_t** computer );


/**
 * Compare two ::vas_computer_t objects for equality.
 *
 * @param ctx           A ::vas_ctx_t obtained from vas_ctx_alloc().
 * @param computer_a    First computer to compare.
 * @param computer_b    Second computer to compare.
 *
 * @return VAS_ERR_SUCCESS if users are equal, VAS_ERR_FAILURE otherwise.
 */
vas_err_t vas_computer_compare( vas_ctx_t *ctx,
                                vas_computer_t *computer_a,
                                vas_computer_t *computer_b );


/**
 * Determine whether the given computer object is a member of the given
 * Active Directory group.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id        Identity of user used to perform Active Directory searches.
 *                  Pass NULL to perform anonymous searches.
 *
 * @param computer  A ::vas_computer_t for the computer object.
 *
 * @param group     A ::vas_group_t for the group to check membership of.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_NOT_FOUND       - The user is not a member
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 *
 * @see vas_user_is_member()
 **/
vas_err_t vas_computer_is_member( vas_ctx_t* ctx,
                                  vas_id_t* id,
                                  vas_computer_t* computer,
                                  vas_group_t* group );

/**
 * Lookup attributes for the given computer object.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id        Identity of user used to perform Active Directory searches.
 *                  Pass NULL to perform anonymous searches.
 *
 * @param computer  A ::vas_computer_t for the computer object.
 *
 * @param anames    A NULL terminated array of attribute names to retrieve.
 *
 * @param attrs     Address of a ::vas_attrs_t pointer that is set to memory
 *                  allocated by the QAS library. Must be freed by calling
 *                  vas_attrs_free(). The attribute values can be obtained
 *                  with the vas_vals_get* family of functions.
 *                  If this function fails, the memory pointed at by attrs
 *                  is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 *
 **/
vas_err_t vas_computer_get_attrs( vas_ctx_t* ctx,
                                  vas_id_t* id,
                                  vas_computer_t* computer,
                                  const char* const* anames,
                                  vas_attrs_t** attrs );

/**
 * Get the distinguished name (DN) for a computer object.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id        Identity of user used to perform Active Directory searches.
 *                  Pass NULL to perform anonymous searches.
 *
 * @param computer  A ::vas_computer_t for the computer object.
 *
 * @param dn        Used to return the DN of the computer object. Must be
 *                  freed by calling free().
 *                  If this function fails, the value pointed at by dn
 *                  is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_computer_get_dn( vas_ctx_t* ctx,
                               vas_id_t* id,
                               vas_computer_t* computer,
                               char** dn );

/**
 * Get the name for a computer object by which it is known to the Domain Name
 * Service (DNS).
 *
 * @param ctx           A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id            Identity of user used to perform Active Directory searches.
 *                      Pass NULL to perform anonymous searches.
 *
 * @param computer      A ::vas_computer_t for the computer object.
 *
 * @param dns_hostname  Used to return the DNS name of the computer object.
 *                      Must be freed by calling free().
 *                      If this function fails, the value pointed at by
 *                      dns_hostname is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_computer_get_dns_hostname( vas_ctx_t* ctx,
                                         vas_id_t* id,
                                         vas_computer_t* computer,
                                         char** dns_hostname );

/**
 * Get the Active Directory domain the given computer exists in.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id        Identity of user used to perform Active Directory searches.
 *                  Pass NULL to perform anonymous searches.
 *
 * @param computer  A ::vas_computer_t for the computer object.
 *
 * @param domain    Used to return the domain of the computer object. Must be
 *                  freed by calling free().
 *                  If this function fails, the value pointed at by domain
 *                  is undefined and must not be freed.
 *
 * @since 3.0.1
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_computer_get_domain( vas_ctx_t* ctx,
                                  vas_id_t* id,
                                  vas_computer_t* computer,
                                  char** domain );

/**
 * Get the security identity (SID) for a computer object.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id        Identity of user used to perform Active Directory searches.
 *                  Pass NULL to perform anonymous searches.
 *
 * @param computer  A ::vas_computer_t for the computer object.
 *
 * @param sid       Used to return the sid of the computer object. Must be
 *                  freed by calling free().
 *                  If this function fails, the value pointed at by sid
 *                  is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_computer_get_sid( vas_ctx_t* ctx,
                                vas_id_t* id,
                                vas_computer_t* computer,
                                char** sid );

/**
 * Get the service principal names (SPNs) for a computer object.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id        Identity of user used to perform Active Directory searches.
 *                  Pass NULL to perform anonymous searches.
 *
 * @param computer  A ::vas_computer_t for the computer object.
 *
 * @param spns      Used to return the SPNs of the computer object. This is a
 *                  NULL terminated array. Each item in the array and the
 *                  array itself must be freed by calling free().
 *                  If this function fails, the array pointed at by spns
 *                  is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_computer_get_spns( vas_ctx_t* ctx,
                                 vas_id_t* id,
                                 vas_computer_t* computer,
                                 char*** spns );

/**
 * Get the security account manager (SAM) name (the NETBIOS name) for a
 * computer object.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id        Identity of user used to perform Active Directory searches.
 *                  Pass NULL to perform anonymous searches.
 *
 * @param computer  A ::vas_computer_t for the computer object.
 *
 * @param sam       Used to return the SAM account name of the computer
 *                  object. Must be freed by calling free().
 *                  If this function fails, the value pointed at by sam
 *                  is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_computer_get_sam_account_name( vas_ctx_t* ctx,
                                             vas_id_t* id,
                                             vas_computer_t* computer,
                                             char** sam );

/**
 * Get the user principal name (UPN) for a computer object.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id        Identity of user used to perform Active Directory searches.
 *                  Pass NULL to perform anonymous searches.
 *
 * @param computer  A ::vas_computer_t for the computer object.
 *
 * @param upn       Used to return the UPN of the computer object. Must be
 *                  freed by calling free().
 *                  If this function fails, the value pointed at by upn
 *                  is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_computer_get_upn( vas_ctx_t* ctx,
                                vas_id_t* id,
                                vas_computer_t* computer,
                                char** upn );

/**
 * Get the Kerberos client name for a computer object.
 *
 * This function returns the computer object's Kerberos principal name
 * for retrieving client tickets. This is equivalent to NETBIOS\$\@realm where
 * NETBIOS is the NETBIOS name or samAccountName of the computer object.
 * This name is always guaranteed to work for obtaining ticket granting
 * tickets for any computer object.
 *
 * @param ctx           A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id            Identity of user used to perform Active Directory searches.
 *                      Pass NULL to perform anonymous searches.
 *
 * @param computer      A ::vas_computer_t for the computer object.
 *
 * @param client_name   Used to return the Kerberos client name
 *                      of the computer object. Must be freed by calling
 *                      free().
 *                      If this function fails, the value pointed at by
 *                      client_name is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_computer_get_krb5_client_name( vas_ctx_t* ctx,
                                             vas_id_t* id,
                                             vas_computer_t* computer,
                                             char** client_name );


/**
 * Get the Kerberos service name for a computer object.
 *
 * This function returns the computer object's Kerberos principal name
 * for obtaining service tickets. This is equivalent to
 * HOST/NETBIOS\$\@realm where NETBIOS is the NETBIOS  or samAccountName.
 * This name is always guaranteed to work for obtaining service tickets for
 * any computer object.
 *
 * Note: this function does not return the servicePrincipalName attribute
 * from Active Directory, which is not guaranteed to be set.
 * To retrieve the SPNs using the servicePrincipalName
 * attribute, use the vas_computer_get_spns() function.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id        Identity of user used to perform Active Directory searches.
 *                  Pass NULL to perform anonymous searches.
 *
 * @param computer  A ::vas_computer_t for the computer object.
 *
 * @param host_spn  Used to return the Kerberos service name of the computer
 *                  object. Must be freed by calling free().
 *                  If this function fails, the value pointed at by host_spn
 *                  is undefined and must not be freed.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_computer_get_host_spn( vas_ctx_t* ctx,
                                     vas_id_t* id,
                                     vas_computer_t* computer,
                                     char** host_spn );

/**
 * Get account control flags for this computer object.
 *
 * @param ctx               A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id                Identity of user used to perform Active Directory
 *                          searches. Pass NULL to perform anonymous searches.
 *
 * @param computer          A ::vas_computer_t for the computer object.
 *
 * @param account_control   Pointer to an integer to return the flags. Must not
 *                          be NULL.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM   - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY       - Memory allocation failed
 *          - VAS_ERR_FAILURE         - Unspecified failure
 **/
vas_err_t vas_computer_get_account_control( vas_ctx_t* ctx,
                                            vas_id_t* id,
                                            vas_computer_t* computer,
                                            int* account_control );

/**
 * Free a ::vas_computer_t.
 *
 * @param ctx           A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param computer      A ::vas_computer_t to free.
 *
 **/
void vas_computer_free( vas_ctx_t* ctx, vas_computer_t* computer );


/****************************************************************************
 *                                                                          *
 *                   LOGGING RELATED FUNCTIONS                              *
 *                                                                          *
 ****************************************************************************/

/** Initialize per-process logging to syslog or log file
 *
 * @param log_mode    Pass in one of the following values:
 *                    0: no logging at all
 *                    1: will log to syslog
 *                    3: will log to stderr
 *                    4: will log to a file
 *
 * @param log_debug_level Pass in one of the following vas_log_debug_level enum values:
 *                    Set to 0 to not get debug messages
 *                    Set to 1 to get verbose app debug messages
 *                    Set to 2 to get verbose app debug messages
 *                    Set to 3 to get api and libvas debug messages
 *                    Set to 4 to get libldap/krb5 debug messages
 *                    Set to 5 to get libvasdb debug messages
 *                    Set to 6 to get all messages
 *
 * @parm log_file	  Write debug out to this file. This param will be ignored if 
 *                    log_mode is not set to 4.
 **/
vas_err_t vas_log_init_log( int log_mode,
                            int log_debug_level,
                            const char* log_file );

/** Deinitialize per-process logging to syslog or log file
*
**/
void vas_log_deinit_log(void);

/* Include the deprecated API - this is last to make sure we have all definitions */
#include "vas_deprecated.h"


#ifdef __cplusplus
}
#endif

#endif /* VASAPI_H_INCLUDED */
