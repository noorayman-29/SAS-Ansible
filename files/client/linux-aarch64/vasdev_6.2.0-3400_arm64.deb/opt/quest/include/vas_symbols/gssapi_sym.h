#ifndef gssapi_sym_h
#define gssapi_sym_h

/* 8003.c */
#define _gsskrb5_encode_om_uint32 vassym__gsskrb5_encode_om_uint32
#define _gsskrb5_encode_be_om_uint32 vassym__gsskrb5_encode_be_om_uint32
#define _gsskrb5_decode_om_uint32 vassym__gsskrb5_decode_om_uint32
#define _gsskrb5_decode_be_om_uint32 vassym__gsskrb5_decode_be_om_uint32
#define _gsskrb5_create_8003_checksum vassym__gsskrb5_create_8003_checksum
#define _gsskrb5_verify_8003_checksum vassym__gsskrb5_verify_8003_checksum

/* accept_sec_context.c */
#define gssapi_keytab_mutex vassym_gssapi_keytab_mutex
#define _gsskrb5_keytab vassym__gsskrb5_keytab
#define _gsskrb5_register_acceptor_identity vassym__gsskrb5_register_acceptor_identity
#define _gsskrb5i_is_cfx vassym__gsskrb5i_is_cfx
#define _gsskrb5_accept_sec_context vassym__gsskrb5_accept_sec_context

/* acquire_cred.c */
#define __gsskrb5_cred_store_find vassym___gsskrb5_cred_store_find
#define __gsskrb5_ccache_lifetime vassym___gsskrb5_ccache_lifetime
#define _gsskrb5_acquire_cred_from vassym__gsskrb5_acquire_cred_from

/* add_cred.c */
#define _gsskrb5_add_cred_from vassym__gsskrb5_add_cred_from

/* address_to_krb5addr.c */
#define _gsskrb5i_address_to_krb5addr vassym__gsskrb5i_address_to_krb5addr

/* aeap.c */
#define _gk_wrap_iov vassym__gk_wrap_iov
#define _gk_unwrap_iov vassym__gk_unwrap_iov
#define _gk_wrap_iov_length vassym__gk_wrap_iov_length

/* arcfour.c */
#define _gssapi_get_mic_arcfour vassym__gssapi_get_mic_arcfour
#define _gssapi_verify_mic_arcfour vassym__gssapi_verify_mic_arcfour
#define _gssapi_wrap_arcfour vassym__gssapi_wrap_arcfour
#define _gssapi_unwrap_arcfour vassym__gssapi_unwrap_arcfour
#define _gssapi_wrap_size_arcfour vassym__gssapi_wrap_size_arcfour
#define _gssapi_wrap_iov_length_arcfour vassym__gssapi_wrap_iov_length_arcfour
#define _gssapi_wrap_iov_arcfour vassym__gssapi_wrap_iov_arcfour
#define _gssapi_unwrap_iov_arcfour vassym__gssapi_unwrap_iov_arcfour

/* canonicalize_name.c */
#define _gsskrb5_canonicalize_name vassym__gsskrb5_canonicalize_name

/* creds.c */
#define _gsskrb5_export_cred vassym__gsskrb5_export_cred
#define _gsskrb5_import_cred vassym__gsskrb5_import_cred

/* ccache_name.c */

/* cfx.c */
#define _gsskrb5cfx_wrap_length_cfx vassym__gsskrb5cfx_wrap_length_cfx
#define _gssapi_wrap_size_cfx vassym__gssapi_wrap_size_cfx
#define _gk_find_buffer vassym__gk_find_buffer
#define _gk_allocate_buffer vassym__gk_allocate_buffer
#define _gk_verify_buffers vassym__gk_verify_buffers
#define _gssapi_wrap_cfx_iov vassym__gssapi_wrap_cfx_iov
#define _gssapi_unwrap_cfx_iov vassym__gssapi_unwrap_cfx_iov
#define _gssapi_wrap_iov_length_cfx vassym__gssapi_wrap_iov_length_cfx
#define _gssapi_wrap_cfx vassym__gssapi_wrap_cfx
#define _gssapi_unwrap_cfx vassym__gssapi_unwrap_cfx
#define _gssapi_mic_cfx vassym__gssapi_mic_cfx
#define _gssapi_verify_mic_cfx vassym__gssapi_verify_mic_cfx

/* cfx.h */

/* compare_name.c */
#define _gsskrb5_compare_name vassym__gsskrb5_compare_name

/* compat.c */
#define _gss_DES3_get_mic_compat vassym__gss_DES3_get_mic_compat

/* context_time.c */
#define _gsskrb5_lifetime_left vassym__gsskrb5_lifetime_left
#define _gsskrb5_context_time vassym__gsskrb5_context_time

/* copy_ccache.c */
#define _gsskrb5_krb5_import_cred vassym__gsskrb5_krb5_import_cred

/* decapsulate.c */
#define _gsskrb5_get_mech vassym__gsskrb5_get_mech
#define _gssapi_verify_mech_header vassym__gssapi_verify_mech_header
#define _gsskrb5_verify_header vassym__gsskrb5_verify_header
#define _gssapi_decapsulate vassym__gssapi_decapsulate
#define _gsskrb5_decapsulate vassym__gsskrb5_decapsulate
#define _gssapi_verify_pad vassym__gssapi_verify_pad

/* delete_sec_context.c */
#define _gsskrb5_delete_sec_context vassym__gsskrb5_delete_sec_context

/* display_name.c */
#define _gsskrb5_display_name vassym__gsskrb5_display_name

/* display_status.c */
#define _gsskrb5_clear_status vassym__gsskrb5_clear_status
#define _gsskrb5_set_status vassym__gsskrb5_set_status
#define _gsskrb5_display_status vassym__gsskrb5_display_status

/* duplicate_cred.c */
#define _gsskrb5_duplicate_cred vassym__gsskrb5_duplicate_cred

/* duplicate_name.c */
#define _gsskrb5_duplicate_name vassym__gsskrb5_duplicate_name

/* encapsulate.c */
#define _gssapi_encap_length vassym__gssapi_encap_length
#define _gsskrb5_encap_length vassym__gsskrb5_encap_length
#define _gssapi_make_mech_header vassym__gssapi_make_mech_header
#define _gsskrb5_make_header vassym__gsskrb5_make_header
#define _gssapi_encapsulate vassym__gssapi_encapsulate
#define _gsskrb5_encapsulate vassym__gsskrb5_encapsulate

/* export_name.c */
#define _gsskrb5_export_name vassym__gsskrb5_export_name

/* export_sec_context.c */
#define _gsskrb5_export_sec_context vassym__gsskrb5_export_sec_context

/* external.c */
#define __gss_c_nt_user_name_oid_desc vassym___gss_c_nt_user_name_oid_desc
#define __gss_c_nt_machine_uid_name_oid_desc vassym___gss_c_nt_machine_uid_name_oid_desc
#define __gss_c_nt_string_uid_name_oid_desc vassym___gss_c_nt_string_uid_name_oid_desc
#define __gss_c_nt_hostbased_service_x_oid_desc vassym___gss_c_nt_hostbased_service_x_oid_desc
#define __gss_c_nt_hostbased_service_oid_desc vassym___gss_c_nt_hostbased_service_oid_desc
#define __gss_c_nt_anonymous_oid_desc vassym___gss_c_nt_anonymous_oid_desc
#define __gss_c_nt_export_name_oid_desc vassym___gss_c_nt_export_name_oid_desc
#define __gss_krb5_nt_principal_name_oid_desc vassym___gss_krb5_nt_principal_name_oid_desc
#define __gss_c_nt_composite_export_oid_desc vassym___gss_c_nt_composite_export_oid_desc
#define __gss_iakerb_proxy_mechanism_oid_desc vassym___gss_iakerb_proxy_mechanism_oid_desc
#define __gss_iakerb_min_msg_mechanism_oid_desc vassym___gss_iakerb_min_msg_mechanism_oid_desc
#define __gss_krb5_initialize vassym___gss_krb5_initialize

/* get_mic.c */
#define _gsskrb5_get_mic vassym__gsskrb5_get_mic

/* gsskrb5_locl.h */

/* gsskrb5-private.h */

/* import_name.c */
#define _gsskrb5_canon_name vassym__gsskrb5_canon_name
#define _gsskrb5_import_name vassym__gsskrb5_import_name

/* import_sec_context.c */
#define _gsskrb5_import_sec_context vassym__gsskrb5_import_sec_context

/* indicate_mechs.c */
#define _gsskrb5_indicate_mechs vassym__gsskrb5_indicate_mechs

/* init.c */
#define _gsskrb5_ctx_reinit vassym__gsskrb5_ctx_reinit
#define _gsskrb5_init vassym__gsskrb5_init

/* init_sec_context.c */
#define _gsskrb5_create_ctx vassym__gsskrb5_create_ctx
#define _gsskrb5_init_sec_context vassym__gsskrb5_init_sec_context

/* inquire_context.c */
#define _gsskrb5_inquire_context vassym__gsskrb5_inquire_context

/* inquire_cred.c */
#define _gsskrb5_inquire_cred vassym__gsskrb5_inquire_cred

/* inquire_cred_by_mech.c */
#define _gsskrb5_inquire_cred_by_mech vassym__gsskrb5_inquire_cred_by_mech

/* inquire_cred_by_oid.c */
#define _gsskrb5_inquire_cred_by_oid vassym__gsskrb5_inquire_cred_by_oid

/* inquire_mechs_for_name.c */
#define _gsskrb5_inquire_mechs_for_name vassym__gsskrb5_inquire_mechs_for_name

/* inquire_names_for_mech.c */
#define _gsskrb5_inquire_names_for_mech vassym__gsskrb5_inquire_names_for_mech

/* inquire_sec_context_by_oid.c */
#define _gsskrb5_inquire_sec_context_by_oid vassym__gsskrb5_inquire_sec_context_by_oid

/* name_attrs.c */
#define _gsskrb5_get_name_attribute vassym__gsskrb5_get_name_attribute
#define _gsskrb5_set_name_attribute vassym__gsskrb5_set_name_attribute
#define _gsskrb5_delete_name_attribute vassym__gsskrb5_delete_name_attribute
#define _gsskrb5_inquire_name vassym__gsskrb5_inquire_name
#define _gsskrb5_display_name_ext vassym__gsskrb5_display_name_ext
#define _gsskrb5_export_name_composite vassym__gsskrb5_export_name_composite

/* pname_to_uid.c */
#define _gsskrb5_localname vassym__gsskrb5_localname

/* process_context_token.c */
#define _gsskrb5_process_context_token vassym__gsskrb5_process_context_token

/* prf.c */
#define _gsskrb5_pseudo_random vassym__gsskrb5_pseudo_random

/* release_buffer.c */
#define _gsskrb5_release_buffer vassym__gsskrb5_release_buffer

/* release_cred.c */
#define _gsskrb5_release_cred vassym__gsskrb5_release_cred

/* release_name.c */
#define _gsskrb5_release_name vassym__gsskrb5_release_name

/* sequence.c */
#define _gssapi_msg_order_create vassym__gssapi_msg_order_create
#define _gssapi_msg_order_destroy vassym__gssapi_msg_order_destroy
#define _gssapi_msg_order_check vassym__gssapi_msg_order_check
#define _gssapi_msg_order_f vassym__gssapi_msg_order_f
#define _gssapi_msg_order_export vassym__gssapi_msg_order_export
#define _gssapi_msg_order_import vassym__gssapi_msg_order_import

/* store_cred.c */
#define _gsskrb5_store_cred_into2 vassym__gsskrb5_store_cred_into2
#define _gsskrb5_store_cred_into vassym__gsskrb5_store_cred_into

/* set_cred_option.c */
#define _gsskrb5_set_cred_option vassym__gsskrb5_set_cred_option

/* set_sec_context_option.c */
#define _gsskrb5_set_sec_context_option vassym__gsskrb5_set_sec_context_option

/* ticket_flags.c */
#define _gsskrb5_get_tkt_flags vassym__gsskrb5_get_tkt_flags

/* unwrap.c */
#define _gsskrb5_unwrap vassym__gsskrb5_unwrap

/* authorize_localname.c */
#define _gsskrb5_authorize_localname vassym__gsskrb5_authorize_localname

/* verify_mic.c */
#define _gsskrb5_verify_mic_internal vassym__gsskrb5_verify_mic_internal
#define _gsskrb5_verify_mic vassym__gsskrb5_verify_mic

/* wrap.c */
#define _gsskrb5i_get_initiator_subkey vassym__gsskrb5i_get_initiator_subkey
#define _gsskrb5i_get_acceptor_subkey vassym__gsskrb5i_get_acceptor_subkey
#define _gsskrb5i_get_token_key vassym__gsskrb5i_get_token_key
#define _gsskrb5_wrap_size_limit vassym__gsskrb5_wrap_size_limit
#define _gsskrb5_wrap vassym__gsskrb5_wrap

/* context.h */

/* context.c */
#define _gss_mg_krb5_context vassym__gss_mg_krb5_context
#define _gss_mg_get_error vassym__gss_mg_get_error
#define _gss_mg_error vassym__gss_mg_error
#define gss_mg_collect_error vassym_gss_mg_collect_error
#define gss_mg_set_error_string vassym_gss_mg_set_error_string
#define _gss_mg_log_level vassym__gss_mg_log_level
#define _gss_mg_log vassym__gss_mg_log
#define _gss_mg_log_name vassym__gss_mg_log_name
#define _gss_mg_log_cred vassym__gss_mg_log_cred

/* cred.h */

/* cred.c */
#define _gss_mg_release_cred vassym__gss_mg_release_cred
#define _gss_mg_alloc_cred vassym__gss_mg_alloc_cred

/* compat.h */

/* doxygen.c */

/* gss_accept_sec_context.c */
#define gss_accept_sec_context vassym_gss_accept_sec_context

/* gss_acquire_cred.c */
#define gss_acquire_cred vassym_gss_acquire_cred

/* gss_acquire_cred_from.c */
#define gss_acquire_cred_from vassym_gss_acquire_cred_from

/* gss_acquire_cred_impersonate_name.c */
#define gss_acquire_cred_impersonate_name vassym_gss_acquire_cred_impersonate_name

/* gss_acquire_cred_with_password.c */
#define gss_acquire_cred_with_password vassym_gss_acquire_cred_with_password

/* gss_add_cred.c */
#define gss_add_cred vassym_gss_add_cred

/* gss_add_cred_from.c */
#define _gss_mg_add_mech_cred vassym__gss_mg_add_mech_cred
#define gss_add_cred_from vassym_gss_add_cred_from

/* gss_add_cred_with_password.c */
#define gss_add_cred_with_password vassym_gss_add_cred_with_password

/* gss_add_oid_set_member.c */
#define gss_add_oid_set_member vassym_gss_add_oid_set_member

/* gss_aeap.c */
#define gss_wrap_iov vassym_gss_wrap_iov
#define gss_unwrap_iov vassym_gss_unwrap_iov
#define gss_wrap_iov_length vassym_gss_wrap_iov_length
#define gss_release_iov_buffer vassym_gss_release_iov_buffer
#define __gss_c_attr_stream_sizes_oid_desc vassym___gss_c_attr_stream_sizes_oid_desc
#define gss_context_query_attributes vassym_gss_context_query_attributes
#define gss_wrap_aead vassym_gss_wrap_aead
#define gss_unwrap_aead vassym_gss_unwrap_aead

/* gss_buffer_set.c */
#define gss_create_empty_buffer_set vassym_gss_create_empty_buffer_set
#define gss_add_buffer_set_member vassym_gss_add_buffer_set_member
#define gss_release_buffer_set vassym_gss_release_buffer_set

/* gss_canonicalize_name.c */
#define gss_canonicalize_name vassym_gss_canonicalize_name

/* gss_compare_name.c */
#define gss_compare_name vassym_gss_compare_name

/* gss_context_time.c */
#define gss_context_time vassym_gss_context_time

/* gss_create_empty_oid_set.c */
#define gss_create_empty_oid_set vassym_gss_create_empty_oid_set

/* gss_cred.c */
#define gss_export_cred vassym_gss_export_cred
#define gss_import_cred vassym_gss_import_cred

/* gss_decapsulate_token.c */
#define gss_decapsulate_token vassym_gss_decapsulate_token

/* gss_delete_name_attribute.c */
#define gss_delete_name_attribute vassym_gss_delete_name_attribute

/* gss_delete_sec_context.c */
#define gss_delete_sec_context vassym_gss_delete_sec_context

/* gss_destroy_cred.c */
#define gss_destroy_cred vassym_gss_destroy_cred

/* gss_display_name.c */
#define gss_display_name vassym_gss_display_name

/* gss_display_name_ext.c */
#define gss_display_name_ext vassym_gss_display_name_ext

/* gss_display_status.c */
#define gss_display_status vassym_gss_display_status

/* gss_duplicate_cred.c */
#define gss_duplicate_cred vassym_gss_duplicate_cred

/* gss_duplicate_name.c */
#define gss_duplicate_name vassym_gss_duplicate_name

/* gss_duplicate_oid.c */
#define gss_duplicate_oid vassym_gss_duplicate_oid

/* gss_duplicate_oid_set.c */
#define gss_duplicate_oid_set vassym_gss_duplicate_oid_set

/* gss_encapsulate_token.c */
#define gss_encapsulate_token vassym_gss_encapsulate_token

/* gss_export_name.c */
#define gss_export_name vassym_gss_export_name
#define gss_mg_export_name vassym_gss_mg_export_name

/* gss_export_name_composite.c */
#define gss_export_name_composite vassym_gss_export_name_composite

/* gss_export_sec_context.c */
#define gss_export_sec_context vassym_gss_export_sec_context

/* gss_get_mic.c */
#define gss_get_mic vassym_gss_get_mic

/* gss_get_neg_mechs.c */
#define gss_get_neg_mechs vassym_gss_get_neg_mechs

/* gss_get_name_attribute.c */
#define gss_get_name_attribute vassym_gss_get_name_attribute

/* gss_import_name.c */
#define gss_import_name vassym_gss_import_name

/* gss_import_sec_context.c */
#define gss_import_sec_context vassym_gss_import_sec_context

/* gss_indicate_mechs.c */
#define gss_indicate_mechs vassym_gss_indicate_mechs

/* gss_init_sec_context.c */
#define _gss_mg_find_mech_cred vassym__gss_mg_find_mech_cred
#define gss_init_sec_context vassym_gss_init_sec_context

/* gss_inquire_context.c */
#define gss_inquire_context vassym_gss_inquire_context

/* gss_inquire_cred.c */
#define gss_inquire_cred vassym_gss_inquire_cred

/* gss_inquire_cred_by_mech.c */
#define gss_inquire_cred_by_mech vassym_gss_inquire_cred_by_mech

/* gss_inquire_cred_by_oid.c */
#define gss_inquire_cred_by_oid vassym_gss_inquire_cred_by_oid

/* gss_inquire_mechs_for_name.c */
#define gss_inquire_mechs_for_name vassym_gss_inquire_mechs_for_name

/* gss_inquire_name.c */
#define gss_inquire_name vassym_gss_inquire_name

/* gss_inquire_names_for_mech.c */
#define gss_inquire_names_for_mech vassym_gss_inquire_names_for_mech

/* gss_krb5.c */
#define gss_krb5_copy_ccache vassym_gss_krb5_copy_ccache
#define gss_krb5_import_cred vassym_gss_krb5_import_cred
#define gsskrb5_register_acceptor_identity vassym_gsskrb5_register_acceptor_identity
#define krb5_gss_register_acceptor_identity vassym_krb5_gss_register_acceptor_identity
#define gsskrb5_set_dns_canonicalize vassym_gsskrb5_set_dns_canonicalize
#define gss_krb5_export_lucid_sec_context vassym_gss_krb5_export_lucid_sec_context
#define gss_krb5_free_lucid_sec_context vassym_gss_krb5_free_lucid_sec_context
#define gss_krb5_set_allowable_enctypes vassym_gss_krb5_set_allowable_enctypes
#define gsskrb5_set_send_to_kdc vassym_gsskrb5_set_send_to_kdc
#define gss_krb5_ccache_name vassym_gss_krb5_ccache_name
#define gsskrb5_extract_authtime_from_sec_context vassym_gsskrb5_extract_authtime_from_sec_context
#define gsskrb5_extract_authz_data_from_sec_context vassym_gsskrb5_extract_authz_data_from_sec_context
#define gsskrb5_extract_service_keyblock vassym_gsskrb5_extract_service_keyblock
#define gsskrb5_get_initiator_subkey vassym_gsskrb5_get_initiator_subkey
#define gsskrb5_get_subkey vassym_gsskrb5_get_subkey
#define gsskrb5_set_default_realm vassym_gsskrb5_set_default_realm
#define gss_krb5_get_tkt_flags vassym_gss_krb5_get_tkt_flags
#define gsskrb5_set_time_offset vassym_gsskrb5_set_time_offset
#define gsskrb5_get_time_offset vassym_gsskrb5_get_time_offset
#define gsskrb5_plugin_register vassym_gsskrb5_plugin_register

/* gss_mech_switch.c */
#define _gss_mechs vassym__gss_mechs
#define _gss_mech_oids vassym__gss_mech_oids
#define _gss_load_mech vassym__gss_load_mech
#define __gss_get_mechanism vassym___gss_get_mechanism
#define _gss_mg_support_mechanism vassym__gss_mg_support_mechanism
#define gss_name_to_oid vassym_gss_name_to_oid
#define gss_oid_to_name vassym_gss_oid_to_name

/* gss_mo.c */
#define _gss_mo_get_option_1 vassym__gss_mo_get_option_1
#define _gss_mo_get_option_0 vassym__gss_mo_get_option_0
#define _gss_mo_get_ctx_as_string vassym__gss_mo_get_ctx_as_string
#define gss_mo_set vassym_gss_mo_set
#define gss_mo_get vassym_gss_mo_get
#define gss_mo_list vassym_gss_mo_list
#define gss_mo_name vassym_gss_mo_name
#define gss_inquire_saslname_for_mech vassym_gss_inquire_saslname_for_mech
#define gss_inquire_mech_for_saslname vassym_gss_inquire_mech_for_saslname
#define gss_indicate_mechs_by_attrs vassym_gss_indicate_mechs_by_attrs
#define gss_inquire_attrs_for_mech vassym_gss_inquire_attrs_for_mech
#define gss_display_mech_attr vassym_gss_display_mech_attr

/* gss_names.c */
#define _gss_mg_get_underlying_mech_name vassym__gss_mg_get_underlying_mech_name
#define _gss_find_mn vassym__gss_find_mn
#define _gss_create_name vassym__gss_create_name
#define _gss_mg_release_name vassym__gss_mg_release_name
#define _gss_mg_check_name vassym__gss_mg_check_name
#define _gss_mech_import_name vassym__gss_mech_import_name
#define _gss_mech_inquire_names_for_mech vassym__gss_mech_inquire_names_for_mech

/* gss_oid.c */
#define __gss_krb5_copy_ccache_x_oid_desc vassym___gss_krb5_copy_ccache_x_oid_desc
#define __gss_krb5_get_tkt_flags_x_oid_desc vassym___gss_krb5_get_tkt_flags_x_oid_desc
#define __gss_krb5_extract_authz_data_from_sec_context_x_oid_desc vassym___gss_krb5_extract_authz_data_from_sec_context_x_oid_desc
#define __gss_krb5_compat_des3_mic_x_oid_desc vassym___gss_krb5_compat_des3_mic_x_oid_desc
#define __gss_krb5_register_acceptor_identity_x_oid_desc vassym___gss_krb5_register_acceptor_identity_x_oid_desc
#define __gss_krb5_export_lucid_context_x_oid_desc vassym___gss_krb5_export_lucid_context_x_oid_desc
#define __gss_krb5_export_lucid_context_v1_x_oid_desc vassym___gss_krb5_export_lucid_context_v1_x_oid_desc
#define __gss_krb5_set_dns_canonicalize_x_oid_desc vassym___gss_krb5_set_dns_canonicalize_x_oid_desc
#define __gss_krb5_get_subkey_x_oid_desc vassym___gss_krb5_get_subkey_x_oid_desc
#define __gss_krb5_get_initiator_subkey_x_oid_desc vassym___gss_krb5_get_initiator_subkey_x_oid_desc
#define __gss_krb5_get_acceptor_subkey_x_oid_desc vassym___gss_krb5_get_acceptor_subkey_x_oid_desc
#define __gss_krb5_send_to_kdc_x_oid_desc vassym___gss_krb5_send_to_kdc_x_oid_desc
#define __gss_krb5_get_authtime_x_oid_desc vassym___gss_krb5_get_authtime_x_oid_desc
#define __gss_krb5_get_service_keyblock_x_oid_desc vassym___gss_krb5_get_service_keyblock_x_oid_desc
#define __gss_krb5_set_allowable_enctypes_x_oid_desc vassym___gss_krb5_set_allowable_enctypes_x_oid_desc
#define __gss_krb5_set_default_realm_x_oid_desc vassym___gss_krb5_set_default_realm_x_oid_desc
#define __gss_krb5_ccache_name_x_oid_desc vassym___gss_krb5_ccache_name_x_oid_desc
#define __gss_krb5_set_time_offset_x_oid_desc vassym___gss_krb5_set_time_offset_x_oid_desc
#define __gss_krb5_get_time_offset_x_oid_desc vassym___gss_krb5_get_time_offset_x_oid_desc
#define __gss_krb5_plugin_register_x_oid_desc vassym___gss_krb5_plugin_register_x_oid_desc
#define __gss_ntlm_get_session_key_x_oid_desc vassym___gss_ntlm_get_session_key_x_oid_desc
#define __gss_c_nt_ntlm_oid_desc vassym___gss_c_nt_ntlm_oid_desc
#define __gss_c_nt_dn_oid_desc vassym___gss_c_nt_dn_oid_desc
#define __gss_krb5_nt_principal_name_referral_oid_desc vassym___gss_krb5_nt_principal_name_referral_oid_desc
#define __gss_c_ntlm_avguest_oid_desc vassym___gss_c_ntlm_avguest_oid_desc
#define __gss_c_ntlm_v1_oid_desc vassym___gss_c_ntlm_v1_oid_desc
#define __gss_c_ntlm_v2_oid_desc vassym___gss_c_ntlm_v2_oid_desc
#define __gss_c_ntlm_session_key_oid_desc vassym___gss_c_ntlm_session_key_oid_desc
#define __gss_c_ntlm_force_v1_oid_desc vassym___gss_c_ntlm_force_v1_oid_desc
#define __gss_krb5_cred_no_ci_flags_x_oid_desc vassym___gss_krb5_cred_no_ci_flags_x_oid_desc
#define __gss_krb5_import_cred_x_oid_desc vassym___gss_krb5_import_cred_x_oid_desc
#define __gss_krb5_import_rfc4121_context_x_oid_desc vassym___gss_krb5_import_rfc4121_context_x_oid_desc
#define __gss_c_ma_sasl_mech_name_oid_desc vassym___gss_c_ma_sasl_mech_name_oid_desc
#define __gss_c_ma_mech_name_oid_desc vassym___gss_c_ma_mech_name_oid_desc
#define __gss_c_ma_mech_description_oid_desc vassym___gss_c_ma_mech_description_oid_desc
#define __gss_sasl_digest_md5_mechanism_oid_desc vassym___gss_sasl_digest_md5_mechanism_oid_desc
#define __gss_netlogon_mechanism_oid_desc vassym___gss_netlogon_mechanism_oid_desc
#define __gss_netlogon_set_session_key_x_oid_desc vassym___gss_netlogon_set_session_key_x_oid_desc
#define __gss_netlogon_set_sign_algorithm_x_oid_desc vassym___gss_netlogon_set_sign_algorithm_x_oid_desc
#define __gss_netlogon_nt_netbios_dns_name_oid_desc vassym___gss_netlogon_nt_netbios_dns_name_oid_desc
#define __gss_c_inq_win2k_pac_x_oid_desc vassym___gss_c_inq_win2k_pac_x_oid_desc
#define __gss_c_inq_sspi_session_key_oid_desc vassym___gss_c_inq_sspi_session_key_oid_desc
#define __gss_c_inq_negoex_key_oid_desc vassym___gss_c_inq_negoex_key_oid_desc
#define __gss_c_inq_negoex_verify_key_oid_desc vassym___gss_c_inq_negoex_verify_key_oid_desc
#define __gss_c_inq_require_mechlist_mic_oid_desc vassym___gss_c_inq_require_mechlist_mic_oid_desc
#define __gss_krb5_mechanism_oid_desc vassym___gss_krb5_mechanism_oid_desc
#define __gss_mskrb5_mechanism_oid_desc vassym___gss_mskrb5_mechanism_oid_desc
#define __gss_ntlm_mechanism_oid_desc vassym___gss_ntlm_mechanism_oid_desc
#define __gss_spnego_mechanism_oid_desc vassym___gss_spnego_mechanism_oid_desc
#define __gss_c_inq_peer_has_buggy_spnego_oid_desc vassym___gss_c_inq_peer_has_buggy_spnego_oid_desc
#define __gss_c_ntlm_reset_crypto_oid_desc vassym___gss_c_ntlm_reset_crypto_oid_desc
#define __gss_negoex_mechanism_oid_desc vassym___gss_negoex_mechanism_oid_desc
#define __gss_sanon_x25519_mechanism_oid_desc vassym___gss_sanon_x25519_mechanism_oid_desc
#define __gss_c_ma_mech_concrete_oid_desc vassym___gss_c_ma_mech_concrete_oid_desc
#define __gss_c_ma_mech_pseudo_oid_desc vassym___gss_c_ma_mech_pseudo_oid_desc
#define __gss_c_ma_mech_composite_oid_desc vassym___gss_c_ma_mech_composite_oid_desc
#define __gss_c_ma_mech_nego_oid_desc vassym___gss_c_ma_mech_nego_oid_desc
#define __gss_c_ma_mech_glue_oid_desc vassym___gss_c_ma_mech_glue_oid_desc
#define __gss_c_ma_not_mech_oid_desc vassym___gss_c_ma_not_mech_oid_desc
#define __gss_c_ma_deprecated_oid_desc vassym___gss_c_ma_deprecated_oid_desc
#define __gss_c_ma_not_dflt_mech_oid_desc vassym___gss_c_ma_not_dflt_mech_oid_desc
#define __gss_c_ma_itok_framed_oid_desc vassym___gss_c_ma_itok_framed_oid_desc
#define __gss_c_ma_auth_init_oid_desc vassym___gss_c_ma_auth_init_oid_desc
#define __gss_c_ma_auth_targ_oid_desc vassym___gss_c_ma_auth_targ_oid_desc
#define __gss_c_ma_auth_init_init_oid_desc vassym___gss_c_ma_auth_init_init_oid_desc
#define __gss_c_ma_auth_targ_init_oid_desc vassym___gss_c_ma_auth_targ_init_oid_desc
#define __gss_c_ma_auth_init_anon_oid_desc vassym___gss_c_ma_auth_init_anon_oid_desc
#define __gss_c_ma_auth_targ_anon_oid_desc vassym___gss_c_ma_auth_targ_anon_oid_desc
#define __gss_c_ma_deleg_cred_oid_desc vassym___gss_c_ma_deleg_cred_oid_desc
#define __gss_c_ma_integ_prot_oid_desc vassym___gss_c_ma_integ_prot_oid_desc
#define __gss_c_ma_conf_prot_oid_desc vassym___gss_c_ma_conf_prot_oid_desc
#define __gss_c_ma_mic_oid_desc vassym___gss_c_ma_mic_oid_desc
#define __gss_c_ma_wrap_oid_desc vassym___gss_c_ma_wrap_oid_desc
#define __gss_c_ma_prot_ready_oid_desc vassym___gss_c_ma_prot_ready_oid_desc
#define __gss_c_ma_replay_det_oid_desc vassym___gss_c_ma_replay_det_oid_desc
#define __gss_c_ma_oos_det_oid_desc vassym___gss_c_ma_oos_det_oid_desc
#define __gss_c_ma_cbindings_oid_desc vassym___gss_c_ma_cbindings_oid_desc
#define __gss_c_ma_pfs_oid_desc vassym___gss_c_ma_pfs_oid_desc
#define __gss_c_ma_compress_oid_desc vassym___gss_c_ma_compress_oid_desc
#define __gss_c_ma_ctx_trans_oid_desc vassym___gss_c_ma_ctx_trans_oid_desc
#define __gss_c_ma_negoex_and_spnego_oid_desc vassym___gss_c_ma_negoex_and_spnego_oid_desc
#define _gss_ont_ma vassym__gss_ont_ma
#define _gss_ont_mech vassym__gss_ont_mech
#define _gss_ot_internal vassym__gss_ot_internal
#define _gss_ot_internal_count vassym__gss_ot_internal_count

/* gss_oid_equal.c */
#define gss_oid_equal vassym_gss_oid_equal

/* gss_oid_to_str.c */
#define gss_oid_to_str vassym_gss_oid_to_str

/* gss_pname_to_uid.c */
#define gss_localname vassym_gss_localname
#define gss_pname_to_uid vassym_gss_pname_to_uid

/* gss_process_context_token.c */
#define gss_process_context_token vassym_gss_process_context_token

/* gss_pseudo_random.c */
#define gss_pseudo_random vassym_gss_pseudo_random

/* gss_release_buffer.c */
#define gss_release_buffer vassym_gss_release_buffer

/* gss_release_cred.c */
#define gss_release_cred vassym_gss_release_cred

/* gss_release_name.c */
#define gss_release_name vassym_gss_release_name

/* gss_release_oid.c */
#define gss_release_oid vassym_gss_release_oid

/* gss_release_oid_set.c */
#define gss_release_oid_set vassym_gss_release_oid_set

/* gss_rfc4121.c */
#define _gss_mg_import_rfc4121_context vassym__gss_mg_import_rfc4121_context

/* gss_seal.c */
#define gss_seal vassym_gss_seal

/* gss_set_cred_option.c */
#define gss_set_cred_option vassym_gss_set_cred_option

/* gss_set_name_attribute.c */
#define gss_set_name_attribute vassym_gss_set_name_attribute

/* gss_set_neg_mechs.c */
#define gss_set_neg_mechs vassym_gss_set_neg_mechs

/* gss_set_sec_context_option.c */
#define gss_set_sec_context_option vassym_gss_set_sec_context_option

/* gss_sign.c */
#define gss_sign vassym_gss_sign

/* gss_store_cred.c */
#define gss_store_cred vassym_gss_store_cred

/* gss_store_cred_into.c */
#define gss_store_cred_into2 vassym_gss_store_cred_into2
#define gss_store_cred_into vassym_gss_store_cred_into

/* gss_test_oid_set_member.c */
#define gss_test_oid_set_member vassym_gss_test_oid_set_member

/* gss_unseal.c */
#define gss_unseal vassym_gss_unseal

/* gss_unwrap.c */
#define gss_unwrap vassym_gss_unwrap

/* gss_authorize_localname.c */
#define __gss_c_attr_local_login_user vassym___gss_c_attr_local_login_user
#define gss_authorize_localname vassym_gss_authorize_localname
#define gss_userok vassym_gss_userok

/* gss_utils.c */
#define _gss_free_oid vassym__gss_free_oid
#define _gss_intern_oid vassym__gss_intern_oid
#define _gss_copy_buffer vassym__gss_copy_buffer
#define _gss_secure_release_buffer vassym__gss_secure_release_buffer
#define _gss_secure_release_buffer_set vassym__gss_secure_release_buffer_set
#define _gss_mg_encode_le_uint32 vassym__gss_mg_encode_le_uint32
#define _gss_mg_decode_le_uint32 vassym__gss_mg_decode_le_uint32
#define _gss_mg_encode_be_uint32 vassym__gss_mg_encode_be_uint32
#define _gss_mg_decode_be_uint32 vassym__gss_mg_decode_be_uint32
#define _gss_mg_encode_le_uint16 vassym__gss_mg_encode_le_uint16
#define _gss_mg_decode_le_uint16 vassym__gss_mg_decode_le_uint16
#define _gss_mg_encode_be_uint16 vassym__gss_mg_encode_be_uint16
#define _gss_mg_decode_be_uint16 vassym__gss_mg_decode_be_uint16
#define _gss_mg_ret_oid vassym__gss_mg_ret_oid
#define _gss_mg_store_oid vassym__gss_mg_store_oid
#define _gss_mg_ret_buffer vassym__gss_mg_ret_buffer
#define _gss_mg_store_buffer vassym__gss_mg_store_buffer

/* gss_verify.c */
#define gss_verify vassym_gss_verify

/* gss_verify_mic.c */
#define gss_verify_mic vassym_gss_verify_mic

/* gss_wrap.c */
#define gss_wrap vassym_gss_wrap

/* gss_wrap_size_limit.c */
#define gss_wrap_size_limit vassym_gss_wrap_size_limit

/* gss_inquire_sec_context_by_oid.c */
#define gss_inquire_sec_context_by_oid vassym_gss_inquire_sec_context_by_oid

/* gssspi_exchange_meta_data.c */
#define gssspi_exchange_meta_data vassym_gssspi_exchange_meta_data

/* gssspi_query_mechanism_info.c */
#define gssspi_query_mechanism_info vassym_gssspi_query_mechanism_info

/* gssspi_query_meta_data.c */
#define gssspi_query_meta_data vassym_gssspi_query_meta_data

/* mech_switch.h */

/* mech_locl.h */

/* name.h */

/* utils.h */

/* accept_sec_context.c */
#define _gss_ntlm_allocate_ctx vassym__gss_ntlm_allocate_ctx
#define _gss_ntlm_accept_sec_context vassym__gss_ntlm_accept_sec_context

/* acquire_cred.c */
#define _gss_ntlm_acquire_cred_from vassym__gss_ntlm_acquire_cred_from

/* add_cred.c */
#define _gss_ntlm_add_cred vassym__gss_ntlm_add_cred

/* canonicalize_name.c */
#define _gss_ntlm_canonicalize_name vassym__gss_ntlm_canonicalize_name

/* compare_name.c */
#define _gss_ntlm_compare_name vassym__gss_ntlm_compare_name

/* context_time.c */
#define _gss_ntlm_context_time vassym__gss_ntlm_context_time

/* creds.c */
#define _gss_ntlm_inquire_cred vassym__gss_ntlm_inquire_cred
#define _gss_ntlm_destroy_cred vassym__gss_ntlm_destroy_cred

/* crypto.c */
#define a2i_signmagic vassym_a2i_signmagic
#define a2i_sealmagic vassym_a2i_sealmagic
#define i2a_signmagic vassym_i2a_signmagic
#define i2a_sealmagic vassym_i2a_sealmagic
#define _gss_ntlm_set_key vassym__gss_ntlm_set_key
#define _gss_ntlm_set_keys vassym__gss_ntlm_set_keys
#define _gss_ntlm_get_mic vassym__gss_ntlm_get_mic
#define _gss_ntlm_verify_mic vassym__gss_ntlm_verify_mic
#define _gss_ntlm_wrap_size_limit vassym__gss_ntlm_wrap_size_limit
#define _gss_ntlm_wrap vassym__gss_ntlm_wrap
#define _gss_ntlm_unwrap vassym__gss_ntlm_unwrap

/* delete_sec_context.c */
#define _gss_ntlm_delete_sec_context vassym__gss_ntlm_delete_sec_context

/* display_name.c */
#define _gss_ntlm_display_name vassym__gss_ntlm_display_name

/* display_status.c */
#define _gss_ntlm_display_status vassym__gss_ntlm_display_status

/* duplicate_name.c */
#define _gss_ntlm_duplicate_name vassym__gss_ntlm_duplicate_name

/* export_name.c */
#define _gss_ntlm_export_name vassym__gss_ntlm_export_name

/* export_sec_context.c */
#define _gss_ntlm_export_sec_context vassym__gss_ntlm_export_sec_context

/* external.c */
#define __gss_ntlm_initialize vassym___gss_ntlm_initialize

/* ntlm.h */

/* import_name.c */
#define _gss_ntlm_import_name vassym__gss_ntlm_import_name

/* import_sec_context.c */
#define _gss_ntlm_import_sec_context vassym__gss_ntlm_import_sec_context

/* indicate_mechs.c */
#define _gss_ntlm_indicate_mechs vassym__gss_ntlm_indicate_mechs

/* init_sec_context.c */
#define _gss_ntlm_get_user_cred vassym__gss_ntlm_get_user_cred
#define _gss_ntlm_copy_cred vassym__gss_ntlm_copy_cred
#define _gss_ntlm_init_sec_context vassym__gss_ntlm_init_sec_context

/* inquire_context.c */
#define _gss_ntlm_inquire_context vassym__gss_ntlm_inquire_context

/* inquire_cred_by_mech.c */
#define _gss_ntlm_inquire_cred_by_mech vassym__gss_ntlm_inquire_cred_by_mech

/* inquire_mechs_for_name.c */
#define _gss_ntlm_inquire_mechs_for_name vassym__gss_ntlm_inquire_mechs_for_name

/* inquire_names_for_mech.c */
#define _gss_ntlm_inquire_names_for_mech vassym__gss_ntlm_inquire_names_for_mech

/* inquire_sec_context_by_oid.c */
#define _gss_ntlm_inquire_sec_context_by_oid vassym__gss_ntlm_inquire_sec_context_by_oid

/* iter_cred.c */
#define _gss_ntlm_iter_creds_f vassym__gss_ntlm_iter_creds_f

/* process_context_token.c */
#define _gss_ntlm_process_context_token vassym__gss_ntlm_process_context_token

/* release_cred.c */
#define _gss_ntlm_release_cred vassym__gss_ntlm_release_cred

/* release_name.c */
#define _gss_ntlm_release_name vassym__gss_ntlm_release_name

/* set_sec_context_option.c */
#define _gss_ntlm_set_sec_context_option vassym__gss_ntlm_set_sec_context_option

/* kdc.c */
#define ntlmsspi_kdc_digest vassym_ntlmsspi_kdc_digest

/* accept_sec_context.c */
#define _gss_spnego_accept_sec_context vassym__gss_spnego_accept_sec_context

/* compat.c */
#define _gss_spnego_mskrb_mechanism_oid_desc vassym__gss_spnego_mskrb_mechanism_oid_desc
#define _gss_spnego_alloc_sec_context vassym__gss_spnego_alloc_sec_context
#define _gss_spnego_internal_delete_sec_context vassym__gss_spnego_internal_delete_sec_context
#define _gss_spnego_safe_omit_mechlist_mic vassym__gss_spnego_safe_omit_mechlist_mic
#define _gss_spnego_indicate_mechtypelist vassym__gss_spnego_indicate_mechtypelist
#define _gss_spnego_verify_mechtypes_mic vassym__gss_spnego_verify_mechtypes_mic
#define _gss_spnego_ntlm_reset_crypto vassym__gss_spnego_ntlm_reset_crypto
#define _gss_spnego_log_mech vassym__gss_spnego_log_mech
#define _gss_spnego_log_mechTypes vassym__gss_spnego_log_mechTypes
#define _gss_spnego_indicate_mechs vassym__gss_spnego_indicate_mechs
#define _gss_spnego_inquire_cred_mechs vassym__gss_spnego_inquire_cred_mechs

/* context_storage.c */
#define _gss_spnego_import_sec_context_internal vassym__gss_spnego_import_sec_context_internal
#define _gss_spnego_export_sec_context_internal vassym__gss_spnego_export_sec_context_internal

/* context_stubs.c */
#define _gss_spnego_process_context_token vassym__gss_spnego_process_context_token
#define _gss_spnego_delete_sec_context vassym__gss_spnego_delete_sec_context
#define _gss_spnego_context_time vassym__gss_spnego_context_time
#define _gss_spnego_get_mic vassym__gss_spnego_get_mic
#define _gss_spnego_verify_mic vassym__gss_spnego_verify_mic
#define _gss_spnego_wrap vassym__gss_spnego_wrap
#define _gss_spnego_unwrap vassym__gss_spnego_unwrap
#define _gss_spnego_inquire_context vassym__gss_spnego_inquire_context
#define _gss_spnego_wrap_size_limit vassym__gss_spnego_wrap_size_limit
#define _gss_spnego_export_sec_context vassym__gss_spnego_export_sec_context
#define _gss_spnego_import_sec_context vassym__gss_spnego_import_sec_context
#define _gss_spnego_inquire_names_for_mech vassym__gss_spnego_inquire_names_for_mech
#define _gss_spnego_wrap_iov vassym__gss_spnego_wrap_iov
#define _gss_spnego_unwrap_iov vassym__gss_spnego_unwrap_iov
#define _gss_spnego_wrap_iov_length vassym__gss_spnego_wrap_iov_length
#define _gss_spnego_inquire_sec_context_by_oid vassym__gss_spnego_inquire_sec_context_by_oid
#define _gss_spnego_set_sec_context_option vassym__gss_spnego_set_sec_context_option
#define _gss_spnego_pseudo_random vassym__gss_spnego_pseudo_random

/* external.c */
#define __gss_spnego_initialize vassym___gss_spnego_initialize

/* init_sec_context.c */
#define _gss_spnego_init_sec_context vassym__gss_spnego_init_sec_context

/* negoex_ctx.c */
#define _gss_negoex_init vassym__gss_negoex_init
#define _gss_negoex_accept vassym__gss_negoex_accept

/* negoex_util.c */
#define _gss_negoex_end vassym__gss_negoex_end
#define _gss_negoex_begin vassym__gss_negoex_begin
#define _gss_negoex_release_context vassym__gss_negoex_release_context
#define _gss_negoex_log_auth_scheme vassym__gss_negoex_log_auth_scheme
#define _gss_negoex_log_message vassym__gss_negoex_log_message
#define _gss_negoex_parse_token vassym__gss_negoex_parse_token
#define _gss_negoex_locate_nego_message vassym__gss_negoex_locate_nego_message
#define _gss_negoex_locate_exchange_message vassym__gss_negoex_locate_exchange_message
#define _gss_negoex_locate_verify_message vassym__gss_negoex_locate_verify_message
#define _gss_negoex_locate_alert_message vassym__gss_negoex_locate_alert_message
#define _gss_negoex_add_nego_message vassym__gss_negoex_add_nego_message
#define _gss_negoex_add_exchange_message vassym__gss_negoex_add_exchange_message
#define _gss_negoex_add_verify_message vassym__gss_negoex_add_verify_message
#define _gss_negoex_add_verify_no_key_alert vassym__gss_negoex_add_verify_no_key_alert
#define _gss_negoex_release_auth_mech vassym__gss_negoex_release_auth_mech
#define _gss_negoex_delete_auth_mech vassym__gss_negoex_delete_auth_mech
#define _gss_negoex_select_auth_mech vassym__gss_negoex_select_auth_mech
#define _gss_negoex_add_auth_mech vassym__gss_negoex_add_auth_mech
#define _gss_negoex_locate_auth_scheme vassym__gss_negoex_locate_auth_scheme
#define _gss_negoex_common_auth_schemes vassym__gss_negoex_common_auth_schemes
#define _gss_negoex_restrict_auth_schemes vassym__gss_negoex_restrict_auth_schemes
#define _gss_negoex_negotiated_mech vassym__gss_negoex_negotiated_mech
#define _gss_negoex_and_spnego_mech_p vassym__gss_negoex_and_spnego_mech_p
#define _gss_negoex_mech_p vassym__gss_negoex_mech_p

/* spnego_locl.h */

/* negoex_locl.h */

/* spnego-private.h */

/* accept_sec_context.c */
#define _gss_sanon_accept_sec_context vassym__gss_sanon_accept_sec_context

/* acquire_cred.c */
#define _gss_sanon_acquire_cred_from vassym__gss_sanon_acquire_cred_from

/* add_cred.c */
#define _gss_sanon_add_cred_from vassym__gss_sanon_add_cred_from

/* canonicalize_name.c */
#define _gss_sanon_canonicalize_name vassym__gss_sanon_canonicalize_name

/* compare_name.c */
#define _gss_sanon_compare_name vassym__gss_sanon_compare_name

/* context_time.c */
#define _gss_sanon_context_time vassym__gss_sanon_context_time

/* crypto.c */
#define _gss_sanon_wrap vassym__gss_sanon_wrap
#define _gss_sanon_wrap_size_limit vassym__gss_sanon_wrap_size_limit
#define _gss_sanon_wrap_iov vassym__gss_sanon_wrap_iov
#define _gss_sanon_wrap_iov_length vassym__gss_sanon_wrap_iov_length
#define _gss_sanon_unwrap vassym__gss_sanon_unwrap
#define _gss_sanon_unwrap_iov vassym__gss_sanon_unwrap_iov
#define _gss_sanon_get_mic vassym__gss_sanon_get_mic
#define _gss_sanon_verify_mic vassym__gss_sanon_verify_mic
#define _gss_sanon_pseudo_random vassym__gss_sanon_pseudo_random
#define _gss_sanon_curve25519_base vassym__gss_sanon_curve25519_base
#define _gss_sanon_curve25519 vassym__gss_sanon_curve25519
#define _gss_sanon_import_rfc4121_context vassym__gss_sanon_import_rfc4121_context

/* delete_sec_context.c */
#define _gss_sanon_delete_sec_context vassym__gss_sanon_delete_sec_context

/* display_name.c */
#define _gss_sanon_display_name vassym__gss_sanon_display_name

/* display_status.c */
#define _gss_sanon_display_status vassym__gss_sanon_display_status

/* duplicate_cred.c */
#define _gss_sanon_duplicate_cred vassym__gss_sanon_duplicate_cred

/* duplicate_name.c */
#define _gss_sanon_duplicate_name vassym__gss_sanon_duplicate_name

/* export_name.c */
#define _gss_sanon_export_name vassym__gss_sanon_export_name

/* export_cred.c */
#define _gss_sanon_export_cred vassym__gss_sanon_export_cred

/* export_sec_context.c */
#define _gss_sanon_export_sec_context vassym__gss_sanon_export_sec_context

/* external.c */
#define _gss_sanon_anonymous_identity vassym__gss_sanon_anonymous_identity
#define _gss_sanon_non_anonymous_identity vassym__gss_sanon_non_anonymous_identity
#define _gss_sanon_wellknown_user_name vassym__gss_sanon_wellknown_user_name
#define _gss_sanon_wellknown_service_name vassym__gss_sanon_wellknown_service_name
#define __gss_sanon_initialize vassym___gss_sanon_initialize

/* import_cred.c */
#define _gss_sanon_import_cred vassym__gss_sanon_import_cred

/* import_name.c */
#define _gss_sanon_import_name vassym__gss_sanon_import_name

/* import_sec_context.c */
#define _gss_sanon_import_sec_context vassym__gss_sanon_import_sec_context

/* init_sec_context.c */
#define _gss_sanon_available_p vassym__gss_sanon_available_p
#define _gss_sanon_init_sec_context vassym__gss_sanon_init_sec_context

/* inquire_context.c */
#define _gss_sanon_inquire_context vassym__gss_sanon_inquire_context

/* inquire_cred.c */
#define _gss_sanon_inquire_cred vassym__gss_sanon_inquire_cred

/* inquire_cred_by_mech.c */
#define _gss_sanon_inquire_cred_by_mech vassym__gss_sanon_inquire_cred_by_mech

/* inquire_mechs_for_name.c */
#define _gss_sanon_inquire_mechs_for_name vassym__gss_sanon_inquire_mechs_for_name

/* inquire_names_for_mech.c */
#define _gss_sanon_inquire_names_for_mech vassym__gss_sanon_inquire_names_for_mech

/* inquire_sec_context_by_oid.c */
#define _gss_sanon_inquire_sec_context_by_oid vassym__gss_sanon_inquire_sec_context_by_oid

/* negoex.c */
#define _gssspi_sanon_query_mechanism_info vassym__gssspi_sanon_query_mechanism_info
#define _gss_sanon_inquire_negoex_key vassym__gss_sanon_inquire_negoex_key
#define _gssspi_sanon_query_meta_data vassym__gssspi_sanon_query_meta_data
#define _gssspi_sanon_exchange_meta_data vassym__gssspi_sanon_exchange_meta_data

/* process_context_token.c */
#define _gss_sanon_process_context_token vassym__gss_sanon_process_context_token

/* release_cred.c */
#define _gss_sanon_release_cred vassym__gss_sanon_release_cred

/* release_name.c */
#define _gss_sanon_release_name vassym__gss_sanon_release_name

/* sanon_locl.h */

/* sanon-private.h */

/* asn1_ContextFlags.c */
#define encode_ContextFlags vassym_encode_ContextFlags
#define decode_ContextFlags vassym_decode_ContextFlags
#define free_ContextFlags vassym_free_ContextFlags
#define length_ContextFlags vassym_length_ContextFlags
#define copy_ContextFlags vassym_copy_ContextFlags
#define print_ContextFlags vassym_print_ContextFlags
#define ContextFlags2int vassym_ContextFlags2int
#define int2ContextFlags vassym_int2ContextFlags

/* asn1_MechType.c */
#define encode_MechType vassym_encode_MechType
#define decode_MechType vassym_decode_MechType
#define free_MechType vassym_free_MechType
#define length_MechType vassym_length_MechType
#define copy_MechType vassym_copy_MechType
#define print_MechType vassym_print_MechType

/* asn1_MechTypeList.c */
#define encode_MechTypeList vassym_encode_MechTypeList
#define decode_MechTypeList vassym_decode_MechTypeList
#define free_MechTypeList vassym_free_MechTypeList
#define length_MechTypeList vassym_length_MechTypeList
#define copy_MechTypeList vassym_copy_MechTypeList
#define print_MechTypeList vassym_print_MechTypeList
#define add_MechTypeList vassym_add_MechTypeList
#define remove_MechTypeList vassym_remove_MechTypeList

/* asn1_NegHints.c */
#define encode_NegHints vassym_encode_NegHints
#define decode_NegHints vassym_decode_NegHints
#define free_NegHints vassym_free_NegHints
#define length_NegHints vassym_length_NegHints
#define copy_NegHints vassym_copy_NegHints
#define print_NegHints vassym_print_NegHints

/* asn1_NegStateEnum.c */
#define encode_NegStateEnum vassym_encode_NegStateEnum
#define decode_NegStateEnum vassym_decode_NegStateEnum
#define free_NegStateEnum vassym_free_NegStateEnum
#define length_NegStateEnum vassym_length_NegStateEnum
#define copy_NegStateEnum vassym_copy_NegStateEnum
#define print_NegStateEnum vassym_print_NegStateEnum

/* asn1_NegTokenInit.c */
#define encode_NegTokenInit vassym_encode_NegTokenInit
#define decode_NegTokenInit vassym_decode_NegTokenInit
#define free_NegTokenInit vassym_free_NegTokenInit
#define length_NegTokenInit vassym_length_NegTokenInit
#define copy_NegTokenInit vassym_copy_NegTokenInit
#define print_NegTokenInit vassym_print_NegTokenInit

/* asn1_NegTokenInit2.c */
#define encode_NegTokenInit2 vassym_encode_NegTokenInit2
#define decode_NegTokenInit2 vassym_decode_NegTokenInit2
#define free_NegTokenInit2 vassym_free_NegTokenInit2
#define length_NegTokenInit2 vassym_length_NegTokenInit2
#define copy_NegTokenInit2 vassym_copy_NegTokenInit2
#define print_NegTokenInit2 vassym_print_NegTokenInit2

/* asn1_NegTokenResp.c */
#define encode_NegTokenResp vassym_encode_NegTokenResp
#define decode_NegTokenResp vassym_decode_NegTokenResp
#define free_NegTokenResp vassym_free_NegTokenResp
#define length_NegTokenResp vassym_length_NegTokenResp
#define copy_NegTokenResp vassym_copy_NegTokenResp
#define print_NegTokenResp vassym_print_NegTokenResp

/* asn1_NegotiationToken.c */
#define encode_NegotiationToken vassym_encode_NegotiationToken
#define decode_NegotiationToken vassym_decode_NegotiationToken
#define free_NegotiationToken vassym_free_NegotiationToken
#define length_NegotiationToken vassym_length_NegotiationToken
#define copy_NegotiationToken vassym_copy_NegotiationToken
#define print_NegotiationToken vassym_print_NegotiationToken

/* asn1_NegotiationToken2.c */
#define encode_NegotiationToken2 vassym_encode_NegotiationToken2
#define decode_NegotiationToken2 vassym_decode_NegotiationToken2
#define free_NegotiationToken2 vassym_free_NegotiationToken2
#define length_NegotiationToken2 vassym_length_NegotiationToken2
#define copy_NegotiationToken2 vassym_copy_NegotiationToken2
#define print_NegotiationToken2 vassym_print_NegotiationToken2

/* asn1_GSSAPIContextToken.c */
#define encode_GSSAPIContextToken vassym_encode_GSSAPIContextToken
#define decode_GSSAPIContextToken vassym_decode_GSSAPIContextToken
#define free_GSSAPIContextToken vassym_free_GSSAPIContextToken
#define length_GSSAPIContextToken vassym_length_GSSAPIContextToken
#define copy_GSSAPIContextToken vassym_copy_GSSAPIContextToken
#define print_GSSAPIContextToken vassym_print_GSSAPIContextToken

/* gkrb5_err.c */
#define initialize_gk5_error_table_r vassym_initialize_gk5_error_table_r
#define initialize_gk5_error_table vassym_initialize_gk5_error_table

/* gkrb5_err.h */

/* negoex_err.c */
#define initialize_ngex_error_table_r vassym_initialize_ngex_error_table_r
#define initialize_ngex_error_table vassym_initialize_ngex_error_table

/* negoex_err.h */

/* gsskrb5-private.h */

/* spnego-private.h */

/* sanon-private.h */

/* ntlm-private.h */

/* spnego_asn1.h */

/* spnego_asn1-priv.h */

/* gssapi_asn1.h */

/* gssapi_asn1-priv.h */
#endif
