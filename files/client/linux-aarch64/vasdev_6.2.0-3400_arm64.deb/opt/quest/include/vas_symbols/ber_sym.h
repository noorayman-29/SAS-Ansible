#ifndef ber_sym_h
#define ber_sym_h

/* libber.h */

/* memory.c */
#define ber_realloc vassym_ber_realloc
#define ber_read vassym_ber_read
#define ber_write vassym_ber_write
#define ber_free vassym_ber_free
#define ber_alloc_t vassym_ber_alloc_t
#define ber_bvfree vassym_ber_bvfree
#define ber_bvecfree vassym_ber_bvecfree
#define ber_bvdup vassym_ber_bvdup
#define ber_init vassym_ber_init
#define ber_init_no_copy vassym_ber_init_no_copy
#define ber_flatten vassym_ber_flatten
#define ber_flatten_no_copy vassym_ber_flatten_no_copy
#define ber_memvfree vassym_ber_memvfree
#define ber_memalloc_x vassym_ber_memalloc_x
#define ber_memalloc vassym_ber_memalloc
#define ber_memcalloc_x vassym_ber_memcalloc_x
#define ber_memcalloc vassym_ber_memcalloc
#define ber_memrealloc_x vassym_ber_memrealloc_x
#define ber_memrealloc vassym_ber_memrealloc
#define ber_strdup_x vassym_ber_strdup_x
#define ber_strdup vassym_ber_strdup
#define ber_dupbv_x vassym_ber_dupbv_x
#define ber_dupbv vassym_ber_dupbv
#define ber_str2bv_x vassym_ber_str2bv_x
#define ber_str2bv vassym_ber_str2bv
#define ber_memfree_x vassym_ber_memfree_x
#define ber_memfree vassym_ber_memfree

/* decode.c */
#define ber_get_stringbv vassym_ber_get_stringbv
#define ber_skip_tag vassym_ber_skip_tag
#define ber_peek_tag vassym_ber_peek_tag
#define ber_first_element vassym_ber_first_element
#define ber_next_element vassym_ber_next_element
#define ber_scanf vassym_ber_scanf

/* encode.c */
#define ber_put_berval vassym_ber_put_berval
#define ber_printf vassym_ber_printf
#endif
