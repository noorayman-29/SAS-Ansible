#ifndef ldap_sym_h
#define ldap_sym_h

/* libldap.h */

/* add.c */
#define ldap_add_ext vassym_ldap_add_ext
#define ldap_add_ext_s vassym_ldap_add_ext_s

/* attribute.c */
#define ldap_first_attribute vassym_ldap_first_attribute
#define ldap_next_attribute vassym_ldap_next_attribute
#define ldap_get_attribute_ber vassym_ldap_get_attribute_ber

/* blocking.c */
#define ldap_nonblocking vassym_ldap_nonblocking
#define ldap_nonblocking_get_fds vassym_ldap_nonblocking_get_fds

/* buffer.c */
#define libldap_buffer_init vassym_libldap_buffer_init
#define libldap_buffer_init_from_BerElement vassym_libldap_buffer_init_from_BerElement
#define libldap_buffer_to_BerElement vassym_libldap_buffer_to_BerElement
#define libldap_buffer_init_from_berval vassym_libldap_buffer_init_from_berval
#define libldap_buffer_deinit vassym_libldap_buffer_deinit

/* connect.c */
#define libldap_is_connected vassym_libldap_is_connected
#define libldap_connect vassym_libldap_connect
#define libldap_disconnect vassym_libldap_disconnect

/* controls.c */
#define libldap_controls_put vassym_libldap_controls_put
#define libldap_controls_get vassym_libldap_controls_get
#define ldap_controls_free vassym_ldap_controls_free
#define ldap_control_free vassym_ldap_control_free
#define ldap_create_sd_flags_control vassym_ldap_create_sd_flags_control
#define ldap_create_tree_delete_control vassym_ldap_create_tree_delete_control
#define ldap_create_page_control vassym_ldap_create_page_control
#define ldap_parse_page_control vassym_ldap_parse_page_control

/* delete.c */
#define ldap_delete_ext vassym_ldap_delete_ext
#define ldap_delete_ext_s vassym_ldap_delete_ext_s

/* dn.c */
#define ldap_get_dn vassym_ldap_get_dn

/* error.c */
#define libldap_get_default_errmsg vassym_libldap_get_default_errmsg
#define ldap_get_lderrno vassym_ldap_get_lderrno
#define libldap_set_lderrno vassym_libldap_set_lderrno

/* filter.c */
#define libldap_filter_put vassym_libldap_filter_put

/* gss.c */
#define libldap_gss_wrap vassym_libldap_gss_wrap
#define libldap_gss_unwrap vassym_libldap_gss_unwrap

/* gsssasl.c */
#define ldap_gsssasl_bind_s vassym_ldap_gsssasl_bind_s

/* init.c */
#define ldap_init vassym_ldap_init
#define ldap_unbind vassym_ldap_unbind
#define ldap_abandon vassym_ldap_abandon
#define ldap_unbind_s vassym_ldap_unbind_s
#define ldap_unbind_ext vassym_ldap_unbind_ext

/* message.c */
#define libldap_message_free vassym_libldap_message_free
#define libldap_message_send_list vassym_libldap_message_send_list
#define libldap_message_send vassym_libldap_message_send
#define libldap_message_recv_list vassym_libldap_message_recv_list
#define libldap_message_recv vassym_libldap_message_recv
#define ldap_msgfree vassym_ldap_msgfree
#define ldap_msgtype vassym_ldap_msgtype
#define ldap_msgid vassym_ldap_msgid
#define ldap_first_message vassym_ldap_first_message
#define ldap_next_message vassym_ldap_next_message
#define ldap_count_messages vassym_ldap_count_messages
#define ldap_first_reference vassym_ldap_first_reference
#define ldap_next_reference vassym_ldap_next_reference
#define ldap_count_references vassym_ldap_count_references
#define ldap_memfree vassym_ldap_memfree
#define libldap_message_get_ber vassym_libldap_message_get_ber

/* modify.c */
#define ldap_modify_ext vassym_ldap_modify_ext
#define ldap_mods_free vassym_ldap_mods_free
#define ldap_rename vassym_ldap_rename

/* option.c */
#define libldap_options_set_default vassym_libldap_options_set_default
#define libldap_options_free vassym_libldap_options_free
#define ldap_set_option vassym_ldap_set_option
#define ldap_get_option vassym_ldap_get_option

/* parse.c */
#define libldap_parse_ldap_message_length vassym_libldap_parse_ldap_message_length
#define libldap_parse_msgid_and_protoop vassym_libldap_parse_msgid_and_protoop
#define ldap_parse_sasl_bind_result vassym_ldap_parse_sasl_bind_result
#define ldap_parse_reference vassym_ldap_parse_reference
#define ldap_parse_result vassym_ldap_parse_result

/* result.c */
#define ldap_result vassym_ldap_result

/* sasl.c */
#define ldap_sasl_bind vassym_ldap_sasl_bind
#define ldap_sasl_bind_s vassym_ldap_sasl_bind_s

/* search.c */
#define ldap_search_ext vassym_ldap_search_ext
#define ldap_search_ext_s vassym_ldap_search_ext_s

/* socket.c */
#define libldap_socket_connect vassym_libldap_socket_connect
#define libldap_socket_send_ldap_busy_loop vassym_libldap_socket_send_ldap_busy_loop
#define libldap_socket_send vassym_libldap_socket_send
#define libldap_socket_recv vassym_libldap_socket_recv
#define libldap_socket_accept vassym_libldap_socket_accept
#define libldap_socket_init vassym_libldap_socket_init
#define libldap_socket_close vassym_libldap_socket_close

/* value.c */
#define ldap_get_values vassym_ldap_get_values
#define ldap_get_values_len vassym_ldap_get_values_len
#define ldap_count_values vassym_ldap_count_values
#define ldap_count_values_len vassym_ldap_count_values_len
#define ldap_value_free vassym_ldap_value_free
#define ldap_value_free_len vassym_ldap_value_free_len

/* ldif.h */

/* ldif.c */
#define ldif_parse_line vassym_ldif_parse_line
#define ldif_parse_line2 vassym_ldif_parse_line2
#define ldif_countlines vassym_ldif_countlines
#define ldif_getline vassym_ldif_getline
#define ldif_must_b64_encode_register vassym_ldif_must_b64_encode_register
#define ldif_must_b64_encode_release vassym_ldif_must_b64_encode_release
#define ldif_sput vassym_ldif_sput
#define ldif_put vassym_ldif_put
#define ldif_is_not_printable vassym_ldif_is_not_printable
#define ldif_open vassym_ldif_open
#define ldif_close vassym_ldif_close
#define ldif_read_record vassym_ldif_read_record
#define quest_ldif_set_debug vassym_quest_ldif_set_debug

/* fetch.c */
#define ldif_open_url vassym_ldif_open_url
#define ldif_fetch_url vassym_ldif_fetch_url
#endif
