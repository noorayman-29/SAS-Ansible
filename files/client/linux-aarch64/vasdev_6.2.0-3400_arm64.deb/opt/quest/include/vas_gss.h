/**
 * Quest Authentication Services (QAS) API 
 * GSSAPI and SPNEGO Transition API 
 *
 * QAS API Version 4.0
 *
 * Copyright (c) 2010 Quest Software, Inc. All Rights Reserved.
 *
 * This header file is distributed as part of the Quest 
 * Authentication Services (previously Vintela Authentication 
 * Services or VAS) distribution governed by the Quest 
 * Authentication Services (QAS) Software End User License 
 * Agreement (the "EULA"). This header file is part of the 
 * "Licensed Software" licensed to a Licensee under the EULA. 
 * The Licensee may use information learned from this file to 
 * develop software applications that use the libvas library of 
 * QAS as permitted by the EULA, and for no other purpose. If 
 * you are not the Licensee under the EULA, then you do not have 
 * any license to use this file or any information in it. 
 *
 **/

/* NOTE:  This header file contains comment markups that are used with  
 *        the Doxygen (generated) documentation system
 */ 

  
/** @file 
 * Function declarations for SPNEGO convenience functions and functions
 * that allow transition to RFC 2744 GSSAPI
 * 
 * These declarations are intended to be used in conjunction with the
 * GSSAPI (RFC 2744) implementation found in libvas.so. Do not link in 
 * any other GSSAPI library!  
 **/

#ifndef VAS_GSS_H_INCLUDED
#define VAS_GSS_H_INCLUDED

#include "gssapi.h"
#include "vas_krb5.h"

#ifdef __cplusplus
extern "C" {
#endif


/** The encoding types for SPNEGO tokens.
 */
typedef enum vas_gss_spnego_encoding
{
    VAS_GSS_SPNEGO_ENCODING_DER = 0,   /* The tokens are encoded with 
                                          standard ASN.1 DER. */
    VAS_GSS_SPNEGO_ENCODING_BASE64 = 1 /* The tokens are standard ASN.1 DER
                                          encoded, then base64 encoded. */
}vas_gss_spnego_encoding_t;


/** Developers using the GSSAPI functionality QAS API Library should call 
 * vas_gss_initialize() before using any of the vas_gss or GSSAPI v2 
 * functions. Calling vas_gss_initialize() causes some of the data from QAS 
 * API to be used when initializing GSSAPI data structures.  In particular, 
 * calling vas_gss_initialize() allows the GSSAPI to operate using the 
 * credential cache (and keytab) associated with the specified ::vas_id_t.
 * 
 * The design of the GSS API version 2 (RFC 2744) makes it difficult to 
 * accomplish many mechanism-specific tasks such as selection of 
 * default_realm/domain, credential caches,and keytabs. Fortunately, efforts
 * toward GSSAPI v3 are being made in the IETF Kitten Workgroup that may 
 * address some of the difficulties for GSSAPI implementors. 
 * 
 * @param ctx   A ::vas_ctx_t obtained from vas_ctx_alloc().
 * 
 * @param id    A ::vas_id_t whose credential cache, keytab, and realm 
 *              information will be used as defaults for the GSSAPI 
 *              implementation.  Pass in NULL to use standard Kerberos
 *              derived defaults (ccache derived from username and
 *              default_realm and default_keytab_name derived from the 
 *              vas.conf file).
 * 
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_NO_MEMORY     - Memory allocation failed
 *          - VAS_ERR_KRB5          - Kerberos error. Use vas_err_t functions
 *                                    to obtain Kerberos error details
 **/
vas_err_t vas_gss_initialize( vas_ctx_t* ctx , vas_id_t* id );

// Call this function if you want to initialize gss logging based on libvas/gssapi-debug-* config options
int vas_gss_init_logging( vas_ctx_t *ctx );


/** Return global variables in the GSSAPI library back to their 
 * original state.  Every call to vas_gss_initialize() should be 
 * matched by a call to vas_gss_deinitialized() when use of the 
 * GSSAPI is complete.
 *
 * @param ctx     A ::vas_ctx_t obtained from vas_ctx_alloc().
 * 
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM - An invalid parameter was passed
 **/
vas_err_t vas_gss_deinitialize( vas_ctx_t* ctx );


/** Obtain a GSSAPI credential from a ::vas_id_t.
 * 
 * @param ctx     A ::vas_ctx_t obtained from vas_ctx_alloc().
 * 
 * @param id      A ::vas_id_t with established credentials.
 * 
 * @param minor_status  Will be set to the GSS API minor status code
 * 
 * @param usage   One of the following GSS credentials types:
 *                - GSS_C_BOTH
 *                - GSS_C_INITIATE 
 *                - GSS_C_ACCEPT
 * 
 * @param gsscred The Returned credential handle.  Resources associated
 *                with this credential handle must be released by the 
 *                application with a call to gss_release_cred()            
 * 
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM - An invalid parameter was passed
 *          - VAS_ERR_KRB5          - Kerberos error. Use vas_err_t 
 *                                    functions to obtain Kerberos error 
 *                                    details
 **/
OM_uint32 vas_gss_acquire_cred( vas_ctx_t* ctx,
                                vas_id_t* id,
                                OM_uint32* minor_status,
                                gss_cred_usage_t usage,
                                gss_cred_id_t* gsscred );

/** Obtain a ::vas_auth_t from the ::gss_ctx_id_t established by a completed
 * call to gss_accept_sec_context() or vas_gss_spnego_accept(). 
 *  
 * @param minor_status A status code from the security mechanism
 *
 * @param ctx     A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param cred    Credential used as the acceptor in call to 
 *                gss_accept_sec_context().
 *
 * @param context The gss_ctx_id_t returned by completed calls to 
 *                gss_accept_sec_context() and vas_gss_spnego_accept()
 * 
 * @param auth    Set to point to memory allocated by the QAS library.
 *                The resulting ::vas_auth_t must be freed by calling 
 *                vas_auth_free().
 * 
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM - An invalid parameter was passed
 *          - VAS_ERR_KRB5          - Kerberos error. Use vas_err_t 
 *                                    functions to obtain Kerberos error 
 *                                    details
 **/
vas_err_t vas_gss_auth_with_minor( OM_uint32 *minor_status, 
                                   vas_ctx_t *ctx,
                                   gss_cred_id_t cred,
                                   gss_ctx_id_t context,
                                   vas_auth_t **auth );

/** Obtain a ::vas_auth_t from the ::gss_ctx_id_t established by a completed
 * call to gss_accept_sec_context() or vas_gss_spnego_accept(). 
 *  
 * @param minor_status A status code from the security mechanism
 *
 * @param ctx     A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param cred    Credential used as the acceptor in call to 
 *                gss_accept_sec_context().
 *
 * @param context The gss_ctx_id_t returned by completed calls to 
 *                gss_accept_sec_context() and vas_gss_spnego_accept()
 *
 * @param server_id The ::vas_id_t of the service initiator. Provide 
 *                  the server_id when the vas_id_t has already been 
 *                  established. Typically when the keytab is not in
 *                  the standard location of /etc/opt/quest/vas/<SERVICE>.keytab
 *
 * 
 * @param auth    Set to point to memory allocated by the QAS library.
 *                The resulting ::vas_auth_t must be freed by calling 
 *                vas_auth_free().
 * 
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM - An invalid parameter was passed
 *          - VAS_ERR_KRB5          - Kerberos error. Use vas_err_t 
 *                                    functions to obtain Kerberos error 
 *                                    details
 **/
vas_err_t vas_gss_auth_with_server_id( OM_uint32 *minor_status,
                                   vas_ctx_t* ctx,
                                   gss_cred_id_t cred,
                                   gss_ctx_id_t context,
                                   vas_id_t * server_id,
                                   vas_auth_t** auth );

/** Obtain a ::vas_auth_t from the ::gss_ctx_id_t established by a completed
 * call to gss_accept_sec_context() or vas_gss_spnego_accept(). 
 *  
 * @param ctx     A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param cred    Credential used as the acceptor in call to 
 *                gss_accept_sec_context().
 *
 * @param context The gss_ctx_id_t returned by completed calls to 
 *                gss_accept_sec_context() and vas_gss_spnego_accept()
 * 
 * @param auth    Set to point to memory allocated by the QAS library.
 *                The resulting ::vas_auth_t must be freed by calling 
 *                vas_auth_free().
 * 
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_INVALID_PARAM - An invalid parameter was passed
 *          - VAS_ERR_KRB5          - Kerberos error. Use vas_err_t 
 *                                    functions to obtain Kerberos error 
 *                                    details
 **/
vas_err_t vas_gss_auth( vas_ctx_t* ctx,
                        gss_cred_id_t cred,
                        gss_ctx_id_t context,
                        vas_auth_t** auth );


/** Convenience function used to obtain an initiator GSS SPNEGO token (or 
 * continue GSS SPNEGO negotiation as an initiator).
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id        The ::vas_id_t of the client initiator.
 * 
 * @param reserved  Pass in NULL.
 * 
 * @param gssctx    Will be set to a gss_ctx_id_t, the read/modify context 
 *                  handle for the new context.
 *                  Supply GSS_C_NO_CONTEXT for the first call. Resources 
 *                  associated with this context handle must be release by 
 *                  the application after use with a call to 
 *                  gss_delete_sec_context()
 *
 * @param name      The principal name of the server.  It is recommended that
 *                  this name contain the keberos realm, as the default is to
 *                  use the default realm component.
 *                  For example: "http/jaws.foobar.com@foobar.com"
 * 
 * @param  flags    Bitmask of GSS_C_XXXXX_FLAG values.  Currently supports
 *                  - GSS_C_DELEG_FLAG
 *                  - GSS_C_MUTUAL_FLAG 
 *                  - GSS_C_REPLAY_FLAG
 *                  - GSS_C_SEQUENCE_FLAG
 *                  - GSS_C_CONF_FLAG
 *                  - GSS_C_INTEG_FLAG
 *
 * @param encoding  Specifies the encoding format for in and out negotiation
 *                  tokens.  Currently supported values include:
 *                  - VAS_GSS_SPNEGO_ENCODING_DER
 *                  - VAS_GSS_SPNEGO_ENCODING_BASE64
 *
 * @param in_token  The input token buffer. Should be GSS_C_NO_BUFFER when
 *                  on first call.  On a subsequent calls, the in_token should 
 *                  be the negTokenTarg NegotiationToken like what is returned
 *                  as an out_token from a call to vas_gss_spnego_accept().
 *
 * @param out_token Pointer to the output token buffer.  The caller is 
 *                  responsible to free the out_token buffer with call 
 *                  to gss_release_buffer() when no longer needed or before 
 *                  subsequent calls to  vas_gss_spnego_initiate().  The 
 *                  out_token buffer will be a Mechanism-Independent Token 
 *                  as defined by RFC 2078 where the innerToken is a 
 *                  negTokenInit Negotiation Token as defined by RFC 2478. 
 *                  The resulting out_token is suitable for use as an 
 *                  in_token in a call to vas_gss_spnego_accept()
 *
 * @return  GSS status code as documented in 5.19 of RFC 2744. 
 **/
OM_uint32 vas_gss_spnego_initiate( vas_ctx_t* ctx,
                                   vas_id_t* id,
                                   void* reserved,
                                   gss_ctx_id_t* gssctx,
                                   const char* name,
                                   OM_uint32 flags,
                                   vas_gss_spnego_encoding_t encoding,
                                   const gss_buffer_t in_token,
                                   gss_buffer_t out_token );


/** Convenience function used to accept GSS SPNEGO tokens (or continue 
 * GSS SPNEGO negotiation as an acceptor).
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id        The ::vas_id_t of the service acceptor.
 * 
 * @param auth      Set to point to memory allocated by the QAS library. 
 *                  The resulting ::vas_auth_t must be freed by calling 
 *                  vas_auth_free(). The auth parameter is ignored if you
 *                  pass in NULL.
 * 
 * @param gssctx    gss_ctx_id_t, read/modify context handle for new context.
 *                  Supply GSS_C_NO_CONTEXT for first call. Resources 
 *                  associated with this context handle must be release by 
 *                  the application after use with a call to 
 *                  gss_delete_sec_context()
 *
 * @param flags     Flags that were returned by underlying gssapi call.
 *
 * @param encoding  Specifies the encoding format for in and out negotiation
 *                  tokens.  Currently supported values include:
 *                  - VAS_GSS_SPNEGO_ENCODING_DER
 *                  - VAS_GSS_SPNEGO_ENCODING_BASE64
 *
 * @param in_token  The input token buffer which should be a 
 *                  Mechanism-Independent Token as defined by RFC 2078
 *                  where the innerToken is a negTokenInit Negotiation 
 *                  Token; this is what is generated as an out_token by 
 *                  the call to vas_gss_spnego_initiate().
 *
 * @param out_token The output token buffer.  The caller is responsible 
 *                  for freeing the out_token buffer with a call to 
 *                  gss_release_buffer() when no longer needed or before 
 *                  subsequent calls to vas_gss_spnego_accept().  The 
 *                  output buffer is a negTokenTarg Negotiation token 
 *                  that is suitable for use as an in_token in a call to 
 *                  vas_gss_spnego_initiate().
 *
 * @param deleg_cred If the initiation is for delegated credentials,
 *                   this parameter will be set to hold the delegation
 *                   credentials.  If used, it must be freed by the
 *                   caller with call to gss_release_cred().  Pass NULL
 *                   if delegated creds are not desired.
 *
 * @return  GSS status code as documented in 5.19 of RFC 2744.
 **/
OM_uint32 vas_gss_spnego_accept( vas_ctx_t* ctx,
                                 vas_id_t* id,
                                 vas_auth_t** auth,
                                 gss_ctx_id_t* gssctx,
                                 OM_uint32* flags,
                                 vas_gss_spnego_encoding_t encoding,
                                 const gss_buffer_t in_token,
                                 gss_buffer_t out_token,
                                 gss_cred_id_t* deleg_cred );


/** Obtain the subkey associated with an initiator or acceptor gss_ctx_id_t.
 *
 * @param ctx         A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param gssctx      A ::gss_ctx_id_t returned by a completed call to either 
 *                    gss_accept_sec_context(), gss_init_sec_context(), 
 *                    vas_gss_spnego_initiate(), or vas_gss_spnego_accept()
 *
 * @param key         Returns the keyblock.  Returned pointer must be freed
 *                    by calling krb5_free_keyblock()
 *
 * @return  GSS_S_COMPLETE or GSS_KRB5_S_KG_NO_SUBKEY
 **/
OM_uint32 vas_gss_krb5_get_subkey( vas_ctx_t* ctx,
                                   gss_ctx_id_t gssctx,
                                   krb5_keyblock** key );

#ifdef __cplusplus
}
#endif

#endif
