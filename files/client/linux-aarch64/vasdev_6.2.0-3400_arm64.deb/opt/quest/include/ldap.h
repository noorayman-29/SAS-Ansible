/** 
 * Copyright 2006 Quest Software, Inc.  -  All Rights Reserved
 * 
 * This header file is distributed as part of the Vintela Authentication 
 * Services (VAS) distribution governed by the Vintela Authentication 
 * Services (VAS) Software End User License Agreement (the "EULA"). 
 * This header file is part of the "Licensed Software" licensed to a 
 * Licensee under the EULA.  The Licensee may use information learned 
 * from this file to develop software applications that use the libvas 
 * library of VAS as permitted by the EULA, and for no other purpose.  
 * If you are not the Licensee under the EULA, then you do not have any 
 * license to use this file or any information in it. 
 * 
 **/
 
/** @file
 * Header file for the LDAPv3 API defined in draft-ietf-ldapext-ldap-c-api-05
 * and the LDAPv2 API defined by RFC 1823.
 * This LDAP implementation only performs SASL binds for authentication.
 * All SASL binds use GSSAPI for authentication and data encryption, which
 * uses the GSSAPI implementation in libvas. The VAS LDAP implementation
 * aims to be source compatible with the OpenLDAP and Netscape LDAP 
 * implementations. 
 * 
 * The VAS LDAP and BER implementations are in libvas.so. DO NOT link 
 * in a separate ldap or ber library.
 * 
 * Also note that the LDAP API is very complex. For a simplified API for
 * searching Active Directory that takes advantage of the VAS infrastructure,
 * see the VAS API defined in vas.h.
 * 
 **/

#ifndef LDAP_H_INCLUDED
#define LDAP_H_INCLUDED

#include <ber.h>
#include <gssapi.h>
#include <sys/time.h> /* required for timeval on darwin */

#ifdef __cplusplus
extern "C" {
#endif

/* Include the symbol fixing header file */
#ifndef NO_VAS_SYM_FIXING
#include <vas_symbols/ldap_sym.h>
#endif

#if 0
/* LDAP_CONST is defined as 'const' for ldapext-ldap-c-api compatibility,
 * but should be defined as an empty token for RFC 1823 compatibility */
#ifndef LDAP_CONST
#define LDAP_CONST		const
#endif
#endif

/***************************************************************************
 *****                     LDAP REQUEST VALUES                       *******
 ***************************************************************************/

/** BER value to request a bind operation. */
#define LDAP_REQ_BIND      ((ber_tag_t) 0x60U)

/** BER value to request an unbind operation. */
#define LDAP_REQ_UNBIND    ((ber_tag_t) 0x42U)

/** BER value to request a search operation. */
#define LDAP_REQ_SEARCH    ((ber_tag_t) 0x63U)

/** BER value to request a modify operation. */
#define LDAP_REQ_MODIFY    ((ber_tag_t) 0x66U)

/** BER value to request an add operation. */
#define LDAP_REQ_ADD       ((ber_tag_t) 0x68U)

/** BER value to request a delete operation. */
#define LDAP_REQ_DELETE    ((ber_tag_t) 0x4aU)

/** BER value to request a modify RDN operation. */
#define LDAP_REQ_MODDN     ((ber_tag_t) 0x6cU)
#define LDAP_REQ_MODRDN    LDAP_REQ_MODDN
#define LDAP_REQ_RENAME    LDAP_REQ_MODDN

/** BER value to request a compare operation. */
#define LDAP_REQ_COMPARE   ((ber_tag_t) 0x6eU)

/** BER value to request that an operation be abandoned. */
#define LDAP_REQ_ABANDON   ((ber_tag_t) 0x50U)

/** BER value to request an extended operation. */
#define LDAP_REQ_EXTENDED  ((ber_tag_t) 0x77U)


/***************************************************************************
 *****                     LDAP RESPONSE VALUES                      *******
 ***************************************************************************/

/** BER value when an LDAPMessage contains a bind response. */
#define LDAP_RES_BIND                   ((ber_tag_t) 0x61U)

/** BER value when an LDAPMessage contains an entry from a search. */
#define LDAP_RES_SEARCH_ENTRY           ((ber_tag_t) 0x64U)

/** BER value when an LDAPMessage contains a search reference. */
#define LDAP_RES_SEARCH_REFERENCE       ((ber_tag_t) 0x73U)

/** BER value when an LDAPMessage contains a search result. */
#define LDAP_RES_SEARCH_RESULT          ((ber_tag_t) 0x65U)

/** BER value when an LDAPMessage contains a modify result. */
#define LDAP_RES_MODIFY                 ((ber_tag_t) 0x67U)

/** BER value when an LDAPMessage contains an add result. */
#define LDAP_RES_ADD                    ((ber_tag_t) 0x69U)

/** BER value when an LDAPMessage contains a delete result. */
#define LDAP_RES_DELETE                 ((ber_tag_t) 0x6bU)

/** BER value when an LDAPMessage contains a modify DN result . */
#define LDAP_RES_MODDN                  ((ber_tag_t) 0x6dU)

/** BER value when an LDAPMessage contains a modify RDN result . */
#define LDAP_RES_MODRDN                 LDAP_RES_MODDN

/** BER value when an LDAPMessage contains a rename result . */
#define LDAP_RES_RENAME                 LDAP_RES_MODDN

/** BER value when an LDAPMessage contains a compare result . */
#define LDAP_RES_COMPARE                ((ber_tag_t) 0x6fU)

/** BER value when an LDAPMessage contains an extended result . */
#define LDAP_RES_EXTENDED               ((ber_tag_t) 0x78U)

/** BER value when an LDAPMessage contains an extended partial result. */
#define LDAP_RES_EXTENDED_PARTIAL       ((ber_tag_t) 0x79U)
                             

/***************************************************************************
 *****                     LDAP ERROR CODES                          *******
 ***************************************************************************/

/** Determine if n is in the range between x and y. */
#define LDAP_RANGE(n,x,y)   (((x) <= (n)) && ((n) <= (y)))

/** Return code that indicates successful operation. */
#define LDAP_SUCCESS                     0x00

/** Error code that indicates an operational error occurred. */
#define LDAP_OPERATIONS_ERROR            0x01

/** Error code that indicates a protocol error occurred. */
#define LDAP_PROTOCOL_ERROR              0x02

/** Error code that indicates the operation timed out. */
#define LDAP_TIMELIMIT_EXCEEDED          0x03

/** Error code that indicates that a size limit was succeeded. */
#define LDAP_SIZELIMIT_EXCEEDED          0x04

/** Error code that indicates a compare operation returned false. */
#define LDAP_COMPARE_FALSE               0x05

/** Error code that indicates a compare operation returned true. */
#define LDAP_COMPARE_TRUE                0x06

/** Error code that indicates the authentication method is not supported. */
#define LDAP_AUTH_METHOD_NOT_SUPPORTED   0x07

/** Error code that indicates the authentication method is not supported. */
#define LDAP_STRONG_AUTH_NOT_SUPPORTED   LDAP_AUTH_METHOD_NOT_SUPPORTED

/** Error code that indicates the strong authentication is required. */
#define LDAP_STRONG_AUTH_REQUIRED        0x08

/** Error code that partial results and a referral were received. */
#define LDAP_PARTIAL_RESULTS             0x09

/** Error code that indicates a referral was returned. (LDAPv3 only) */
#define LDAP_REFERRAL                    0x0a

/** Error code that indicates the "look through limit" for a search was 
 * exceeded. (LDAPv3 only) */
#define LDAP_ADMINLIMIT_EXCEEDED         0x0b

/** Error code that indicates the server does not support the specified 
 * control or matching rule. (LDAPv3 only) */
#define LDAP_UNAVAILABLE_CRITICAL_EXTENSION     0x0c

/** Error code that indicates the server requires confidentiality to return 
 * the result. (LDAPv3 only) */
#define LDAP_CONFIDENTIALITY_REQUIRED    0x0d

/** Error code used in multi-stage SASL binds. This is returned until the 
 * authentication process is completed. (LDAPv3 only) */
#define LDAP_SASL_BIND_IN_PROGRESS       0x0e

/** Determine if the given error code deals with attribute errors. */
#define LDAP_ATTR_ERROR(n)  LDAP_RANGE((n),0x10,0x15) /* 16-21 */

/** Error code that indicates the specified attribute does not exist in 
 * the specified entry. */
#define LDAP_NO_SUCH_ATTRIBUTE           0x10

/** Error code that indicates the request specified an undefined 
 * attribute type. */
#define LDAP_UNDEFINED_TYPE              0x11

/** Error code that indicates the filter contains a matching rule 
 * that does not work with the specified attributes. */
#define LDAP_INAPPROPRIATE_MATCHING      0x12

/** Error code that indicates a request value does not comply with some
 *  constraints. */
#define LDAP_CONSTRAINT_VIOLATION        0x13

/** Error code that indicates that an add request attempted to add
 * a value that already exists. */
#define LDAP_TYPE_OR_VALUE_EXISTS        0x14

/** Error code that indicates the request contains invalid syntax. */
#define LDAP_INVALID_SYNTAX              0x15

/** Determine if the given error code deals with naming errors. */
#define LDAP_NAME_ERROR(n)  LDAP_RANGE((n),0x20,0x24) /* 32-34,36 */ 

/** Error code that indicates the server could not find an entry for 
 * the request. */
#define LDAP_NO_SUCH_OBJECT              0x20

/** Error code that indicates that dereferencing an alias resulted in 
 * an error. */
#define LDAP_ALIAS_PROBLEM               0x21

/** Error code that indicates an invalid DN was specified. */
#define LDAP_INVALID_DN_SYNTAX           0x22

/** Error code that indicates the specified entry is a leaf node. */
#define LDAP_IS_LEAF                     0x23 /* not LDAPv3 */

/** Error code that indicates that dereferencing an alias resulted in 
 * an error. */
#define LDAP_ALIAS_DEREF_PROBLEM         0x24

/** Determine if the given error deals with authentication/security 
 * errors. */
#define LDAP_SECURITY_ERROR(n)  LDAP_RANGE((n),0x30,0x32) /* 48-50 */

/** Error code that indicates the supplied credentials are inappropriate
 * for the requested authentication method. */
#define LDAP_INAPPROPRIATE_AUTH                 0x30

/** Error code that indicates the supplied credentials are invalid. */
#define LDAP_INVALID_CREDENTIALS                0x31

/** Error code that indicates the client does not rights to perform 
 * the operation. */
#define LDAP_INSUFFICIENT_ACCESS                0x32

/** Determine if the given error deals with service errors. */
#define LDAP_SERVICE_ERROR(n)   LDAP_RANGE((n),0x33,0x36) /* 51-54 */

/** Error code that indicates the server is too busy to perform the 
 * operation. */
#define LDAP_BUSY                               0x33

/** Error code that indicates that the server is not available to 
 * perform the operation. */
#define LDAP_UNAVAILABLE                        0x34

/** Error code that indicates that the server will not perform the 
 * operation. */
#define LDAP_UNWILLING_TO_PERFORM               0x35

/** Error code that indicates the server detecteded an internal loop
 * that prevented it from performing the operation. */
#define LDAP_LOOP_DETECT                        0x36

/** Determine if the given error deals with object creation or 
 * modification. */
#define LDAP_UPDATE_ERROR(n)    LDAP_RANGE((n),0x40,0x47) /* 64-69,71 */

/** Error code that indicates the result does not conform to the 
 * DIT structure. */
#define LDAP_NAMING_VIOLATION                   0x40

/** Error code that indicates the request violates the server's schema. */
#define LDAP_OBJECT_CLASS_VIOLATION             0x41

/** Error code that indicates the operation can only be performed on a 
 * leaf node, and the specified entry is a parent node. */
#define LDAP_NOT_ALLOWED_ON_NONLEAF             0x42

/** Error code that indicates that the operation would affect the 
 * entry's RDN. */
#define LDAP_NOT_ALLOWED_ON_RDN                 0x43

/** Error code that indicates that an add request is for an entry 
 * that already exists. */
#define LDAP_ALREADY_EXISTS                     0x44

/** Error code that indicates the request is attempting to modify
 * things that should not be modified (i.e. a structural object class) */
#define LDAP_NO_OBJECT_CLASS_MODS               0x45

/** Error code that indicates that the request results are too large to
 * be returned. */
#define LDAP_RESULTS_TOO_LARGE                  0x46

/** Error code that indicates that the request must be performed on
 * different servers. */
#define LDAP_AFFECTS_MULTIPLE_DSAS              0x47

/** Error code that indicates an unknown error occurred. */
#define LDAP_OTHER                              0x50

/** Error code that indicates that a connection to the server was lost
 * or could not be established. */
#define LDAP_SERVER_DOWN                        0x51

/** Error code that indicates that the client had an error. */
#define LDAP_LOCAL_ERROR                        0x52

/** Error code that indicates the client could not encode the 
 * LDAP request. */
#define LDAP_ENCODING_ERROR                     0x53

/** Error code that indicates the client could not decode the 
 * LDAP response. */
#define LDAP_DECODING_ERROR                     0x54

/** Error code that indicates that the server response did not
 * return soon enough. */
#define LDAP_TIMEOUT                            0x55

/** Error code that indicates an unknown authentication mechanisim 
 * was requested. */
#define LDAP_AUTH_UNKNOWN                       0x56

/** Error code that indicates that specifying the search filter failed. */
#define LDAP_FILTER_ERROR                       0x57

/** Error code that indicates the user cancelled the LDAP operation. */
#define LDAP_USER_CANCELLED                     0x58

/** Error code that indicates an invalid parameter was supplied. */
#define LDAP_PARAM_ERROR                        0x59

/** Error code that indicates the system is out of memory. */
#define LDAP_NO_MEMORY                          0x5a

/** Error code that indicates the client lost or could not establish the 
 * connection with the LDAP server. */
#define LDAP_CONNECT_ERROR                      0x5b

/** Error code that indicates the server does not support functionality 
 * the client is requesting. */
#define LDAP_NOT_SUPPORTED                      0x5c

/** Error code that indicates a requested LDAP control was not found. */
#define LDAP_CONTROL_NOT_FOUND                  0x5d

/** Error code that indicates the server did not return any results. */
#define LDAP_NO_RESULTS_RETURNED                0x5e

/** Error code that indicates there are more results to process. */
#define LDAP_MORE_RESULTS_TO_RETURN             0x5f


/* LDAP options */
#define LDAP_OPT_PRIVATE_EXTENSION_BASE	    0x4000
#define LDAP_OPT_NON_BLOCKING               0x4000
#define LDAP_OPT_MAX_RECV_PDU               0x4001
#define LDAP_OPT_MAX_SEND_PDU               0x4002
#define LDAP_OPT_GSS_SECURITY_LAYERS        0x4003
#define LDAP_OPT_GSS_CONTEXT                0x4004
#define LDAP_OPT_SEARCH_BASE                0x4005
#define LDAP_OPT_TIMELIMIT                  0x4006
#define LDAP_OPT_CONNECT_TIMEOUT            0x4007
#define LDAP_OPT_SERVERS                    0x4FFE
#define LDAP_OPT_KERBEROS_REALM             0x4FFF

/** Specifies the LDAP search should use the default search scope, which is
 * LDAP_SCOPE_SUBTREE. */
#define LDAP_SCOPE_DEFAULT      ((ber_int_t) -1)

/** Specifies that the LDAP search should search only the search base. */
#define LDAP_SCOPE_BASE         ((ber_int_t) 0x0000)

/** Specifies that the LDAP search should search all entries one level
 * below the search base. */
#define LDAP_SCOPE_ONELEVEL     ((ber_int_t) 0x0001)

/** Specifies that the LDAP search should search the search base entry and 
 * everything under the search base. */
#define LDAP_SCOPE_SUBTREE      ((ber_int_t) 0x0002)

/** The default LDAP Port */
#define LDAP_PORT       389
#define LDAP_PORT_STR   "389"
#define GC_PORT         3268

/** An LDAP session context.
 * An opaque structure that must be obtained through a call to ldap_init().
 * All ldap functions require a valid LDAP context.
 **/
struct ldap;
typedef struct ldap LDAP;


/** An LDAP Message structure.
 * An opaque structure that represents the results of an LDAP operation.
 **/
struct ldapmsg;
typedef struct ldapmsg LDAPMessage;


/** An LDAP control structure.
 * A structure for client or server controls associated with an LDAP 
 * operation.
 **/
typedef struct ldapcontrol 
{ 
    char*           ldctl_oid; 
    struct berval   ldctl_value; 
    char            ldctl_iscritical; 
} LDAPControl;


/**--------------------------------------------------------------------------
 * LDAPMod represents a modification changes associated with an LDAP
 * operation.
 *
 * Note the following: 
 *
 *    If you specify LDAP_MOD_DELETE in the mod_op field and you remove all
 *    values in an attribute, the attribute is removed from the entry. 
 *
 *    If you specify LDAP_MOD_DELETE in the mod_op field and NULL in the 
 *    mod_values field, the attribute is removed from the entry. 
 *    
 *    If you specify LDAP_MOD_REPLACE in the mod_op field and NULL in the 
 *    mod_values field, the attribute is removed from the entry. 
 * 
 *    If you specify LDAP_MOD_REPLACE in the mod_op field and the attribute 
 *    does not exist in the entry, the attribute is added to the entry. 
 *
 *    If you specify LDAP_MOD_ADD in the mod_op field and the attribute 
 *    does not exist in the entry, the attribute is added to the entry.
 *
 *    If you ve allocated memory for the structures yourself, you should 
 *    free the structures when you re finished by calling ldap_mods_free()
 *-------------------------------------------------------------------------*/
typedef union mod_vals_u 
{ 
    /* A pointer to a NULL-terminated array of string values for the 
     * attribute.
     */
    char** modv_strvals; 

    /* A pointer to a NULL-terminated array of berval structures for
     * the attribute.
     */
    struct berval** modv_bvals; 
} mod_vals_u_t;

typedef struct ldapmod 
{ 
    /* The operation to be performed on the attribute and the type of data
     * specified as the attribute values. This field can have one of the 
     * following values: 
     *    LDAP_MOD_ADD adds a value to the attribute. 
     *    LDAP_MOD_DELETE removes the value from the attribute. 
     *    LDAP_MOD_REPLACE replaces all existing values of the attribute. 
     *
     * In addition, if you are specifying binary values in the mod_bvalues 
     * field, you should use the bitwise OR operator ( | ) to combine 
     * LDAP_MOD_BVALUES with the operation type. For example: 
     *    mod->mod_op = LDAP_MOD_ADD | LDAP_MOD_BVALUES 
     *
     * Note that if you are using the structure a call to ldap_add() the
     * mod_op field be zero unless unless you are adding binary values
     * and need to specify LDAP_MOD_BVALUES). 
     */
    #define LDAP_MOD_ADD            ((ber_int_t) 0x0000)
    #define LDAP_MOD_DELETE         ((ber_int_t) 0x0001)
    #define LDAP_MOD_REPLACE        ((ber_int_t) 0x0002)
    #define LDAP_MOD_BVALUES        ((ber_int_t) 0x0080)
    
    int mod_op;    

    /* The attribute type that you want to add, delete, or replace the values
     * of (for example,  sn  or  telephoneNumber ).
     */
    char* mod_type; 

    mod_vals_u_t mod_vals; 
    #define mod_values mod_vals.modv_strvals 
    #define mod_bvalues mod_vals.modv_bvals 
} LDAPMod;

/** Initialize an LDAP context.
 * Creates a session with an LDAP server, and return an LDAP structure
 * that represents the connection to the specified server that may be used
 * in subsequent ldap calls.
 *
 * @param   defhost  Space-separated list of hostnames or dotted strings
 * 		     representing the IP address of hosts running an
 * 		     LDAP server to connect to. Each hostname MAY include
 * 		     a port number which is separated from the host itself
 * 		     with a colon (:) character. The hosts will be tried
 * 		     in the order listed, stopping with the first one to
 * 		     which a successful connection is made.
 * 		     May not be NULL.
 * @param   defport  TCP port to connect to. Use zero or LDAP_PORT to use 
 *                   the standard LDAP port (389). 
 *                   If a host includes a port number, then this parameter
 *                   is ignored.
 *
 * @return  A pointer to the LDAP context on success, NULL on a failure.
 *          The LDAP context should be freed by the caller with 
 *          ldap_unbind().
 *          If NULL is returned, errno contains the error.
 **/
LDAP* ldap_init( const char* defhost, int defport );


/** Destroy an LDAP context.
 * Closes the connection to the LDAP server, and frees the resources 
 * contained in the LDAP structure.
 *
 * @param ld    Pointer to an LDAP structure containing information about
 *              the connection to the LDAP server.
 * 
 * @return      LDAP_SUCCESS            If successful. 
 *              LDAP_OPERATIONS_ERROR   If un-parsed LDAPMessages were left
 *                                      in the result queue.  For debugging
 *                                      purposes developers SHOULD check
 *                                      for LDAP_OPERATIONS_ERROR to ensure
 *                                      that their code is not hogging 
 *                                      memory.  This is especially true 
 *                                      when the API is used as part of a
 *                                      daemon operation where un-processed
 *                                      messages could represent a 
 *                                      significant memory leak.
 **/
int ldap_unbind( LDAP* ld );


/** Abandon outstanding requests for a given message id.
 * This will clear off any messages from both the receive and send queues that
 * match the passed in msgid.  If msgid == 0, then all outstanding request
 * and send queues will be cleared.
 *
 * @param   ld      Pointer to an LDAP structure containing information about
 *                  the connection to the LDAP server.
 *          msgid   The message id to abandon.  A msgid of 0 means all messages
 *                  on both the send and receive queues will be discarded.
 * @return  LDAP_SUCCESS                If successful.
 *                  
 *
 **/
int ldap_abandon( LDAP *ld, int msgid );

/** Authenticate the LDAP client using a SASL mechanism.
 * Using a Simple Authentication and Security Layer mechanism, the LDAP
 * connection will be authenticated. This should not be called directly
 * if you want to use the GSSAPI -- use ldap_gsssasl_bind_s() instead.
 *
 * @param ld        Connection handle obtained from the call to ldap_init()
 *
 * @param dn        Distinguished name (DN) of the user who wants to 
 *                  authenticate. This parameter may be NULL if a SASL 
 *                  mechanism specific or anonymous identity is to be used.
 *
 * @param mech      Name of the SASL mechanism to be used for authentication
 * 
 * @param cred      Pointer to the berval structure containing the 
 *                  credentials to be used for authentication.
 *
 * @param sctls     Pointer to an array of LDAPControl structures representing
 *                  LDAP server controls that apply to this LDAP operation. 
 *                  To not pass any server controls, specify NULL for this 
 *                  argument.
 *
 * @param cctls     Pointer to an array of LDAPControl structures representing
 *                  LDAP client controls that apply to this LDAP operation. 
 *                  To not pass any client controls, specify NULL for this 
 *                  argument.
 *
 * @param msgidp    Pointer to an integer that will be set to the message ID
 *                  of the LDAP operation. To check the result of this 
 *                  operation, call ldap_result() and 
 *                  ldap_parse_sasl_bind_result() functions.
 *
 * @return          LDAP_SUCCESS the SASL bind request successfully sent
 *
 *                  LDAP_PARAM_ERROR invalid parameter passed to the function.
 *                 
 *                  LDAP_NOT_SUPPORTED mechanism not supported.
 *
 *                  LDAP_ENCODING_ERROR error during BER-encoding
 *
 *                  LDAP_NO_MEMORY if memory cannot be allocated
 *
 *                  LDAP_SERVER_DOWN if the LDAP server did not receive the 
 *                  request or connection to the server was lost.
 **/
int ldap_sasl_bind( LDAP* ld, 
                    const char* dn, 
                    const char* mech, 
                    const struct berval* cred, 
                    LDAPControl** sctrls, 
                    LDAPControl** cctrls, 
                    int* msgidp );


/** Obtain the result of an LDAP operation.
 * The function ldap_result() waits for and returns the result of an LDAP 
 * operation initiated by one of the asynchronous LDAP API functions 
 *
 * @param ld        Connection handle obtained from call to ldap_init()
 *
 * @param msgid     Message ID of the operation for which you want the 
 *                  results. To check any operation, pass LDAP_RES_ANY as 
 *                  the value of this parameter.
 *        
 * @param all       If zero, only one result is returned, If nonzero all 
 *                  results are returned.  
 *
 * @param timeout   Specifies a maximum amount of time to wait for results. 
 *                  Pass NULL for infinite timeout
 *
 * @param result    Result of the operation. To interpret the results, pass
 *                  this to the LDAP parsing routines,
 * 
 * @return      LDAP_RES_BIND The LDAPMessage structure contains the result
 *              of an LDAP bind operation
 *
 *              LDAP_RES_SEARCH_ENTRY indicates that the LDAPMessage structure
 *              contains an entry found during an LDAP search operation.
 *
 *              LDAP_RES_SEARCH_RESULT indicates that the LDAPMessage structure
 *              contains the result of an LDAP search operation.
 *
 *              LDAP_RES_MODIFY indicates that the LDAPMessage structure 
 *              contains the result of an LDAP modify operation.
 *
 *              LDAP_RES_ADD indicates that the LDAPMessage structure 
 *              contains the result of an LDAP add operation.
 *
 *              LDAP_RES_DELETE indicates that the LDAPMessage structure 
 *              contains the result of an LDAP delete operation.
 *
 *              LDAP_RES_MODDN or LDAP_RES_RENAME indicates that the 
 *              LDAPMessage structure contains the result of an LDAP modify 
 *              DN operation.
 *
 *              LDAP_RES_COMPARE indicates that the LDAPMessage structure 
 *              contains the result of an LDAP compare operation.
 *
 *              LDAP_RES_EXTENDED indicates that the LDAPMessage structure 
 *              contains the result of an LDAPv3 extended operation.
 *
 *              -1 indicates that an error occurred.  To get the error code, 
 *              call the ldap_get_lderrno() function. 
 *
 *              0 indicates that the operation has timed out.
 **/
int ldap_result( LDAP* ld, 
                 int msgid, 
                 int all, 
                 struct timeval* timeout, 
                 LDAPMessage** result );

#define LDAP_MSG_ONE		0x00
#define LDAP_MSG_ALL		0x01
#define LDAP_MSG_RECEIVED	0x02		/* not implemented */


/** Parse a SASL bind result.
 * Parses the results of an LDAP SASL bind operation and retrieves data 
 * (such as a challenge) returned by the server.
 *
 * @param ld            Connection handle obtained from call to ldap_init()
 *
 * @param res           Pointer to the LDAPMessage structure containing the 
 *                      results of an LDAP operation.
 *
 * @param servercredp   Pointer to a pointer to an berval structure 
 *                      containing any challenge or credentials returned by
 *                      the server.
 *
 * @param freeit        Specifies whether or not to free the results of the 
 *                      operation (the LDAPMessage structure specified by the
 *                      res argument). Zero specifies that the result should 
 *                      not be freed. " A non-zero value specifies that the 
 *                      result should be freed. 
 *
 * @returns             LDAP_SUCCESS if the results were parsed successfully.
 *                      
 *                      LDAP_BUSY returned only if LDAP handle was set for
 *                      nonblocking operation (see ldap_set_nonblocking()).
 *
 *                      LDAP_PARAM_ERROR if an invalid parameter was passed 
 *                      to the function. 
 *                       
 *                      LDAP_DECODING_ERROR if an error occurred when decoding
 *                      the BER-encoded message.
 *
 *                      LDAP_OPERATIONS_ERROR server experienced internal
 *                      error
 *
 *                      LDAP_PROTOCOL_ERROR unrecognized version number or 
 *                      incorrect PDU structure
 *
 *                      LDAP_AUTH_METHOD_NOT_SUPPORTED unrecognized SASL mech
 *
 *                      LDAP_STRONG_AUTH_REQUIRED server requires auth
 *
 *                      LDAP_REFERRAL this server can not accept this bind and
 *                      client should try another
 *                       
 *                      LDAP_SASL_BIND_IN_PROGRESS the server requires client
 *                      to send another request with the same sasl mechanism to 
 *                      continue the authentication process
 *                      
 *                      LDAP_INAPPROPRIATE_AUTH and                     
 *                      LDAP_INVALID_CREDENTIALS the wrong credentials were
 *                      supplied
 **/
int ldap_parse_sasl_bind_result( LDAP* ld, 
                                 LDAPMessage* res, 
                                 struct berval** servercredp, 
                                 int freeit );


/** Perform a complete synchronous GSS SASL LDAP bind.  
 *
 * @param ld            Connection handle obtained from call to ldap_init()
 *
 * @param cred          GSSAPI credentials that were obtained via call to 
 *                      gss_acquire_cred().  If using the VAS API, these
 *                      credentials are easily obtained by calling 
 *                      vas_gss_acquire_my_cred().  Credentials must be
 *                      for cred_usage GSS_C_INITIATE.
 *
 * @param timeout       Specifies a maximum amount of time to wait for 
 *                      bind to complete. Pass NULL for infinite timeout
 *
 * @returns             LDAP_SUCCESS on success, or the LDAP_xxxx errorcodes
 *                      #defined in this file.  The return value indicates
 *                      the final status of the bind.  There is no need
 *                      to make subsequent calls to ldap_result() or 
 *                      ldap_parse_sasl_bind_result()
 **/
int ldap_gsssasl_bind_s( LDAP* ld, 
                         gss_cred_id_t cred, 
                         struct timeval* timeout );


/** Get the last error that occurred for an LDAP operation. 
 * You can also call this function to get error codes for functions 
 * that do not return errors (such as ldap_next_attribute()).
 *
 * @param ld            Connection handle obtained from call to ldap_init()
 *
 * @param matcheddn     In the event of an LDAP_NO_SUCH_OBJECT error return, 
 *                      this parameter contains the portion of the DN that 
 *                      identifies an existing entry.  May be NULL. The
 *                      matched DN string should be freed by calling
 *                      ldap_memfree().
 *
 * @param errstr        The text of the error message. May be NULL. The
 *                      error message string should be freed by calling
 *                      ldap_memfree().
 *
 * @returns             LDAP_SUCCESS or one of the LDAP_xxxx errorcodes 
 *                      #defined in this file.
 **/
int ldap_get_lderrno( LDAP* ld, char** matcheddn, char** s );


/** Set session preferences in the LDAP handle.
 *
 * @param ld            Connection handle obtained from call to ldap_init()
 *
 * @param option        Option that to set.  See below for possible options:
 *                       
 *                      LDAP_OPT_PROTOCOL_VERSION protocol version to use.
 *                      currently only version 3 is supported. optdata is int*
 *
 *                      LDAP_OPT_NON_BLOCKING enable or disable non-blocking 
 *                      operation.  0 to disable (default) or 1 to enable.
 *                      optdata is int*
 *                      
 *                      LDAP_OPT_SET_MAX_PDU set the maximium size of LDAP
 *                      message that is allowed to be processed.  
 *                      optdata is int*
 *
 *                      LDAP_OPT_SET_GSS_SECURITY_LAYERS set the gss security
 *                      layers as negotiated via SASL bind (see RFC 2222)
 *                      optdata is int*
 *
 *                      LDAP_OPT_SET_GSS_CONTEXT set the gss context 
 *                      established during gssapi bind. optdata is
 *                      gss_ctx_id_t
 *
 *                      LDAP_OPT_SET_SEARCH_BASE set the default search base
 *                      optdata is char* of searchbase.
 * 
 *                      LDAP_OPT_KERBEROS_REALM the kerberos realm that will
 *                      be used when doing building the gssname in 
 *                      ldap_gsssasl_bind_s().  optdata is the realm string.
 *
 * @param optdata       Pointer to the value of the option to set.
 *
 * @returns             LDAP_SUCCESS, LDAP_PARAM_ERROR or LDAP_NOT_SUPPORTED
 **/
int ldap_set_option( LDAP* ld, int option, const void* optdata );



/** Get session preferences from the LDAP handle.
 *
 * @param ld            Connection handle obtained from call to ldap_init()
 *
 * @param option        Option that to set.  See below for possible options:
 *                       
 *                      LDAP_OPT_PROTOCOL_VERSION protocol version to use.
 *                      currently only version 3 is supported. optdata is int*
 *
 *                      LDAP_OPT_NON_BLOCKING enable or disable non-blocking 
 *                      operation.  0 to disable (default) or 1 to enable.
 *                      optdata is int*
 *                      
 *                      LDAP_OPT_MAX_PDU set the maximium size of LDAP
 *                      message that is allowed to be processed.  
 *                      optdata is int*
 *
 *                      LDAP_OPT_GSS_SECURITY_LAYERS set the gss security
 *                      layers as negotiated via SASL bind (see RFC 2222)
 *                      optdata is int*
 *
 *                      LDAP_OPT_GSS_CONTEXT set the gss context 
 *                      established during gssapi bind. optdata is
 *                      gss_ctx_id_t
 *
 *                      LDAP_OPT_SEARCH_BASE set the default search base
 *                      optdata is char* of searchbase. Must be freed by
 *                      caller, may be NULL.
 *
 * @param optdata       Pointer to the value of the option to get.
 *
 * @returns             LDAP_SUCCESS, LDAP_PARAM_ERROR or LDAP_NOT_SUPPORTED
 **/
int ldap_get_option( LDAP* ld, int option, void* optdata );



/** Search the directory asynchronously.
 *
 * @param ld            Connection handle obtained from call to ldap_init()
 *
 * @param base          Distinguished name (DN) of the entry that serves as 
 *                      the starting point for the search.  Pass NULL to use
 *                      the search base associated with ld.
 *
 * @param scope         Scope of the search: LDAP_SCOPE_BASE, 
 *                      LDAP_SCOPE_ONELEVEL, LDAP_SCOPE_SUBTREE 
 *
 * @param filter        String representation of the filter to apply in the 
 *                      search. i.e  "(attributetype=attributevalue)"
 *
 * @param attrs         A NULL-terminated array of attribute types to return
 *                      from entries that match filter. If you specify a NULL,
 *                      all attributes will be returned.
 *
 * @param attrsonly     Specifies whether or not attribute values are returned 
 *                      along with the attribute types. zero specifies that 
 *                      both attribute types and attribute values are returned.
 *                      non-zero specifies that only attribute types are returned.
 *
 * @param sctls         Pointer to an array of LDAPControl structures 
 *                      representing LDAP server controls that apply to this
 *                      LDAP operation.  To not pass any server controls, 
 *                      specify NULL for this argument.
 *
 * @param cctls         Pointer to an array of LDAPControl structures 
 *                      representing LDAP client controls that apply to this 
 *                      LDAP operation. To not pass any client controls, 
 *                      specify NULL for this argument.
 *
 * @param timelimit     Specifies a maximum amount of time the server has to 
 *                      complete the search to be sent. Pass NULL for default 
 *                      time limit.
 *
 * @param sizelimit     Maximum number of results to return in the search. 
 *                      0 to use the default size limit for the current.
 *
 * @param msgidp        Pointer to an integer that will be set to the message 
 *                      ID of the LDAP operation. To check the result of this 
 *                      operation, call the ldap_result() and 
 *                      ldap_parse_result() functions.
 *
 * @returns             LDAP_SUCCESS or one of the LDAP_xxxx errorcodes 
 *                      #defined in this file.
 **/
int ldap_search_ext( LDAP* ld, 
                     const char* base, 
                     int scope, 
                     const char* filter, 
                     char** attrs, 
                     int attrsonly, 
                     LDAPControl** serverctrls, 
                     LDAPControl** clientctrls, 
                     struct timeval* timelimit, 
                     int sizelimit, 
                     int* msgidp );


/** Get the first attribute of a search entry.
 *
 * @param ld            Connection handle obtained from call to ldap_init()
 *
 * @param entry         Pointer to the LDAPMessage structure representing the
 *                      search entry.
 *
 * @param ber           A pointer to a BerElement allocated to keep track of 
 *                      the current position.  This pointer is passed to 
 *                      subsequent calls to ldap_next_attribute() to iterate
 *                      through a search entry's attributes.  Caller is
 *                      responsible for freeing the returned pointer with a
 *                      call to ber_free with fbuf == 0 i.e. ber_free(ber,0);
 *
 * @returns             If successful, ldap_first_attribute returns a pointer
 *                      to the null terminated string name of the first 
 *                      attribute in an entry.  The caller is responsible
 *                      for freeing this string with a call to ldap_memfree().
 *                      If unsuccessful, returns a NULL.  The appropriate 
 *                      error code will be set in the LDAP structure.  To get
 *                      the error code, call ldap_get_lderrno(). function.
 **/
char* ldap_first_attribute( LDAP* ld, 
                            LDAPMessage* entry, 
                            BerElement** ber );


/** Get the next attribute of a search entry.
 *
 * @param ld            Connection handle obtained from call to ldap_init()
 *
 * @param entry         Pointer to the LDAPMessage structure representing the
 *                      search entry.
 *
 * @param ber           A pointer to a BerElement allocated to keep track of 
 *                      the current position.  This pointer is passed to 
 *                      subsequent calls to ldap_next_attribute() to iterate
 *                      through a search entry's attributes.
 *
 * @returns             If successful, ldap_next_attribute returns a pointer
 *                      to the null terminated string name of the next 
 *                      attribute in an entry.  The caller is responsible
 *                      for freeing this string with a call to ldap_memfree().
 *                      If no more attributes exist ldap_next_attribute 
 *                      returns NULL.
 **/
char* ldap_next_attribute( LDAP* ld, 
                           LDAPMessage* entry, 
                           BerElement* ber);

/** Get the ber element corresponding to an attribute
 *
 * @param   ld          Connection handle obtained from call to ldap_init()
 *
 * @param   entry       The Message entry
 *
 * @param   ber         A pointer to a BerElement allocated for this attribute
 *
 * @param   attr        The Value for the BerElement attribute
 *
 * @param   vals        ????
 *
 * @returns             LDAP_SUCCESS if successful
 *                      LDAP_PARAM_ERROR bad parameter
 *                      LDAP_DECODING_ERROR if couldn't decode message
 *
 **/
extern int ldap_get_attribute_ber( LDAP *ld,
                                   LDAPMessage *entry,
                                   BerElement *ber,
                                   BerValue *attr,
                                   BerVarray *vals );


/** Parse search references from the results received from an LDAP server.
 *
 * @param ld            Connection handle obtained from call to ldap_init()
 *
 * @param res           Pointer to an LDAPMessage structure of the type 
 *                      LDAP_RES_SEARCH_REFERENCE.  
 *
 * @param referralsp    Pointer to an array of strings that receives the 
 *                      referrals returned by the server. Must be freed by 
 *                      call to ldap_memfree().  
 *
 * @param serverctrlsp  Pointer to an array that receives LDAPControl 
 *                      structures, which represent the LDAPv3 server controls
 *                      returned by the server. Must be freed by call to 
 *                      ldap_controls_free() function.  (Optional, pass NULL
 *                      if not desired).
 *
 * @param freeit        Specifies whether or not to free the results of the 
 *                      operation (the LDAPMessage structure specified by the
 *                      res argument). Zero specifies that the result should 
 *                      not be freed. " A non-zero value specifies that the 
 *                      result should be freed. 
 *
 * @returns             LDAP_SUCCESS if result was successfully 
 *                      
 *                      LDAP_PARAM_ERROR bad parameter or message is not a
 *                      LDAP_RES_SEARCH_REFERENCE
 *
 *                      other LDAP_XXXX error codes defined above.
 **/
int ldap_parse_reference( LDAP* ld, 
                          LDAPMessage* ref, 
                          char*** referralsp, 
                          LDAPControl*** serverctrlsp, 
                          int freeit );


/** Parse the results of an LDAP operation received from an LDAP server.
 *
 * @param ld            Connection handle obtained from call to ldap_init()
 *
 * @param res           Pointer to the LDAPMessage structure containing the
 *                      results of an LDAP operation (i.e. what you got back
 *                      from ldap_result()). 
 *
 * @param errcodep      Pointer to that receives the LDAP result code 
 *                      specifying the result of the operation. (Optional,
 *                      pass NULL if not desired).
 *
 * @param matcheddnp    Pointer to a string that receives the the portion of 
 *                      a DN that finds an existing entry (in cases where the
 *                      server cannot find the entry specified by a DN).
 *                      Must be freed by call to ldap_memfree().  (Optional
 *                      pass NULL if not desired)
 *
 * @param errmsgp       Pointer to a string that receives additional error 
 *                      message string that was sent from the server. Must be
 *                      freed by call to ldap_memfree(). (Optional, pass NULL
 *                      if not desired).
 *
 * @param referralsp    Pointer to an array of strings that receives the 
 *                      referrals returned by the server. Must be freed by 
 *                      call to ldap_memfree().  (Optional, pass NULL if not
 *                      desired).
 *
 * @param serverctrlsp  Pointer to an array that receives LDAPControl 
 *                      structures, which represent the LDAPv3 server controls
 *                      returned by the server. Must be freed by call to 
 *                      ldap_controls_free() function.  (Optional, pass NULL
 *                      if not desired).
 *
 * @param freeit        Specifies whether or not to free the results of the 
 *                      operation (the LDAPMessage structure specified by the
 *                      res argument). Zero specifies that the result should 
 *                      not be freed. " A non-zero value specifies that the 
 *                      result should be freed. 
 *
 * @returns             LDAP_SUCCESS if result was successfully parsed.
 *
 *                      LDAP_NO_RESULTS_RETURNED if the specified LDAPMessage
 *                      structure does not contain the result of an LDAP 
 *                      operation. For example, if it contains an entry (call
 *                      ldap_first_attribute, etc), search reference (call 
 *                      ldap_parse_reference), or chain of search results 
 *                      (call ldap_get_first_entry, etc).
 *                      
 *                      LDAP_MORE_RESULTS_TO_RETURN if the result in the 
 *                      LDAPMessage structure is part of a chain of results
 *                      and the last result is not included.  This means
 *                      that after parsing all the results with 
 *                      ldap_first_message (and friends), that you will 
 *                      need to call ldap_result again to get more results
 *                      
 *                      Other LDAP_XXXX error codes defined above.                                   
 **/
int ldap_parse_result( LDAP* ld,
                       LDAPMessage* res,
                       int* errcodep,
                       char** matcheddnp,
                       char** errmsgp,
                       char*** referralsp,
                       LDAPControl*** serverctrlsp,
                       int freeit );
                     

/** Get the DN of the LDAP object that the search entry is for.
 *
 * @param ld            Connection handle obtained from call to ldap_init()
 *
 * @param entry         Pointer to the LDAPMessage structure representing the
 *                      search entry.
 *
 * @returns             If successful, returns a pointer to the null 
 *                      terminated string name of the entry dn.  The caller 
 *                      is responsible for freeing this string with a call 
 *                      to ldap_memfree(). If unsuccessful, returns a NULL. 
 *                      The appropriate error code will be set in the LDAP 
 *                      structure.  To get the error code, call 
 *                      ldap_get_lderrno(). function.                                     
 **/
char* ldap_get_dn( LDAP* ld, LDAPMessage* entry );


/** Get an attributes string values.
 * The ldap_get_values() function returns a NULL-terminated array of an 
 * attribute's string values for a given entry. Use the ldap_get_values_len()
 * function instead of this function if the attribute values are binary.
 *
 * @param ld            Connection handle obtained from call to ldap_init()
 *
 * @param entry         Pointer to the LDAPMessage structure representing the
 *                      search entry.
 *
 * @param target        Attribute returned by ldap_first_attribute() or 
 *                      ldap_next_attribute(), or the attribute as a literal 
 *                      string, such as "cn".
 * 
 * @param lengths       This is a return variable, which contains the lengths
 *                      of each of the strings that are returned in the NULL 
 *                      terminated array.  This is most useful when the strings
 *                      may be binary and could contain a NULL terminator in 
 *                      the middle of the string somewhere.  This may be NULL
 *                      if the caller is not interested in the lengths of the
 *                      strings. The caller is responsible for freeing the 
 *                      memory assigned to hold the lengths.
 *
 * @returns             If successful, returns a NULL-terminated array of the
 *                      attribute's values. If unsuccessful or if no such 
 *                      attribute exists in the entry, returns a NULL and 
 *                      sets the appropriate error code in the LDAP structure. 
 *                      To get the error code, call the ldap_get_lderrno() 
 *                      function. Returned pointer must be freed by caller
 *                      with call to ldap_value_free();
 **/                                     
char** ldap_get_values( LDAP* ld, 
                        LDAPMessage* entry, 
                        const char* target, 
                        int** lengths );

/** Get the number of attribute values.
 * Used to get the number of values in an array of strings that
 * are returned by ldap_get_values(). Use the ldap_count_values_len() 
 * function instead of this function if the array contains bervals.
 *
 * @param vals          Values usually obtained from call ldap_get_values()
 *
 * @returns             The number of values in the array, if successful,
 *                      -1 if unsuccessful.  Call ldap_get_lderrno() for 
 *                      error information. 
 **/
int ldap_count_values( char** vals );


/** Frees an array of values from memory. 
 * Use the ldap_value_free_len() function instead of this function if 
 * the values are berval structures.
 *
 * @param vals          Values usually obtained from call ldap_get_values()
 *
 * @returns             None.
 **/
void ldap_value_free( char** vals );


/** Get an array of BER values for an attribute.
 * The ldap_get_values_len() function returns a NULL-terminated array of 
 * pointers to berval structures, each containing the length and pointer to 
 * a binary value of an attribute for a given entry. You *may* use the 
 * ldap_get_values() routine instead of this routine if the attribute 
 * values are string values.
 *
 * @param ld            Connection handle obtained from call to ldap_init()
 *
 * @param entry         Pointer to the LDAPMessage structure representing the
 *                      search entry.
 *
 * @param target        Attribute returned by ldap_first_attribute() or 
 *                      ldap_next_attribute(), or the attribute as a literal 
 *                      string, such as "cn".
 *
 * @returns             If successful, returns a NULL-terminated array of 
 *                      pointers to berval structures, which in turn contain 
 *                      pointers to the attribute s binary values. If 
 *                      unsuccessful or if no such attribute exists in the 
 *                      entry, returns a NULL and sets the appropriate error
 *                      code in the LDAP structure. To get the error code, 
 *                      call the ldap_get_lderrno() function. The returned 
 *                      pointer must be freed by caller with call to 
 *                      ldap_value_free_len()                               
 **/
BerValue** ldap_get_values_len( LDAP* ld, 
                                LDAPMessage* entry, 
                                const char* target );


/** Get the number of BER values in an array.
 * Used to get the number of values in an array of berval structures that
 * are returned by ldap_get_values_len(). Use the ldap_count_values() 
 * function instead of this function if the array contains strings.
 *
 * @param vals          Values usually obtained from call ldap_get_values_len()
 *
 * @returns             The number of values in the array, if successful,
 *                      -1 if unsuccessful.  Call ldap_get_lderrno() for 
 *                      error information. 
 **/
int ldap_count_values_len( struct berval** vals );


/** Free an array of BER values from memory. 
 * Use the ldap_value_free() function instead of this function if the 
 * values are strings.
 *
 * @param vals          Values usually obtained from call ldap_get_values()
 *
 * @returns             None.
 **/
void ldap_value_free_len( struct berval** vals );


/** Get information about the last error that occurred.
 * The ldap_get_lderrno() function gets information about the last error 
 * that occurred for an LDAP operation. You can also call this function to 
 * get error codes for functions that do not return errors (such as 
 * ldap_next_attribute()).
 *
 * @param ld            Connection handle obtained from call to ldap_init()
 *
 * @param matcheddn     In the event of an LDAP_NO_SUCH_OBJECT error return, 
 *                      this parameter contains the portion of the DN that
 *                      identifies an existing entry.  Optional, may be
 *                      NULL if matcheddn is not desired.  Do not free 
 *                      returned pointer!
 *
 * @param errmsg        The text of the error message.  Optional, may be
 *                      NULL if errmsg is not desired. Do not free 
 *                      returned pointer!
 *
 * @returns             Errorcode of the last occuring error                              
 **/
int ldap_get_lderrno( LDAP* ld, char** matcheddn, char** errmsg );


/** Free the LDAPMessage allocated by ldap_result().
 *
 * @param msg           The message to free
 *
 * @returns             If successful, returns the type of result freed.  If
 *                      unsuccessful, returns the appropriate errorcode
 **/
int ldap_msgfree( LDAPMessage* msg );

/** Free the memory allocated by the ldap API
 *
 * @param mem           The memory to free
 *
 * @returns             Nothing; void
 *
 **/
void ldap_memfree( char *mem );


/** Add a new entry to the directory.
 *
 * @param ld            Connection handle obtained from call to ldap_init()
 *
 * @param dn            Distinguished name (DN) of the entry to add. With
 *                      the exception of the leftmost component, all 
 *                      components of the distinguished name must exist.
 *                      For example if "cn=matt,dc=example,dc=com", 
 *                      "dc=example,dc=com" must already exist.
 *
 * @param attrs         Pointer to a NULL-terminated array of pointers to 
 *                      LDAPMod structures representing the attributes of 
 *                      the new entry.
 *
 * @param serverctrls   Pointer to an array of LDAPControl
 *                      structures  representing LDAP server controls that 
 *                      apply to this LDAP operation. If you do not want to
 *                      pass any server controls, specify NULL for this 
 *                      argument.
 *
 * @param clientctrls   Pointer to an array of LDAPControl structures 
 *                      representing LDAP client controls that apply to 
 *                      this LDAP operation. If you do not want to pass any
 *                      client controls, specify NULL for this argument.
 *
 * @param msgid         Pointer to an integer that will be set to the 
 *                      message ID of the LDAP operation. To check the 
 *                      result of this operation, call ldap_result() and 
 *                      ldap_parse_result() functions.
 *
 * @returns             LDAP_SUCCESS if successful.
 *
 *                      LDAP_PARAM_ERROR if any of the arguments are invalid.
 *
 *                      LDAP_ENCODING_ERROR if an error occurred when 
 *                      BER-encoding the request. 
 *
 *                      LDAP_SERVER_DOWN if the LDAP server did not receive
 *                      the request or if the connection to the server was 
 *                      lost.
 *
 *                      LDAP_NO_MEMORY if memory cannot be allocated.
 **/
int ldap_add_ext( LDAP* ld, 
                  const char* dn,
                  LDAPMod** attrs,
                  LDAPControl** serverctrls,
                  LDAPControl** clientctrls,
                  int* msgidp );


/** Modify a directory entry.
 *
 * @param ld            Connection handle obtained from call to ldap_init()
 *
 * @param dn            Distinguished name (DN) of the entry to modify.
 *
 * @param mods          Pointer to a NULL-terminated array of pointers to 
 *                      LDAPMod structures representing the attributes to
 *                      modify.
 *
 * @param serverctrls   Pointer to an array of LDAPControl
 *                      structures  representing LDAP server controls that 
 *                      apply to this LDAP operation. If you do not want to
 *                      pass any server controls, specify NULL for this 
 *                      argument LDAPMod structures representing the 
 *                      attributes of the new entry.
 *
 * @param clientctrls   Pointer to an array of LDAPControl structures 
 *                      representing LDAP client controls that apply to 
 *                      this LDAP operation. If you do not want to pass any
 *                      client controls, specify NULL for this argument.
 *
 * @param msgid         Pointer to an integer that will be set to the 
 *                      message ID of the LDAP operation. To check the 
 *                      result of this operation, call ldap_result() and 
 *                      ldap_parse_result() functions.
 *
 * @returns             LDAP_SUCCESS if successful.
 *
 *                      LDAP_PARAM_ERROR if any of the arguments are invalid.
 *
 *                      LDAP_ENCODING_ERROR if an error occurred when 
 *                      BER-encoding the request. 
 *
 *                      LDAP_SERVER_DOWN if the LDAP server did not receive
 *                      the request or if the connection to the server was 
 *                      lost.
 *
 *                      LDAP_NO_MEMORY if memory cannot be allocated.
 **/
int ldap_modify_ext( LDAP* ld, 
                     const char* dn, 
                     LDAPMod** mods, 
                     LDAPControl** serverctrls, 
                     LDAPControl** clientctrls, 
                     int* msgidp );


/** Delete a directory entry.
 *
 * @param ld            Connection handle obtained from call to ldap_init()
 *
 * @param dn            Distinguished name (DN) of the entry to delete.
 *
 * @param serverctrls   Pointer to an array of LDAPControl
 *                      structures  representing LDAP server controls that 
 *                      apply to this LDAP operation. If you do not want to
 *                      pass any server controls, specify NULL for this 
 *                      argument LDAPMod structures representing the 
 *                      attributes of the new entry.
 *
 * @param clientctrls   Pointer to an array of LDAPControl structures 
 *                      representing LDAP client controls that apply to 
 *                      this LDAP operation. If you do not want to pass any
 *                      client controls, specify NULL for this argument.
 *
 * @param msgid         Pointer to an integer that will be set to the 
 *                      message ID of the LDAP operation. To check the 
 *                      result of this operation, call ldap_result() and 
 *                      ldap_parse_result() functions.
 *
 * @returns             LDAP_SUCCESS if successful.
 *
 *                      LDAP_PARAM_ERROR if any of the arguments are invalid.
 *
 *                      LDAP_ENCODING_ERROR if an error occurred when 
 *                      BER-encoding the request. 
 *
 *                      LDAP_SERVER_DOWN if the LDAP server did not receive
 *                      the request or if the connection to the server was 
 *                      lost.
 *
 *                      LDAP_NO_MEMORY if memory cannot be allocated.
 **/
int ldap_delete_ext( LDAP* ld,
                     const char* dn,
                     LDAPControl** serverctrls,
                     LDAPControl** clientctrls,
                     int* msgidp );


/** Free an array of LDAPMod structures.
 * Call this function only if you ve allocated memory for these 
 * structures yourself.
 *
 * @param mods          Pointer to a NULL-terminated array of pointers to 
 *                      LDAPMod structures.
 *
 * @param freemods      If this is a non-zero value, frees the array of 
 *                      pointers as well as the LDAPMod structures. If 0, 
 *                      just frees the LDAPMod structures.
 *
 * @return              None.
 **/
void ldap_mods_free( LDAPMod** mods, int freemods );


/** Free an LDAPControl structure from memory.
 * The memory owned by ldctl_value will be freed as well.
 *
 * @param control       Pointer to a LDAPControl to free.
 *
 * @return              None.
 **/
void ldap_control_free( LDAPControl* control );


/** Frees a null terminated array of pointers to LDAPControl structures.
 *
 * @param controls      LDAPControls array to free.
 *
 * @return              None.
 **/
void ldap_controls_free( LDAPControl** controls );


/** Create a Microsoft extended control for handling security
 *  descriptor flags. See [MS-ADTS]: 3.1.1.3.4.1.11 and
 *  RFC2251 4.1.12.
 *  
 *  @param ld         Connection handle obtained from call to
 *                    ldap_init()
 *  
 *  @param sdflags    Flags to determine which security
 *                    descriptor information to include.
 *                    Bit flag and value:
 *                    0x0 - NONE
 *                    0x1 - OWNER
 *                    0x2 - GROUP
 *                    0x4 - DACL
 *                    0x8 - SACL
 *  
 *  @param iscritical TRUE (0xFF) or FALSE (0x0)
 *  
 *  @param control    Pointer to the newly created control. Must
 *                    be free with call to ldap_control_free()
 **/
int ldap_create_sd_flags_control( LDAP *ld,
                                  int sdflags,
                                  char iscritical,
                                  LDAPControl** control );

/** Create a basic control for paging results.
 * See RFC 2696 for details!
 *
 * When an LDAP client is accessing a server across a slow connection, or if
 * the client suspects that the result set from a given query may be very 
 * large, the client should be able to retrieve a result set in small pieces.
 * The Simple Paged Result extended control allows this type of retrieval by 
 * allowing a one-way walk through a result set. Options on this control 
 * allow the client to set the initial page size and reset the page size 
 * with each subsequent request to the server.
 *
 * The Simple Paged Result control is also used to access all of a large 
 * results set when there is a server-side administrative limit to the 
 * number of items returned from a query. For example, Active Directory 
 * servers have a default server-side limit of 1000 entries as the maximum
 * number of results that are returned in a single request. If the results 
 * of a query exceed this limit, the Paged Results control is used with a 
 * page size equal to or less than the server-side limit in order to 
 * retrieve all of the results of the query.
 *
 * The interaction between client and server is as follows:
 *
 * The client sends the server a search request with the Simple Paged 
 * Results control with an empty previous Enumeration Key, also known as a 
 * cookie, and the initial page size. The server then returns the number of
 * entries specified by the page size and also returns a cookie used on the 
 * next client request to get the next page of results. The client then 
 * issues a search with the cookie included (optionally resetting the page 
 * size) and the server then responds with up to that number of entries.
 *
 * Paged results are indicated as a control on the ldap_search_ext function 
 * call. Use ldap_create_page_control to construct this control, and then 
 * call ldap_search_ext to add the control. This control structure must then
 * be added to the list of server controls in the ldap_search_ext call. When
 * the server returns the first page of results, it includes the resume 
 * cookie in the controls field of the SearchResultDone message. The client
 * must then extract the cookie from the search result by retrieving the 
 * server controls by using ldap_parse_result and parsing the control with 
 * ldap_parse_page_control. The client then uses the cookie in the next 
 * call to LDAP_create_page_control to retrieve the next page of results.
 *
 * @param ld            Connection handle obtained from call to ldap_init()
 *
 * @param pagesize      The number of entries to return in each page.
 *
 * @param cookie        Pointer to a berval structure that the server uses 
 *                      to determine its location in the result set. This is
 *                      an opaque structure that you should not access 
 *                      directly. Set to NULL for the first call to 
 *                      ldap_create_page_control.
 *
 * @param pagesize      Notifies the server whether this control is critical
 *                      to the search.
 *
 * @param control       Pointer to the newly created control.  Must be freed
 *                      with call to ldap_control_free()
 *
 * @returns             LDAP_SUCCESS or appropriate LDAP_XXXX error code on
 *                      failure. 
 **/
int ldap_create_page_control( LDAP* ld, 
                              int pagesize,
                              struct berval* cookie,
                              char iscritical,
                              LDAPControl** control );


/* 
 * @param control       Pointer to the newly created control.  Must be freed
 *                      with call to ldap_control_free()
 *
 * @returns             LDAP_SUCCESS or appropriate LDAP_XXXX error code on
 *                      failure. 
 **/
int ldap_create_tree_delete_control( char iscritical,
                                     LDAPControl** control );

/** Parse the results of a search into pages.
 *
 * @param ld            Connection handle obtained from call to ldap_init()
 *
 * @param controls      An array of controls that includes a page control. 
 *                      The page control contains the cookie and total count
 *                      fields returned by the server.TotalCount
 *
 * @param count         A pointer to the total count of entries to in all
 *                      result pages.
 *
 * @param cookie        An opaque cookie, used by the server to determine 
 *                      its location in the result set. An empty cookie
 *                      (cookie->bv_len == 0) means that there are no more 
 *                      result pages.  cookie must be freed by call 
 *                      to ber_bvfree().     
 **/
int ldap_parse_page_control( LDAP* ld,
                             LDAPControl** controls,
                             int* count,
                             struct berval** cookie );

/** Set the blocking mode for the LDAP connection.
 * Set or unset non-blocking operation for subsequent calls on the specified
 * LDAP handle.  When operating in nonblocking mode, LDAPResult() may return
 * LDAP_BUSY which means that the LDAP server or network subsystem is busy.
 * ldap_nonblocking_get_fds() can be called to obtain the primitive file
 * descriptors that can be use in calls to select() or poll(). Default 
 * operation of newly created LDAP handle is blocking so to enable
 * non-blocking operation, a call to ldap_nonblocking(1) is required.
 *
 * @param ld            Connection handle obtained from call to ldap_init()
 *
 * @param enabled       zero for blocking operation, non-zero fo non-blocking
 *                      operation.
 *
 * @returns             LDAP_SUCCESS or appropriate LDAP_XXXX error code on
 *                      failure.
 **/
int ldap_nonblocking( LDAP* ld, int enabled );


/** Obtain arrays of blocked primitive file descriptors that are suitable
 * for use in calls to select() or poll().
 *
 * @param ld            Connection handle obtained from call to ldap_init()
 *
 * @param readfds       Pointer to integer that receives primitive file
 *                      descriptor (if any) that is would would block on 
 *                      read.  Check returned fd to ensure that it is >=0.
 *                      -1 is an invalid fd indicating that no fd would 
 *                      block on read. 
 *
 * @param writefds      Pointer to integer that receives primitive file
 *                      descriptor (if any) that is would would block on 
 *                      write. Check returned fd to ensure that it is >=0.
 *                      -1 is an invalid fd indicating that no fd would 
 *                      block on write
 *
 * @returns             LDAP_SUCCESS or appropriate LDAP_XXXX error code on
 *                      failure.
 **/
int ldap_nonblocking_get_fds( LDAP* ld, int* readfd, int* writefd );


/* Compatibility with draft-ietf-ldapext-ldap-c-api-05.txt */
#define LDAP_API_VERSION	2005 /* draft-ietf-ldapext-ldap-c-api-05.txt */
#define LDAP_VERSION_MIN	2
#define LDAP_VERSION_MAX	3
#define LDAP_VENDOR_NAME	"One Identity LLC."
#define LDAP_VENDOR_VERSION	260			/* VAS 2.6 */

typedef struct ldapapiinfo {
    int    ldapai_info_version;     /* version of this struct (1) */
    int    ldapai_api_version;      /* revision of API supported */
    int    ldapai_protocol_version; /* highest LDAP version supported */
    char** ldapai_extensions;       /* names of API extensions */
    char*  ldapai_vendor_name;      /* name of supplier */
    int    ldapai_vendor_version;   /* supplier-specific version times 100 */
} LDAPAPIInfo;
#define LDAP_API_INFO_VERSION 1

typedef struct ldap_apifeature_info {
    int    ldapaif_info_version; /* version of this struct (1) */
    char*  ldapaif_name;         /* name of supported feature */
    int    ldapaif_version;      /* revision of supported feature */
} LDAPAPIFeatureInfo;
#define LDAP_FEATURE_INFO_VERSION 1

#if 0
/** Accesses the current value of various session-wide parameters.
 * @param ld		Connection handle obtained by ldap_init()
 * @param option	Option descriptor (One of LDAP_OPT_...)
 * @param outvalue	Address to place the value of the option.
 * 			The actual type of this parameter depends on
 * 			the option used. For outvalues of type char**
 * 			and LDAPControl**, a copy of the data that
 * 			is associated with the LDAP session ld is
 * 			returned; callers should dispose of the
 * 			memory by calling ldap_memfree() or
 * 			ldap_controls_free() as appropriate.
 * @return  0 if successful, or -1 if an error occurs. If an error
 *          occurs, a specific result code may be obtained by
 *          calling ldap_get_option() with an option value of
 *          LDAP_OPT_RESULT_CODE. (That may fail, too.)
 **/
int ldap_get_option( LDAP* ld, int option, void *outvalue );

/** Sets the value of various session-wide parameters.
 * Some options are READ-ONLY and cannot be set; it is an
 * error to call ldap_set_option() to set a READ-ONLY option.
 * @param ld		Connection handle obtained by ldap_init()
 * @param option	Option descriptor (One of LDAP_OPT_...)
 * @param invalue 	Pointer to the value the option is to be
 * 			given. The actual type of this parameter
 * 			depends on the setting of the option
 * 			parameter. The data associated with invalue
 * 			is copied by the API implementation to allow
 * 			callers of the API to dispose of or
 * 			otherwise change their copy of the data
 * 			after a successful call to ldap_set_option().
 * 			If a value for invalue is invalid or cannot
 * 			be accepted by the implementation, this
 * 			function returns -1.
 * @return  0 if successful, or -1 if an error occurs. If an error
 *          occurs, a specific result code may be obtained by
 *          calling ldap_get_option() with an option value of
 *          LDAP_OPT_RESULT_CODE. (That may fail, too.)
 **/
int ldap_set_option( LDAP* ld, int option, const void *invalue );
#endif

/** An value used to enable boolean options. Typically, any non-NULL
 *  value can be used. Note that when a boolean option value is accessed
 *  with ldap_get_option(), the value may be a non-NULL value other
 *  than LDAP_OPT_ON. **/
#define LDAP_OPT_ON		            ((void*)1)
#define LDAP_OPT_OFF		        ((void*)0)

/** Option used to retrieve some basic information about the
 * LDAP API implementation at execution time.  (LDAPAPIInfo*) (READ-ONLY) **/
#define LDAP_OPT_API_INFO		    (0x00)

/** Option that determines how aliases are handled during search.
 * Values are one of LDAP_DEREF_{NEVER,SEARCHING,FINDING,ALWAYS}. 
 * Default is LDAP_DEREF_NEVER. (int *) **/
#define LDAP_OPT_DEREF   		    (0x02)
#define LDAP_DEREF_NEVER		    (0x00)
#define LDAP_DEREF_SEARCHING	    (0x01)
#define LDAP_DEREF_FINDING		    (0x02)
#define LDAP_DEREF_ALWAYS		    (0x03)

/** Option used to limit the number of entries returned from a search.
 * The default value of LDAP_NO_LIMIT means no limit. (int *) **/
#define LDAP_OPT_SIZELIMIT		    (0x04)
#define LDAP_NO_LIMIT			    0

/** Option that determines whether the LDAP library automatically follows 
 * referrals returned by LDAP servers or not. Referrals are disabled by 
 * setting this option to LDAP_OPT_OFF.  Default is ON. (void *) **/
#define LDAP_OPT_REFERRALS		    (0x08)

/** Option that determines whether LDAP I/O operations are
 * automatically restarted if they abort prematurely. This option
 * is useful if an LDAP I/O operation can be interrupted
 * prematurely, for example by a timer going off. Default is OFF (void *) **/
#define LDAP_OPT_RESTART		    (0x09)

/** Option that indicates the version of LDAP protocol
 * used when communicating with the primary LDAP server. It
 * should be one of the constants LDAP_VERSION2 or LDAP_VERSION3.
 * The default is LDAP_VERSION2. (int *) **/
#define LDAP_OPT_PROTOCOL_VERSION	(0x11)
#define LDAP_VERSION2			    2
#define LDAP_VERSION3			    3

/** Option that provides a default list of LDAP server controls to
 * be sent with each request. Default is NULL. (LDAPControl**) **/
#define LDAP_OPT_SERVER_CONTROLS	(0x12)

/** Option that provides a default list of LDAP client controls to
 * be sent with each request. Default is NULL. (LDAPControl**) **/
#define LDAP_OPT_CLIENT_CONTROLS	(0x13)

/** Option to retreive LDAP API extended features at runtime.
 * (LDAPAPIFeatureInfo*) (READ-ONLY) **/
#define LDAP_OPT_API_FEATURE_INFO	(0x15)

/** Option that specifies the hostname, or list of hosts, for the
 * primary LDAP server. See documentation for the hostname
 * parameter of ldap_init() for syntax. 
 * (invalue: char*; outvalue: char**) **/
#define LDAP_OPT_HOST_NAME		    (0x30)

/** Option provding the most recent API generated or server-returned
 * LDAP result code in the session. (int *) **/
#define LDAP_OPT_RESULT_CODE		(0x31)

/** Option provding the message returned with the most recent LDAP
 * error in the session. (invalue: char*; outvalue: char**) **/
#define LDAP_OPT_ERROR_STRING		(0x32)

/** Option providing the matched DN value returned with the most recent 
 * LDAP error in the session. (invalue: char*; outvalue: char**) **/
#define LDAP_OPT_MATCHED_DN		    (0x33)

/** OID for referrals client control */
#define LDAP_CONTROL_REFERRALS		"1.2.840.113556.1.4.616"
#define LDAP_CHASE_SUBORDINATE_REFERRALS 0x00000020U
#define LDAP_CHASE_EXTERNAL_REFERRALS	 0x00000040U

/* More functions... */
int ldap_sasl_bind_s( LDAP* ld, 
                      const char* dn, 
                      const char* mech, 
                      const struct berval* cred, 
                      LDAPControl** sctrls, 
                      LDAPControl** cctrls, 
                      struct berval** servercredp );

int ldap_unbind_ext( LDAP* ld, 
                     LDAPControl **sctrls,
                     LDAPControl **cctrls );

int ldap_unbind_s( LDAP* ld );

int ldap_search_ext_s( LDAP* ld,
                       const char* base,
                       int scope,
                       const char* filter,
                       char** attrs,
                       int attrsonly,
                       LDAPControl** serverctrls,
                       LDAPControl** clientctrls,
                       struct timeval* timeout,
                       int sizelimit,
                       LDAPMessage** res );

int ldap_compare_ext( LDAP* ld,
                      const char* dn,
                      const char* attr,
                      const struct berval* bvalue,
                      LDAPControl** serverctrls,
                      LDAPControl** clientctrls,
                      int* msgidp );

int ldap_compare_ext_s( LDAP* ld,
                        const char* dn,
                        const char* attr,
                        const struct berval* bvalue,
                        LDAPControl** serverctrls,
                        LDAPControl** clientctrls );

int ldap_compare( LDAP* ld,
                  const char* dn,
                  const char* attr,
                  const char* value );

int ldap_compare_s( LDAP* ld,
                    const char* dn,
                    const char* attr,
                    const char* value );

int ldap_modify_ext_s( LDAP* ld, 
                       const char* dn, 
                       LDAPMod **mods,
                       LDAPControl** serverctrls,
                       LDAPControl** clientctrls );

int ldap_rename( LDAP* ld, 
                 const char* dn, 
                 const char* newrdn, 
                 const char* newparent,
                 int deleteoldrdn,
                 LDAPControl** serverctrls,
                 LDAPControl** clientctrls,
                 int* msgidp );

int ldap_rename_s( LDAP* ld, 
                   const char* dn, 
                   const char* newrdn, 
                   const char* newparent,
                   int deleteoldrdn,
                   LDAPControl** serverctrls,
                   LDAPControl** clientctrls );

int ldap_add_ext_s( LDAP* ld, 
                    const char* dn,
                    LDAPMod** attrs,
                    LDAPControl** serverctrls,
                    LDAPControl** clientctrls );

int ldap_delete_ext_s( LDAP* ld,
                       const char* dn,
                       LDAPControl** serverctrls,
                       LDAPControl** clientctrls );

int ldap_extended_operation( LDAP* ld,
                             const char* requestoid,
                             const struct berval* requestdata,
                             LDAPControl** serverctrls,
                             LDAPControl** clientctrls,
                             int* msgidp );

int ldap_extended_operation_s( LDAP* ld,
                               const char* requestoid,
                               const struct berval* requestdata,
                               LDAPControl** serverctrls,
                               LDAPControl** clientctrls,
                               char** retoidp,
                               struct berval** retdatap );

int ldap_abandon_ext( LDAP* ld,
                      int msgid,
                      LDAPControl** serverctrls,
                      LDAPControl** clientctrls );

int ldap_msgtype( LDAPMessage* res );

int ldap_msgid( LDAPMessage* res );

int ldap_parse_extended_result( LDAP* ld,
                                LDAPMessage* res,
                                char** retoidp,
                                struct berval** retdatap,
                                int freeit );

#define LDAP_NOTICE_OF_DISCONNECTION "1.3.6.1.4.1.1466.20036"

#define LDAP_RES_UNSOLICITED	0		/* unimpl */
#define LDAP_RES_ANY	    	(-1)	/* unimpl */
			      
LDAPMessage* ldap_first_message( LDAP* ld, LDAPMessage* res );

LDAPMessage* ldap_next_message( LDAP* ld, LDAPMessage* msg );

int ldap_count_messages( LDAP* ld, LDAPMessage* res );

LDAPMessage* ldap_first_reference( LDAP* ld, LDAPMessage* res);

LDAPMessage* ldap_next_reference( LDAP* ld, LDAPMessage* ref);

int ldap_count_references( LDAP* ld, LDAPMessage* res );

void ldap_memfree( char *mem );

char** ldap_explode_rdn( const char* rdn, int notypes );

int ldap_get_entry_controls( LDAP* ld,
                             LDAPMessage* entry,
                             LDAPControl*** serverctrlsp );

#ifdef LDAP_USE_RFC1823
/* Deprecated methods provided for RFC1823 compatibility only */
        
/* Constants for use with deprecated ldap_bind() */
#define LDAP_RFC_1823_AUTH_SIMPLE	0
#define LDAP_RFC_1823_AUTH_KRBV41	1
#define LDAP_RFC_1823_AUTH_KRBV42	2

LDAP* ldap_open( char* hostname, int portno );
int ldap_bind( LDAP* ld,  char* dn, char *cred, int method );
int ldap_bind_s( LDAP* ld, char* dn, char *cred, int method );
int ldap_simple_bind( LDAP* ld, char* dn, char *passwd );
int ldap_simple_bind_s( LDAP* ld, char* dn, char *passwd );
int ldap_kerberos_bind( LDAP* ld, char* dn );
int ldap_kerberos_bind_s( LDAP* ld, char* dn );
int ldap_search( LDAP* ld, char* base, int scope,char* filter, char* attrs[], int attrsonly );
int ldap_search_s( LDAP* ld, char* base, int scope, char* filter, char* attrs[], int attrsonly, LDAPMessage** res );
int ldap_search_st( LDAP* ld, char* base, int scope, char* filter, char* attrs[], int attrsonly, struct timeval* timeout, LDAPMessage** res );
int ldap_modify( LDAP* ld, char* dn, LDAPMod* mods[] );
int ldap_modify_s( LDAP* ld, char* dn, LDAPMod* mods[] );
int ldap_modrdn( LDAP* ld, char* dn, char* newrdn, int deleteoldrdn );
int ldap_modrdn_s( LDAP* ld, char* dn, char* newrdn, int deleteoldrdn );
int ldap_add( LDAP* ld, char* dn, LDAPMod* attrs[] );
int ldap_add_s( LDAP* ld, char* dn, LDAPMod* attrs[] );
int ldap_delete( LDAP* ld, char* dn );
int ldap_delete_s( LDAP* ld, char* dn );
int ldap_abandon( LDAP* ld, int msgid );
int ldap_result2error( LDAP* ld, LDAPMessage *res, int freeit );
char* ldap_err2string( int err );
void ldap_perror( LDAP* ld, char* msg );
LDAPMessage* ldap_first_entry( LDAP* ld, LDAPMessage* res );
LDAPMessage* ldap_next_entry( LDAP* ld, LDAPMessage* entry );
int ldap_count_entries( LDAP* ld, LDAPMessage* res );
char** ldap_get_values( LDAP* ld, LDAPMessage* entry, char* attr );
char** ldap_explode_dn( char* dn, int notypes );
char* ldap_dn2ufn( char* dn );
#endif

#ifdef __cplusplus
}
#endif

#endif
