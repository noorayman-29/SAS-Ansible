/**
 * Quest Authentication Services (QAS) API
 *
 * QAS API Version 4.0
 *
 * Copyright (c) 2010 Quest Software, Inc. All Rights Reserved.
 *
 * This header file is distributed as part of the Quest 
 * Authentication Services (previously Vintela Authentication 
 * Services or VAS) distribution governed by the Quest 
 * Authentication Services (QAS) Software End User License 
 * Agreement (the "EULA"). This header file is part of the 
 * "Licensed Software" licensed to a Licensee under the EULA. 
 * The Licensee may use information learned from this file to 
 * develop software applications that use the libvas library of 
 * QAS as permitted by the EULA, and for no other purpose. If 
 * you are not the Licensee under the EULA, then you do not have 
 * any license to use this file or any information in it. 
 *
 **/

/* NOTE:  This header file contains comment markups that are used with
 *        the Doxygen (generated) documentation system
 */


/** @file
 * Function declarations that allow transition to the "MIT-style" Kerberos API
 *
 * These declarations are intended to be used in conjunction with the
 * krb5 header files that are part of the QAS SDK. The implementation for the
 * krb5 library is found in libvas.so. No other Kerberos library should be
 * linked in.
 **/


#ifndef VAS_KRB5_H_INCLUDED
#define VAS_KRB5_H_INCLUDED

#include "vas.h"
#include "krb5.h"

#ifdef __cplusplus
extern "C" {
#endif

/** Obtain the Kerberos context used by a QAS context.
 * Used to obtain a pointer to the krb5_context that is used by a ::vas_ctx_t
 * The returned krb5ctx pointer is a pointer that could be orphaned by
 * subsequent calls to other QAS functions.  To avoid possible problems
 * with orphaned pointers,  vas_krb5_get_context() should be called
 * each time the krb5_context is needed.
 *
 * @param ctx      A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param krb5ctx  Will be set to point to the internal krb5ctx context.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_KRB5          - Kerberos error. Use vas_err_t functions
 *                                    to obtain Kerberos error details
 *
 * @code
 *
 * // EXAMPLE:
 * int myfunc( vas_ctx_t *ctx )
 * {
 *     krb5_context  krb5ctx = NULL;
 *
 *     if( vas_krb5_get_context( ctx, &krb5ctx ) )
 *         fprintf( stderr, "Unable to obtain Kerberos from QAS context!\n" );
 *     ...
 * }
 *
 * @endcode
 *
 **/
vas_err_t vas_krb5_get_context( vas_ctx_t* ctx, krb5_context* krb5ctx );


/** Obtain the Kerberos principal associated with a QAS identity.
 * Used to obtain a pointer to the krb5_principal that is associated with
 * a ::vas_id_t.  The returned krb5princ pointer is a pointer that could be
 * orphaned by subsequent calls to other QAS functions.  To avoid possible
 * problems with orphaned pointers,  vas_krb5_get_principal() should
 * be called each time the krb5_principal is needed.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id        The ::vas_id_t for which you need the krb5_principal.
 *
 * @param krb5princ Will be set to point to the krb5_principal of the id.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_KRB5          - Kerberos error. Use vas_err_t functions
 *                                    to obtain Kerberos error details
 **/
vas_err_t vas_krb5_get_principal( vas_ctx_t* ctx,
                                  vas_id_t* id,
                                  krb5_principal* krb5princ );


/** Obtain the krb5_ccache that is associated with a QAS identity.
 * Used to obtain a pointer to the krb5_ccache that is associated with
 * a ::vas_id_t. The returned krb5cc pointer is a pointer that could be
 * orphaned by subsequent calls to other QAS functions (like
 * vas_id_free()). To avoid possible problems with orphaned
 * Kerberos credential cache pointers, vas_krb5_get_ccache() should
 * be called each time the krb5_ccache is needed.
 *
 * @param ctx       A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id        The ::vas_id_t that you need the krb5cc for.
 *
 * @param krb5cc    The Kerberos credential cache associated with the specified
 *                  ::vas_id_t.
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_KRB5          - Kerberos error. Use vas_err_t functions
 *                                    to obtain Kerberos error details
 **/
vas_err_t vas_krb5_get_ccache( vas_ctx_t* ctx,
                               vas_id_t* id,
                               krb5_ccache* krb5cc );


/** Establish credentials with initial TGT
 *
 * @param ctx         A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id          Set this ::vas_id_t to use the specified TGT
 *
 * @param tgt         The krb5_creds (TGT) to be established in the
 *                    specified ::vas_id_t
 *
 * @param credflags   The following flags are recognized:
 *                    - VAS_ID_FLAG_USE_MEMORY_CCACHE - Credential cache
 *                      is kept in memory so that it will not outlive the
 *                      specified ::vas_id_t
 *
 * @return  VAS_ERR_SUCCESS on success or one of the following error codes:
 *          - VAS_ERR_KRB5     - Kerberos error. Use ::vas_err_t functions
 *                               to obtain Kerberos error details
 *          - VAS_ERR_INVALID_PARAM - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY     - Memory allocation failed
 **/
vas_err_t vas_krb5_establish_cred_tgt( vas_ctx_t* ctx,
                                       vas_id_t* id,
                                       krb5_creds* tgt,
                                       int credflags );


/** Used to obtain, cache, and validate Kerberos credentials.
 *
 * @param ctx         A ::vas_ctx_t obtained from vas_ctx_alloc().
 *
 * @param id          The ::vas_id_t (client) that will be used to obtain creds.
 *
 * @param addtocache  If set to 1, the requested ticket will be added to the id's
 *                    associated ticket cache.
 *
 * @param target      The principal name of the ticket that will be requested.
 *
 * @param creds       The krb5_creds.  Returned pointer must be freed with
 *                    a call to krb5_free_creds(). This may be NULL if the
 *                    actual ticket data is not needed by the caller.
 *
 * @return  Zero on success or non-zero errno on error.  The following
 *          return values are defined:
 *          - VAS_ERR_SUCCESS       - Credentials ARE already established.
 *          - VAS_ERR_KRB5          - Kerberos error
 *          - VAS_ERR_CRED_NEEDED   - Credentials are NOT established
 *          - VAS_ERR_CRED_EXPIRED  - Credentials are expired.
 *          - VAS_ERR_INVALID_PARAM - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY     - Memory allocation failed
 **/
vas_err_t vas_krb5_get_credentials( vas_ctx_t* ctx,
                                    vas_id_t* id,
                                    const char* target,
                                    int addtocache,
                                    krb5_creds** creds );


/** Validate Kerberos credentials and obtain authentication data.
 *
 * @param ctx     vas_ctx_t obtained from vas_ctx_alloc()
 *
 * @param creds   The creds to be validated
 *
 * @param keytab  The service keytab file to use to validate creds. Pass
 *                in NULL to use the default service keytab
 *
 * @param auth    Authentication data that can be used in calls to to
 *                vas_auth_xxx() functions. Returned pointer must be
 *                freed with call to vas_auth_free().  Pass in NULL if
 *                authentication data is not desired.
 *
 * @return  Zero on success or non-zero error.  The following return values
 *          are defined
 *          - VAS_ERR_SUCCESS       - Success
 *          - VAS_ERR_KRB5          - Kerberos error. Use vas_err_t functions
 *                                    to obtain Kerberos error details
 *          - VAS_ERR_INVALID_PARAM - An invalid parameter was passed
 *          - VAS_ERR_NO_MEMORY     - Memory allocation failed
 *          - VAS_ERR_CRED_NEEDED   - Credentials not established for client
 *                                    or server ::vas_id_t
 *          - VAS_ERR_CRED_EXPIRED  - Client credentials are expired.
 **/
vas_err_t vas_krb5_validate_credentials( vas_ctx_t* ctx,
                                         krb5_creds* creds,
                                         const char* keytab,
                                         vas_auth_t** auth );
/** This is a wrapper function for krb5_parse_name.
 * The purpose of this wrapper for now is to capitalize the realm name before handing it
 * off to krb5_parse_name to keep behavior the same in QAS 4.2 as it was in 4.1.x..  By making a
 * wrapper function, we can do this without changing the heimdal code.  This function will
 * be used for other such needs in the future as well.
 **/
krb5_error_code
vas_krb5_parse_name (
        krb5_context /*context*/,
        const char */*name*/,
        krb5_principal */*principal*/);



/** This is a wrapper function for krb5_parse_name_flags.
 * The purpose of this wrapper for now is to capitalize the realm name before handing it
 * off to krb5_parse_name to keep behavior the same in QAS 4.2 as it was in 4.1.x.  By making a
 * wrapper function, we can do this without changing the heimdal code.  This function will
 * be used for other such needs in the future as well.
 **/
krb5_error_code
vas_krb5_parse_name_flags (
        krb5_context /*context*/,
        const char */*name*/,
        int /*flags*/,
        krb5_principal */*principal*/);





#ifdef __cplusplus
}
#endif

#endif
